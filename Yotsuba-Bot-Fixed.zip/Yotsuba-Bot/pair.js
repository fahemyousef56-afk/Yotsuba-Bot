import {
  makeWASocket,
  useMultiFileAuthState,
  Browsers,
  fetchLatestBaileysVersion,
  DisconnectReason
} from '@whiskeysockets/baileys';
import { randomBytes } from 'crypto';
import pino from 'pino';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SESSION_PATH = path.join(__dirname, 'session');

function bytesToCrockford(bytes) {
  const alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  let result = '';
  for (let i = 0; i < bytes.length; i++) {
    result += alphabet[bytes[i] % 32];
  }
  return result;
}

async function startPairing() {
  console.log('\n╔══════════════════════════════════════╗');
  console.log('║        ربط بوت 𝒀𝒖𝒏𝒂 • 𝑩𝜺𝑻⃝🕸 بواتساب        ║');
  console.log('╚══════════════════════════════════════╝\n');

  if (!fs.existsSync(SESSION_PATH)) {
    fs.mkdirSync(SESSION_PATH, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_PATH);
  const { version } = await fetchLatestBaileysVersion();

  const phoneNumber = '201092189342';

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false,
    markOnlineOnConnect: false,
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    fireInitQueries: false,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 10000,
  });

  sock.ev.on('creds.update', saveCreds);

  let pairingDone = false;

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, isNewLogin } = update;

    if (connection === 'open') {
      console.log('\n✅ تم الربط بنجاح! البوت متصل بواتساب');
      console.log('✅ الجلسة محفوظة في مجلد sessions/');
      console.log('\n👉 شغّل البوت الرئيسي بـ: node index.js\n');
      pairingDone = true;
      setTimeout(() => process.exit(0), 3000);
    }

    if (connection === 'close') {
      const reason = lastDisconnect?.error?.output?.statusCode;
      if (reason === DisconnectReason.loggedOut || pairingDone) {
        console.log('\n❌ انتهت الجلسة أو تم تسجيل الخروج\n');
        process.exit(0);
      }
    }
  });

  // انتظر 3 ثواني للاتصال ثم اطلب الكود
  await new Promise(r => setTimeout(r, 3000));

  if (!state.creds.registered) {
    try {
      const customCode = bytesToCrockford(randomBytes(8));
      const code = await sock.requestPairingCode(phoneNumber, customCode);

      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log(`\n🔐 كود الربط: ${code}\n`);
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log('\n📱 افتح واتساب على رقم: ' + phoneNumber);
      console.log('   ⋮ → الأجهزة المرتبطة → ربط جهاز');
      console.log('   → ربط برقم الهاتف → أدخل الكود\n');
      console.log('⏳ في انتظار التأكيد...\n');
    } catch (err) {
      console.error('❌ خطأ في طلب الكود:', err.message);
      process.exit(1);
    }
  } else {
    console.log('✅ الجلسة موجودة مسبقًا - شغّل: node index.js');
    process.exit(0);
  }
}

startPairing().catch(err => {
  console.error('❌ خطأ:', err.message);
  process.exit(1);
});
