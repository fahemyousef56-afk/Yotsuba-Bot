import { SubBots } from 'meowsab';
import { fetchLatestBaileysVersion } from '@whiskeysockets/baileys';
import { group } from './system/control.js';
import { enforceImageOnlySending } from './system/image-only.js';
const BOT_BRAND = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const REACTIONS = [
  '⚡',
  '😈',
  '🔥',
  '👀',
  '🫢',
  '🎭',
  '💥'
];

const randomReaction = () => {
  return REACTIONS[
    Math.floor(Math.random() * REACTIONS.length)
  ];
};

const isBotNameMessage = (text) => {
  if (!text) return false;

  const value = text.trim().toLowerCase();

  return (
    value === 'يوتسوبا' ||
    value === 'Yousef'
  );
};

const sendBotReaction = async (conn, chat, message) => {
  const reaction = randomReaction();

  try {
    await conn.sendMessage(chat, {
      react: {
        text: reaction,
        key: message.key
      }
    });
  } catch (error) {
    console.error(
      'Reaction error:',
      error?.message || error
    );
  }

  try {
    // تم إلغاء فيديو الاسم مع الإبقاء على التفاعل بالإيموجي.
    await conn.sendMessage(
      chat,
      { text: `${reaction} *${BOT_BRAND} معاك* 🌸` },
      { quoted: message }
    );
  } catch (error) {
    console.error(
      'Bot name response error:',
      error?.message || error
    );
  }
};

const getMessageText = (msg) => {
  if (!msg?.message) return null;

  if (msg.message.conversation) {
    return msg.message.conversation;
  }

  if (msg.message.extendedTextMessage?.text) {
    return msg.message.extendedTextMessage.text;
  }

  if (msg.message.imageMessage?.caption) {
    return msg.message.imageMessage.caption;
  }

  if (msg.message.videoMessage?.caption) {
    return msg.message.videoMessage.caption;
  }

  return msg.body || null;
};

const toParticipant = participant => {
  const jid = typeof participant === 'string'
    ? participant
    : participant?.phoneNumber || participant?.id;

  return jid ? { phoneNumber: jid } : null;
};

const attachSubBotWelcome = bot => {
  const sock = bot?.sock;
  if (!sock?.ev || bot.__welcomeSocket === sock) return;

  bot.__welcomeSocket = sock;
  enforceImageOnlySending(sock);
  sock.ev.on('group-participants.update', async update => {
    try {
      const participants = (update?.participants || [])
        .map(toParticipant)
        .filter(Boolean);
      const author = toParticipant(update?.author)?.phoneNumber || null;

      await group(
        { sock },
        {
          chat: update.id,
          participants,
          author
        },
        update.action
      );
    } catch (error) {
      console.error(
        `❌ [SubBot ${bot.id}] Welcome error:`,
        error?.message || error
      );
    }
  });
};

/*
|--------------------------------------------------------------------------
| تشغيل البوتات الفرعية
|--------------------------------------------------------------------------
*/

async function startSubBots(client) {
  global.subBots = new SubBots(
    client.commandSystem
  );

  const { config } = client;

  await global.subBots.setConfig({
    commandsPath:
      config.commandsPath || './plugins',

    owners: config.owners,
    prefix: config.prefix,
    info: config.info,
    settings: {
      ...(config.settings || {}),
      noWelcome: false
    },
    printQR: false
  });

  let controlOperation = Promise.resolve();
  const queueControlOperation = operation => {
    controlOperation = controlOperation.then(operation, operation);
    return controlOperation;
  };

  global.whatsappControl = {
    status() {
      return {
        main: {
          connected: Boolean(global.mainBot?.isConnected?.()),
          phone: global.mainBot?.config?.phoneNumber || null
        },
        subBots: global.subBots.list()
      };
    },

    pauseAll() {
      return queueControlOperation(async () => {
        const subBots = global.subBots.list();
        await Promise.all(
          subBots.map(async item => {
            const bot = global.subBots.get(item.id);
            if (bot?.cleanup) await bot.cleanup();
          })
        );
        if (global.mainBot?.stop) await global.mainBot.stop();
      });
    },

    resumeAll() {
      return queueControlOperation(async () => {
        if (global.mainBot?.start && !global.mainBot.isConnected?.()) {
          await global.mainBot.start();
        }

        const { version } = await fetchLatestBaileysVersion();
        const subBots = global.subBots.list();
        await Promise.all(
          subBots.map(async item => {
            const bot = global.subBots.get(item.id);
            if (bot && !bot.connected) {
              await bot.start([version[0], version[1], version[2]]);
            }
          })
        );
      });
    }
  };

  global.subBots.on(
    'error',
    (uid, error) => {
      console.error(
        `❌ [SubBot ${uid}] Error:`,
        error?.message || error
      );
    }
  );

  global.subBots.on(
    'ready',
    (uid) => {
      attachSubBotWelcome(global.subBots.get(uid));
      console.log(
        `✅ [SubBot ${uid}] Connected!`
      );
    }
  );

  global.subBots.on(
    'pair',
    (uid, code) => {
      console.log(
        `🔐 [SubBot ${uid}] Pairing code: ${code}`
      );
    }
  );

  global.subBots.on(
    'message',
    async (uid, msg) => {
      if (msg.key?.id?.includes('3EB0')) {
        return;
      }

      const body = getMessageText(msg);
      const bot = global.subBots.get(uid);
      const sock = bot?.sock;

      if (!sock || !body) return;

      const chat = msg.key.remoteJid;

       if (!isBotNameMessage(body)) {
        return;
      }

       await sendBotReaction(
        sock,
        chat,
        msg
      );
    }
  );

  global.subBots.on(
    'close',
    (uid) => {
      console.log(
        `🔌 [SubBot ${uid}] Disconnected`
      );
    }
  );

  global.subBots.on(
    'badSession',
    (uid) => {
      console.log(
        `⚠️ [SubBot ${uid}] Bad session, removed`
      );
    }
  );

  const loadedCount =
    await global.subBots.load();

  console.log(
    `✅ Loaded ${loadedCount} saved bots`
  );

  return global.subBots;
}

/*
|--------------------------------------------------------------------------
| تشغيل البوت الأساسي والبوتات الفرعية معًا
|--------------------------------------------------------------------------
*/

async function sub(client) {
  /*
   * هذا الجزء يجعل البوت الأساسي يستجيب لاسم البوت
   * بنفس طريقة البوتات الفرعية، بدون إرسال فيديو.
   */
  if (client?.onBeforeCommand) {
    client.onBeforeCommand(
      async (message, { conn }) => {
        const body =
          message?.text ||
          getMessageText(message);

        if (!isBotNameMessage(body)) {
          return;
        }

        await sendBotReaction(
          conn,
          message.chat,
          message
        );
      }
    );
  }

  /*
   * تشغيل البوتات الفرعية
   */
  return await startSubBots(client);
}

export default sub;