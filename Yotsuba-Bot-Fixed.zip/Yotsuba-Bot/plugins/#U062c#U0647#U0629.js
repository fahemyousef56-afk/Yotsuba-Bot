let handler = async (m, { conn, bot }) => {
  let watermark = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';

  let quoted = {
    key: { 
      fromMe: false, 
      participant: '0@s.whatsapp.net', 
      remoteJid: 'status@broadcast' 
    },
    message: { 
      conversation: watermark 
    }
  };

  const num = bot?.config?.owners?.[0]?.jid?.split("@")[0] 
           || global.owner?.[0]?.[0]?.replace(/[^0-9]/g, '') 
           || m.sender.replace(/[^0-9]/g, '');
           
  const ownerJid = num + '@s.whatsapp.net';

  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:${watermark}
TEL;type=CELL;type=VOICE;waid=${num}:+${num}
END:VCARD`;

  await conn.sendMessage(m.chat, {
    text: `𝑪𝒉𝒂𝒕  •  𝒀𝒐𝒕𝒔𝒖𝒐`,
    mentions: [ownerJid]
  }, { quoted });

  await conn.sendMessage(m.chat, {
    contacts: {
      displayName: watermark,
      contacts: [{ vcard }]
    }
  });
};

handler.command = ['يوتسو'];
handler.desc = 'إرسال جهة اتصال ';

export default handler;