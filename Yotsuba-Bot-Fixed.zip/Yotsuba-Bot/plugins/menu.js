// plugins/menu.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩𝜺𝑻⃝🕸 ⤾
//
// تصميم القائمة القديم (الزخرفة + الأقسام المرقمة) مبني على آلية الكود القديم:
//   bot.getAllCommands()  ← جلب الأوامر المحمّلة فعلاً (من غير import للبلجنز)
//   conn.sendButton()     ← أزرار تفاعلية
//   handler.before        ← التقاط ضغطات القايمة والأزرار

/* ───────────── إعدادات عامة ───────────── */
const DECORATION = '~_✿┉═┉══𐦍༘◞🕸◜༘𐦍═┉═┉═✿_~'
const SEPARATOR = '~✿━━━•﹝🕸﹞•━━━✿~'
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩𝜺𝑻⃝🕸'
const DEV_NAME = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗'
const DEV_NUMBER = '+201142021371'

const CHANNEL_URL = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z'
const CHANNEL_JID = '120363433665479594@newsletter'
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍'

const MAIN_THUMB = 'https://i.ibb.co/vxq66vC2/file-00000000c8848210bee1fab158b95b43.png'
const CATEGORY_THUMB = 'https://i.ibb.co/qF4C0jcS/file-000000004bd08210ad41fbb763236fcf.png'
const MENU_VIDEO = 'https://files.catbox.moe/oyfcb3.mp4'   // الفيديو الدايري اللي بيتبعت بعد القائمة

const ID = 'yots'                       // بادئة ids الأزرار (عشان ما تتعارضش مع أوامر تانية)
const PAGE_SIZE = 8                     // عدد الأقسام في صفحة القايمة الواحدة
const CACHE_TTL = 30 * 1000             // كاش الأوامر 30 ثانية
const AUDIO_COOLDOWN = 10 * 60 * 1000   // الفيديو مرة كل 10 دقايق لكل شات (خليه 0 لو عايزه كل مرة)

const audioCooldown = {}
const cache = new WeakMap()

// رسالة متحوّلة من القناة
const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
})

/* ───────────── الأقسام (نفس ترتيب وأسماء التصميم القديم) ───────────── */
// [رقم, الاسم, مفتاح التصنيف, الإيموجي]
const CATEGORIES = [
    [1, 'التـحـمـيـل', 'downloads', '📂'],
    [2, 'الـمـجـمـوعـات', 'group', '🐞'],
    [3, 'الـمـلـصـقـات', 'sticker', '🌄'],
    [4, 'الـمـطـوريـن', 'owner', '🕸'],
    [5, 'امـثـلـه', 'example', '✳️'],
    [6, 'الـادوات', 'tools', '🚀'],
    [7, 'الـبـحـث', 'search', '🌐'],
    [8, 'الادمــن', 'admin', '👨🏻‍⚖️'],
    [9, 'الالــعـاب', 'games', '🎮'],
    [10, 'الچيف', 'gif', '✴️'],
    [11, 'الـبــنـك', 'bank', '💰'],
    [12, 'الـذكـاء الاصـطـنـاعـي', 'ai', '🤖'],
    [13, 'الـبـوتـات الـفـرعـي', 'sub', '♥️'],
    [14, 'مـعـلومـات الـبـوت', 'info', '🗃️'],
    [15, 'الـالــقــاب', 'nicknames', '🫯'],
    [16, 'الـلـوجـوهــات', 'logos', '🎡'],
    [17, 'تـغـيـر الاصـوات', 'voices', '📢'],
    [18, 'أخــرى', 'other', '🌹'],
]

// أسماء تصنيفات بديلة موجودة في البلجنز → تتحول للقسم الصح
const ALIASES = {
    admins: 'admin',
    game: 'games',
    'ألعاب': 'games',
    'العاب': 'games',
    download: 'downloads',
    downloader: 'downloads',
    media: 'downloads',
    'البوتات': 'sub',
    main: 'other',
    fun: 'other',
}

/* ───────────── دوال مساعدة ───────────── */
const KNOWN_KEYS = new Set(CATEGORIES.map(c => c[2]))

const normalizeCategory = (raw) => {
    const key = String(raw ?? '').trim().toLowerCase()
    const mapped = ALIASES[key] || key
    return KNOWN_KEYS.has(mapped) ? mapped : 'other'
}

const getCommandCategory = (command) => {
    const raw = command?.category
        || (Array.isArray(command?.tags) ? command.tags[0] : command?.tags)
        || 'other'
    return normalizeCategory(raw)
}

// أول اسم أمر نصي (الأوامر اللي بتشتغل بـ RegExp بس بتتجاهل)
const getCommandName = (command) => {
    const triggers = Array.isArray(command?.command) ? command.command : [command?.command]
    const name = triggers.find(t => typeof t === 'string' && t.trim())
    return name ? name.trim() : null
}

const getDeveloperLink = (bot) => {
    const ownerJid = bot?.config?.owners?.find(o => o?.jid)?.jid
        || globalThis.mainBot?.config?.owners?.find(o => o?.jid)?.jid
        || ''
    const number = String(ownerJid).split('@')[0].replace(/\D/g, '') || DEV_NUMBER.replace(/\D/g, '')
    return `https://wa.me/${number}`
}

async function getUserName(conn, m) {
    try {
        if (typeof conn?.getName === 'function') {
            const n = await conn.getName(m.sender)
            if (n) return n
        }
    } catch {}
    return m.pushName || m.name || String(m.sender || '').split('@')[0] || 'مستخدم'
}

// بيرجع id الزر المضغوط (اللي بتبدأ ببادئتنا)
const getMenuId = (m) => {
    const message = m?.message || {}
    const flow = message.interactiveResponseMessage?.nativeFlowResponseMessage
    let params = {}
    try { params = flow?.paramsJson ? JSON.parse(flow.paramsJson) : {} } catch {}

    const candidates = [
        m?.text,
        m?.body,
        m?.selectedButtonId,
        m?.buttonId,
        m?.listResponseId,
        message.buttonsResponseMessage?.selectedButtonId,
        message.templateButtonReplyMessage?.selectedId,
        message.listResponseMessage?.singleSelectReply?.selectedRowId,
        params.id,
        params.selected_id,
        params.selected_row_id,
    ]
    for (const c of candidates) {
        if (typeof c !== 'string') continue
        const text = c.trim().replace(/^[.!/]\s*/, '')
        if (text.startsWith(`${ID}::`)) return text
    }
    return ''
}

/* ───────────── جمع الأوامر من البوت ───────────── */
async function loadCommands(bot) {
    const holder = bot && typeof bot === 'object' ? bot : globalThis
    const hit = cache.get(holder)
    if (hit && Date.now() - hit.ts < CACHE_TTL) return hit

    const loaded = await bot.getAllCommands()
    const all = Array.isArray(loaded) ? loaded : Object.values(loaded || {})

    const map = {}
    const seen = {}
    let total = 0

    for (const command of all) {
        if (!command) continue
        const name = getCommandName(command)
        if (!name) continue
        const key = getCommandCategory(command)
        const set = (seen[key] ||= new Set())
        if (set.has(name)) continue
        set.add(name)
        ;(map[key] ||= []).push(name)
        total++
    }
    for (const key of Object.keys(map)) map[key].sort((a, b) => a.localeCompare(b, 'ar'))

    // الأقسام اللي فيها أوامر بس
    const visible = CATEGORIES.filter(([, , key]) => map[key]?.length)

    const result = { map, total, visible, ts: Date.now() }
    cache.set(holder, result)
    return result
}

/* ───────────── القائمة الرئيسية ───────────── */
const buildMainText = (user, total, sections) => `${DECORATION}

✿ *مـࢪحـبـا يـا*  ⇜  『 ${user} 』
✿ *الأوامــࢪ*  ⇜  『 ${total} 』
✿ *الأقــســام*  ⇜  『 ${sections} 』
✿ *الـمـطـوࢪ*  ⇜  『 ${DEV_NAME} 』

${DECORATION}
\`\`\` أخـتـࢪ مـا تُـࢪيـدة من الـزࢪ أدنـاه \`\`\`
> ${BOT_NAME}
${DECORATION}`

async function sendMainMenu(m, { conn, bot }, page = 0, withAudio = true) {
    const { map, total, visible } = await loadCommands(bot)
    if (!visible.length) {
        return conn.sendMessage(m.chat, {
            text: `${DECORATION}\n❌ لا توجد أقسام أوامر متاحة حالياً\n${DECORATION}`,
            contextInfo: channelContext(),
        }, { quoted: m })
    }

    const user = await getUserName(conn, m)
    const totalPages = Math.max(1, Math.ceil(visible.length / PAGE_SIZE))
    const current = Math.max(0, Math.min(Number(page) || 0, totalPages - 1))
    const start = current * PAGE_SIZE

    const rows = visible.slice(start, start + PAGE_SIZE).map(([, name, key, emoji]) => ({
        title: `${emoji} ${name}`,
        description: `🕸 ${map[key].length} أمر ⇜ اضغط للعرض`,
        id: `${ID}::cat::${key}`,
    }))
    if (current > 0) {
        rows.push({ title: '⬅️ الصفحة السابقة', description: `العودة إلى صفحة ${current}`, id: `${ID}::page::${current - 1}` })
    }
    if (current < totalPages - 1) {
        rows.push({ title: '➡️ الصفحة التالية', description: `عرض صفحة ${current + 2} من ${totalPages}`, id: `${ID}::page::${current + 1}` })
    }

    if (withAudio) {
        try { await conn.sendMessage(m.chat, { react: { text: '🐤', key: m.key } }) } catch {}
    }

    const sectionTitle = totalPages > 1 ? `🕸 جميع الأقسام ${current + 1}/${totalPages}` : '🍷 جميع الأقسام'

    await conn.sendButton(m.chat, {
        imageUrl: MAIN_THUMB,
        bodyText: buildMainText(user, total, visible.length),
        footerText: BOT_NAME,
        buttons: [
            {
                name: 'single_select',
                params: {
                    title: 'اخـتـر الـقـسـم',
                    sections: [{ title: sectionTitle, rows }],
                },
            },
            { name: 'cta_url', params: { display_text: 'الــمــطــوࢪ 🕸', url: getDeveloperLink(bot) } },
            { name: 'cta_url', params: { display_text: 'الــقــنــاة 🔗', url: CHANNEL_URL } },
        ],
        mentions: [m.sender],
        contextInfo: channelContext(),
        interactiveConfig: {
            buttons_limits: 5,
            list_title: 'اخـتـر الـقـسـم',
            button_title: 'اخـتـر الـقـسـم',
            canonical_url: CHANNEL_URL,
        },
    }, m)

    // الفيديو الدايري - مرة كل 10 دقايق لكل شات (مع أول صفحة بس)
    if (withAudio) {
        const now = Date.now()
        if (!audioCooldown[m.chat] || now - audioCooldown[m.chat] > AUDIO_COOLDOWN) {
            audioCooldown[m.chat] = now
            try {
                await conn.sendMessage(m.chat, {
                    video: { url: MENU_VIDEO },
                    ptv: true,
                    mimetype: 'video/mp4',
                }, { quoted: m })
            } catch {
                // لو الدايري فشل يبعته فيديو عادي
                try {
                    await conn.sendMessage(m.chat, {
                        video: { url: MENU_VIDEO },
                        mimetype: 'video/mp4',
                        contextInfo: channelContext(),
                    }, { quoted: m })
                } catch {}
            }
        }
    }
}

/* ───────────── أوامر قسم معين ───────────── */
async function sendCategory(m, { conn, bot }, key) {
    const cat = CATEGORIES.find(c => c[2] === key)
    if (!cat) {
        return conn.sendMessage(m.chat, {
            text: '🙂 القسم غير موجود',
            contextInfo: channelContext(),
        }, { quoted: m })
    }
    const [, name, , emoji] = cat

    const { map } = await loadCommands(bot)
    const commands = map[key] || []

    const rowsText = commands.length
        ? commands.map((cmd, i) => `\`𓆩 ${i + 1} 𓆪\` ↫┇•﹝${cmd}﹞•`).join('\n')
        : '`𓆩 - 𓆪` ↫┇•﹝لا توجد أوامر﹞•'

    const text = `${DECORATION}
*مـرحـبا بـك فـي اوامـࢪ الـقـسـم* ⇜  『 ${emoji} ${name} 』
${SEPARATOR}
${rowsText}
${SEPARATOR}
> ${BOT_NAME}
${DECORATION}`

    await conn.sendButton(m.chat, {
        imageUrl: CATEGORY_THUMB,
        bodyText: text,
        footerText: BOT_NAME,
        buttons: [
            { name: 'quick_reply', params: { display_text: '🔙 رجـوع لـلـقـائـمـة', id: `${ID}::menu` } },
        ],
        mentions: [m.sender],
        contextInfo: channelContext(),
        interactiveConfig: {
            buttons_limits: 5,
            list_title: 'قائمة الأوامر',
            button_title: 'رجوع',
            canonical_url: CHANNEL_URL,
        },
    }, m)
}

/* ───────────── الأمر الرئيسي ───────────── */
const handler = async (m, { conn, bot, args }) => {
    try {
        // دعم القديم: .اوامر 3  ← يفتح القسم رقم 3
        const num = Number(args?.[0])
        if (args?.[0] && Number.isInteger(num)) {
            const cat = CATEGORIES.find(c => c[0] === num)
            return await sendCategory(m, { conn, bot }, cat ? cat[2] : '')
        }
        await sendMainMenu(m, { conn, bot })
    } catch (e) {
        console.error('[Menu] Error:', e)
        await conn.sendMessage(m.chat, {
            text: `${DECORATION}\n❌ حدث خطأ: ${e.message}\n${DECORATION}`,
            contextInfo: channelContext(),
        }, { quoted: m })
    }
}

/* ───────────── التعامل مع الأزرار والقايمة ───────────── */
handler.before = async (m, { conn, bot }) => {
    const id = getMenuId(m)
    if (!id) return false

    const [, action, value] = id.split('::')
    try {
        if (action === 'menu') {
            await sendMainMenu(m, { conn, bot }, 0, false)
        } else if (action === 'page') {
            await sendMainMenu(m, { conn, bot }, Number(value), false)
        } else if (action === 'cat') {
            await sendCategory(m, { conn, bot }, value)
        } else {
            return false
        }
    } catch (e) {
        console.error('[Menu] Error:', e)
        await conn.sendMessage(m.chat, {
            text: `${DECORATION}\n❌ حدث خطأ: ${e.message}\n${DECORATION}`,
            contextInfo: channelContext(),
        }, { quoted: m })
    }
    return true
}

handler.help = ['menu']
handler.category = 'main'
handler.usage = ['.منيو', '.اوامر', '.قائمة']
handler.command = ['الاوامر', 'menu', 'اوامر', 'القائمة', 'منيو', 'قائمة', 'بوت']

export default handler