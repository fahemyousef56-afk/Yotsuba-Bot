const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

const handler = async (m, { conn, bot }) => {
    // رد برسالة متحوّلة من القناة
    const send = (body) =>
        conn.sendMessage(
            m.chat,
            { text: body, contextInfo: channelContext() },
            { quoted: m }
        );

    if (!String(m.chat).endsWith('@g.us')) return send('*❌ الأمر ده بيشتغل في الجروبات بس*');

    try {
        const meta = await conn.groupMetadata(m.chat);
        const participants = meta.participants || [];
        const idsOf = (p) => [p.id, p.jid, p.phoneNumber].filter(Boolean).map(numOf);

        // صلاحيات مرسل الأمر
        const owners = bot?.config?.owners || [];
        const isOwner = m.isOwner || owners.some(o => m.sender === o.jid || m.sender === o.lid);
        const senderNum = numOf(m.sender);
        const isAdmin = participants.some(p => p.admin && idsOf(p).includes(senderNum));

        if (!isOwner && !isAdmin) return send('*❌ الأمر ده للمشرفين فقط*');

        // هل البوت ادمن؟
        const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);
        const botIsAdmin = participants.some(p => p.admin && idsOf(p).some(n => botNums.includes(n)));
        if (!botIsAdmin) return send('*❌ لازم البوت يكون ادمن*');

        // القائمة المحفوظة من أمر كشف_البوتات
        const bots = global.detectedBots?.[m.chat];
        if (!bots?.length) return send('*❌ مفيش بوتات محفوظة، اكتب .كشف_البوتات الأول*');

        await send(`*⚡ جاري طرد ${bots.length} بوت...*`);

        let kicked = 0;
        for (const jid of bots) {
            try {
                await conn.groupParticipantsUpdate(m.chat, [jid], 'remove');
                kicked++;
                await new Promise(r => setTimeout(r, 600));
            } catch {}
        }

        delete global.detectedBots[m.chat];

        const failed = bots.length - kicked;
        await send(
            `*✅ تم طرد ${kicked} بوت من الجروب*` +
            (failed ? `\n*⚠️ تعذر طرد ${failed}*` : '') +
            `\n\n> _الجروب نظيف دلوقتي 🧹_`
        );
    } catch (e) {
        await send(`*❌ حصل خطأ:* ${String(e.message || e).slice(0, 100)}`);
    }
};

handler.usage = ['طرد_البوتات'];
handler.category = 'owner';
handler.command = ['طرد_البوتات'];
handler.botAdmin = true;
handler.group = true;

export default handler;