// رسالة_مجهولة - إرسال رسالة مجهولة للجروب

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const handler = async (m, { conn, text }) => {
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: '*مثال:* .رسالة_مجهولة نص الرسالة',
            contextInfo: channelContext(),
        }, { quoted: m });
    }

    // امسح رسالة الأمر عشان محدش يعرف مين بعت
    try {
        await conn.sendMessage(m.chat, { delete: m.key });
    } catch {}

    // من غير quoted عشان الرسالة تفضل مجهولة
    await conn.sendMessage(m.chat, {
        text: `👤 *رسالة مجهولة:*\n\n${text}`,
        contextInfo: channelContext(),
    });
};

handler.command  = ['رسالة_مجهولة'];
handler.usage    = ['رسالة_مجهولة'];
handler.admin    = true;
handler.category = 'admins';
export default handler;