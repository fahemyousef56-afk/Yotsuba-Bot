const normalizeJid = (jid = '') => String(jid).split(':')[0];

const isConfiguredOwner = (jid, bot) => {
    const normalized = normalizeJid(jid);
    return Boolean(bot?.config?.owners?.some(owner =>
        normalizeJid(owner.jid) === normalized ||
        normalizeJid(owner.lid) === normalized
    ));
};

const getParticipantId = (participant) =>
    participant?.id || participant?.jid || participant?.phoneNumber;

const handler = async (m, { conn, bot }) => {
    if (!m.isOwner && !m.isAdmin && !isConfiguredOwner(m.sender, bot)) {
        return m.reply('❌ الأمر ده للمشرفين أو المطور فقط.');
    }

    let metadata;
    try {
        metadata = await conn.groupMetadata(m.chat);
    } catch (error) {
        return m.reply(`❌ تعذر قراءة أعضاء الجروب: ${error.message}`);
    }

    const botId = normalizeJid(conn.user?.id || conn.user?.jid);
    const owners = new Set((bot?.config?.owners || []).flatMap(owner => [
        normalizeJid(owner.jid),
        normalizeJid(owner.lid),
    ]).filter(Boolean));

    const targets = (metadata?.participants || [])
        .map(getParticipantId)
        .filter(Boolean)
        .filter(id => {
            const normalized = normalizeJid(id);
            // لا يطرد البوت نفسه أو المطور حتى يظل البوت قابلاً للإدارة.
            return normalized !== botId && !owners.has(normalized);
        });

    if (!targets.length) {
        return m.reply('ℹ️ مفيش أعضاء متاحين للطرد.');
    }

    let removed = 0;
    let failed = 0;

    // تقسيم الطلبات يقلل فشل WhatsApp عند وجود عدد كبير من الأعضاء.
    for (let i = 0; i < targets.length; i += 5) {
        const batch = targets.slice(i, i + 5);
        try {
            await conn.groupParticipantsUpdate(m.chat, batch, 'remove');
            removed += batch.length;
        } catch {
            failed += batch.length;
        }
    }

    return m.reply(
        `✅ تم تنفيذ أمر الزرف.\n` +
        `👥 تمت محاولة إخراج: ${removed} عضو` +
        (failed ? `\n⚠️ تعذر إخراج: ${failed} عضو (غالباً مشرفين أو بسبب صلاحيات واتساب)` : '')
    );
};

handler.command = ['زرف'];
handler.usage = ['زرف'];
handler.category = 'admin';
handler.admin = true;
handler.botAdmin = true;

export default handler;