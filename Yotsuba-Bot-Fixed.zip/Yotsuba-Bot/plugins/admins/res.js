const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
});

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

const handler = async (m, { conn }) => {
  // رد برسالة متحوّلة من القناة
  const send = (body, mentions = []) =>
    conn.sendMessage(
      m.chat,
      { text: body, mentions, contextInfo: channelContext() },
      { quoted: global.reply_status || m }
    );

  try {
    const req = await conn.groupRequestParticipantsList(m.chat);
    if (!req?.length) return send("📭 مفيش ريكوستات");

    // الرقم ممكن يجي في phone_number أو jid حسب نسخة Baileys
    const jids = req
      .map(r => r.phone_number || r.jid)
      .filter(Boolean);

    if (!jids.length) return send("📭 مفيش ريكوستات");

    const text = jids.map((jid, i) => `${i + 1}- @${numOf(jid)}`).join("\n");

    await send(`📥 قائمة الريكوستات (${jids.length}):\n\n${text}`, jids);
  } catch (e) {
    await send(`❌ تعذر جلب الريكوستات: ${String(e.message || e).slice(0, 100)}`);
  }
};

handler.command = ["الريكوستات", "الطلبات"];
handler.usage = ['الريكوستات'];
handler.category = "admins";
handler.admin = true;
handler.botAdmin = true;
handler.group = true;

export default handler;