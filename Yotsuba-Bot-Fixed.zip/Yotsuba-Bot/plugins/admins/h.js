const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelInfo = () => ({
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
});

const h = async (m, { text, bot, conn }) => {

    try {
        const { images } = bot.config.info;
        const adReply = {
            title: bot.config.info.nameBot || "WhatsApp Bot",
            body: null,
            thumbnailUrl: images.random(),
            mediaType: 1,
            renderLargerThumbnail: false
        };

        const customText = text || "ﷺ";

        if (!m.quoted) {
            return await conn.sendMessage(m.chat, {
                text: customText,
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 1,
                    forwardedNewsletterMessageInfo: channelInfo(),
                    externalAdReply: adReply
                }
            });
        }

        const groupMetadata = await conn.groupMetadata(m.chat);
        const participants = groupMetadata.participants.map(v => v.id);

        await conn.sendMessage(m.chat, {
            forward: m.quoted.fakeObj(),
            mentions: participants,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 999,
                forwardedNewsletterMessageInfo: channelInfo(),
                externalAdReply: adReply
            }
        });
    } catch (err) {
        await conn.sendMessage(m.chat, {
            text: err.message,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 1,
                forwardedNewsletterMessageInfo: channelInfo()
            }
        }, { quoted: m });
    }
}

h.usage = ["مخفي"]
h.category = "admins";
h.command = ['مخفي', 'h']
h.group = true;
h.admin = true;
h.usePrefix = false

export default h;