// plugins/حذف.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸 ⤾

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DECORATION = '~_✿┉═┉══𐦍༘◞🕸◜༘𐦍═┉═┉═✿_~';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const box = (title, icon, body) => `${DECORATION}

╔═══════ ༺ ${icon} ༻ ═══════╗
     ✦ ${title} ✦
╚═══════ ༺ ${icon} ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
${body}
┗━━━━━━━ ✦ ━━━━━━━┛

${DECORATION}
${EMOJI} *${BOT_NAME}*`;

const handler = async (m, { conn }) => {
    if (!m.quoted) {
        return send(conn, m, box('حَذْفُ رِسَالَةٍ', '🧸', `┃ 🧸 رد على الرسالة يا ذكي
┃ 💡 مثال: رد على رسالة واكتب .حذف`));
    }

    try {
        await m.react?.(EMOJI);

        // حذف الرسالة المردود عليها
        if (typeof m.quoted.delete === 'function') {
            await m.quoted.delete();
        } else {
            // بديل لو الـ base مفيهوش delete جاهزة
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: !!m.quoted.fromMe,
                    id: m.quoted.id,
                    participant: m.quoted.sender
                }
            });
        }

        // حذف رسالة الأمر نفسها عشان الشات يفضل نضيف
        try { await m.delete?.(); } catch {}
    } catch (e) {
        console.error('حذف error:', e);
        await m.react?.('❌');
        await send(conn, m, box('فَشَلَ الْحَذْفُ', '❌', `┃ ❌ تعذر حذف الرسالة
┃ 📌 ${e.message?.slice(0, 100) || 'تأكد إن البوت مشرف'}`));
    }
};

handler.command = ["حذف"];
handler.usage = ['حذف'];
handler.category = "admin";
handler.admin = true;

export default handler;