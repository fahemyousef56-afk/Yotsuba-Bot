/* ───────────── إعدادات عامة ───────────── */
const IMAGE_URL = 'https://i.ibb.co/TqFb5K8r/file-00000000c2188210a01267648b0c57f5.png';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

async function handler(m, { conn, bot, command, args = [] }) {
    const chatId = m.chat;
    const subCmd = args[0]?.toLowerCase();

    // رد برسالة متحوّلة من القناة
    const send = (body) =>
        conn.sendMessage(
            m.chat,
            { text: body, contextInfo: channelContext() },
            { quoted: m }
        );

    const menu = `
╭─┈─┈─┈─⟞🕸️⟝─┈─┈─┈─╮
│ *نظام التفعيل والتشغيل*
│
│ *.تفعيل ايقاف_الترحيب*
│ > البوت هيبطل يرحب بالاعضاء
│
│ *.تفعيل تشغيل_الترحيب*
│ > البوت يرحب بالاعضاء
│
│ *.تفعيل تشغيل_الادمن*
│ > البوت يرد على المشرفين فقط
│
│ *.تفعيل ايقاف_الادمن*
│ > البوت يرد على الجميع
│
│ *.تفعيل مطور_فقط*
│ > البوت يتفاعل مع المطورين فقط
│
│ *.تفعيل مطور_عام*
│ > البوت يتفاعل مع الجميع
│
│ *.تفعيل تشغيل_مضاد_الروابط*
│ > البوت يحذف أي رابط
│
│ *.تفعيل ايقاف_مضاد_الروابط*
│ > البوت مايحذفش الروابط
│
│ *.مضاد البوتات*
│ > طرد الحسابات الآلية من الجروب
│
│ *.تفعيل ايقاف_خاص*
│ > البوت هيشتغل مع المطورين فقط خاص
│
│ *.تفعيل تشغيل_خاص*
│ > البوت هيشتغل مع كله خاص
╰─┈─┈─┈─⟞🕸️⟝─┈─┈─┈─╯
`;

    if (!subCmd) {
        const payload = {
            bodyText: menu,
            footerText: "𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸",
            buttons: [
                { name: "quick_reply", params: { display_text: "🪐 ايقاف التنصيب (البوتات الفرعي)", id: ".تفعيل ايقاف_الفرعي" } },
                { name: "quick_reply", params: { display_text: "🚀 تشغيل التنصيب", id: ".تفعيل تشغيل_الفرعي" } },
                { name: "quick_reply", params: { display_text: "🔇 ايقاف الترحيب", id: ".تفعيل ايقاف_الترحيب" } },
                { name: "quick_reply", params: { display_text: "🔊 تشغيل الترحيب", id: ".تفعيل تشغيل_الترحيب" } },
                { name: "quick_reply", params: { display_text: "👑 تشغيل الادمن", id: ".تفعيل تشغيل_الادمن" } },
                { name: "quick_reply", params: { display_text: "👥 ايقاف الادمن", id: ".تفعيل ايقاف_الادمن" } },
                { name: "quick_reply", params: { display_text: "⭐ مطور فقط", id: ".تفعيل مطور_فقط" } },
                { name: "quick_reply", params: { display_text: "🌍 مطور عام", id: ".تفعيل مطور_عام" } },
                { name: "quick_reply", params: { display_text: "🚫 تشغيل مضاد الروابط", id: ".تفعيل تشغيل_مضاد_الروابط" } },
                { name: "quick_reply", params: { display_text: "✅ ايقاف مضاد الروابط", id: ".تفعيل ايقاف_مضاد_الروابط" } },
                { name: "quick_reply", params: { display_text: "🌟 تشغيل خاص لـ المطورين فقط", id: ".تفعيل ايقاف_خاص" } },
                { name: "quick_reply", params: { display_text: "💔 ايقاف التشغيل خاص لـ المطورين فقط", id: ".تفعيل تشغيل_خاص" } }
            ],
            mentions: [m.sender],
            contextInfo: channelContext(),
            interactiveConfig: {
                buttons_limits: 1, // لازم تبقي واحد
                list_title: "Available Options",
                button_title: "Click Here",
                canonical_url: CHANNEL_LINK
            }
        };

        if (IMAGE_URL) payload.imageUrl = IMAGE_URL;

        await conn.sendButton(m.chat, payload, m);
        return;
    }

    /* ───────────── الصلاحيات ───────────── */
    const owners = bot?.config?.owners || [];
    const isOwner = m.isOwner || owners.some(o => m.sender === o.jid || m.sender === o.lid);

    let isAdmin = !!m.isAdmin;
    const isGroup = String(chatId).endsWith('@g.us');
    if (!isAdmin && isGroup) {
        try {
            const meta = await conn.groupMetadata(chatId);
            const senderNum = numOf(m.sender);
            isAdmin = meta.participants.some(p =>
                p.admin && [p.id, p.jid, p.phoneNumber].filter(Boolean).map(numOf).includes(senderNum)
            );
        } catch {}
    }

    // تأكد إن قاعدة البيانات جاهزة
    if (!global.db) global.db = {};
    if (!global.db.groups) global.db.groups = {};
    if (isGroup && !global.db.groups[chatId]) global.db.groups[chatId] = {};
    const group = global.db.groups[chatId] || {};

    // أوامر الجروب لازم تتنفذ جوه جروب
    const needGroup = () => {
        if (isGroup) return false;
        return '*❌ الأمر ده بيشتغل في الجروبات بس*';
    };

    let result;

    switch (subCmd) {
        case 'ايقاف_الفرعي':
            if (!isOwner) { result = '*❌ الأمر ده بس لـ المطور*'; break; }
            global.db.noSub = true;
            result = '*✅ تم ايقاف تنصيب البوتات الفرعيه*\n> ماحدش هيعرف يستخدم امر تنصيب تاني';
            break;

        case 'تشغيل_الفرعي':
            if (!isOwner) { result = '*❌ الأمر ده بس لـ المطور*'; break; }
            global.db.noSub = false;
            result = '*✅ تم تشغيل تنصيب البوتات الفرعيه*\n> دلوقتي الكل يقدر يستخدم البوتات الفرعيه';
            break;

        case 'ايقاف_الترحيب':
            if (!isOwner && !isAdmin) { result = '*❌ هذا الأمر للمشرفين فقط*'; break; }
            if (needGroup()) { result = needGroup(); break; }
            group.noWelcome = true;
            result = '*✅ تم تفعيل وضع عدم الترحيب*\n> البوت هيبطل يرحب بالاعضاء';
            break;

        case 'تشغيل_الترحيب':
            if (!isOwner && !isAdmin) { result = '*❌ هذا الأمر للمشرفين فقط*'; break; }
            if (needGroup()) { result = needGroup(); break; }
            group.noWelcome = false;
            result = '*✅ تم تفعيل وضع الترحيب*\n> البوت يرحب بالاعضاء';
            break;

        case 'تشغيل_الادمن':
            if (!isOwner && !isAdmin) { result = '*❌ هذا الأمر للمشرفين فقط*'; break; }
            if (needGroup()) { result = needGroup(); break; }
            group.adminOnly = true;
            result = '*✅ تم تفعيل وضع الادمن*\n> البوت سيتفاعل مع المشرفين فقط';
            break;

        case 'ايقاف_الادمن':
            if (!isOwner && !isAdmin) { result = '*❌ هذا الأمر للمشرفين فقط*'; break; }
            if (needGroup()) { result = needGroup(); break; }
            group.adminOnly = false;
            result = '*✅ تم فك وضع الادمن*\n> البوت سيتفاعل مع جميع الأعضاء';
            break;

        case 'مطور_فقط':
            if (!isOwner) { result = '*❌ هذا الأمر للمطور فقط*'; break; }
            global.db.ownerOnly = true;
            result = '*✅ تم تفعيل وضع المطور فقط*\n> البوت سيتفاعل مع المطورين فقط';
            break;

        case 'مطور_عام':
            if (!isOwner) { result = '*❌ هذا الأمر للمطور فقط*'; break; }
            global.db.ownerOnly = false;
            result = '*✅ تم تفعيل وضع المطور العام*\n> البوت سيتفاعل مع الجميع';
            break;

        case 'تشغيل_مضاد_الروابط':
            if (!isOwner && !isAdmin) { result = '*❌ هذا الأمر للمشرفين فقط*'; break; }
            if (needGroup()) { result = needGroup(); break; }
            group.antiLink = true;
            result = '*✅ تم تفعيل مضاد الروابط*\n> البوت هيحذف أي رابط';
            break;

        case 'ايقاف_مضاد_الروابط':
            if (!isOwner && !isAdmin) { result = '*❌ هذا الأمر للمشرفين فقط*'; break; }
            if (needGroup()) { result = needGroup(); break; }
            group.antiLink = false;
            result = '*✅ تم ايقاف مضاد الروابط*\n> البوت مايحذفش الروابط';
            break;

        case 'ايقاف_خاص':
            if (!isOwner) { result = '*❌ هذا الأمر للمطورين فقط*'; break; }
            global.db.dev = true;
            result = '*✅ تم ايقاف الخاص للمستخدمين*\n> فقط المطورين يقدروا يستحدموه خاص';
            break;

        case 'تشغيل_خاص':
            if (!isOwner) { result = '*_❌ هذا الأمر للمطورين فقط ✖️_*'; break; }
            global.db.dev = false;
            result = '*✅ تم تشغيل البوت خاص ل الكل*\n> كله دلوقت يقدر يستخدم البوت خاص';
            break;

        default:
            return send("╭─┈─┈─┈─⟞🕸️⟝─┈─┈─┈─╮\n│ *نظام التفعيل والتشغيل*\n│\n│ 🔇 ايقاف_الترحيب\n│ 🔊 تشغيل_الترحيب\n│ 👑 تشغيل_الادمن\n│ 👥 ايقاف_الادمن\n│ ⭐ مطور_فقط\n│ 🌍 مطور_عام\n│ 🚫 تشغيل_مضاد_الروابط\n│ ✅ ايقاف_مضاد_الروابط\n│ 🪐 ايقاف_الفرعي / تشغيل_الفرعي\n│ 🌟 ايقاف_خاص / تشغيل_خاص\n╰─┈─┈─┈─⟞🕸️⟝─┈─┈─┈─╯");
    }

    if (result) {
        await send(result);
    }
};

handler.usage = ['تفعيل'];
handler.category = 'admin';
handler.command = ['تفعيل'];

export default handler;