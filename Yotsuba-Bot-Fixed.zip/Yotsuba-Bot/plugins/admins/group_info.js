// جروب - معلومات الجروب + إشعارات تغييرات الجروب

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

/* ───────────── أمر معلومات الجروب ───────────── */
const handler = async (m, { conn }) => {
    const send = (body) =>
        conn.sendMessage(
            m.chat,
            { text: body, contextInfo: channelContext() },
            { quoted: m }
        );

    try {
        const meta = await conn.groupMetadata(m.chat);
        const admins = meta.participants.filter(p => p.admin).length;
        const members = meta.participants.length;
        const created = new Date(meta.creation * 1000).toLocaleDateString('ar-EG');

        await send(
            `╭─┈─┈─┈─⟞📋⟝─┈─┈─┈─╮\n` +
            `┃ *معلومات الجروب*\n` +
            `╰─┈─┈─┈─⟞📋⟝─┈─┈─┈─╯\n\n` +
            `📌 *الاسم:* ${meta.subject}\n` +
            `👥 *الأعضاء:* ${members}\n` +
            `👑 *الادمن:* ${admins}\n` +
            `📅 *تاريخ الإنشاء:* ${created}\n` +
            `🔒 *الحالة:* ${meta.announce ? 'مقفل' : 'مفتوح'}\n\n` +
            `📝 *الوصف:*\n${meta.desc || 'لا يوجد وصف'}`
        );
    } catch {
        await send('*❌ تعذر جلب بيانات الجروب*');
    }
};

/* ───────────── إشعارات تغييرات الجروب ─────────────
   بتشتغل على رسائل النظام (stub) اللي واتساب بيبعتها لما حد يغير حاجة في الجروب */

// أنواع التغييرات (رقم أو اسم النوع في Baileys)
const STUB = {
    21: 'subject',      // GROUP_CHANGE_SUBJECT
    22: 'icon',         // GROUP_CHANGE_ICON
    24: 'description',  // GROUP_CHANGE_DESCRIPTION
    25: 'restrict',     // GROUP_CHANGE_RESTRICT (مين يقدر يعدل بيانات الجروب)
    26: 'announce',     // GROUP_CHANGE_ANNOUNCE (مين يقدر يبعت رسائل)
    GROUP_CHANGE_SUBJECT: 'subject',
    GROUP_CHANGE_ICON: 'icon',
    GROUP_CHANGE_DESCRIPTION: 'description',
    GROUP_CHANGE_RESTRICT: 'restrict',
    GROUP_CHANGE_ANNOUNCE: 'announce',
};

if (!global.groupChangeSeen) global.groupChangeSeen = new Set();

handler.before = async (m, { conn }) => {
    try {
        const type = STUB[m?.messageStubType];
        if (!type) return false;
        if (!String(m.chat || '').endsWith('@g.us')) return false;

        // منع تكرار نفس الإشعار
        const id = m.key?.id;
        if (id) {
            if (global.groupChangeSeen.has(id)) return false;
            global.groupChangeSeen.add(id);
            if (global.groupChangeSeen.size > 500) {
                global.groupChangeSeen.delete(global.groupChangeSeen.values().next().value);
            }
        }

        const author = m.sender || m.key?.participant || m.participant;
        const tag = author ? `@${String(author).split('@')[0].split(':')[0]}` : 'أحد الأعضاء';
        const param = m.messageStubParameters?.[0];

        let text;
        switch (type) {
            case 'subject':
                text = `📌 *تم تغيير اسم الجروب*\n\n👤 بواسطة: ${tag}` +
                       (param ? `\n🆕 الاسم الجديد: *${param}*` : '');
                break;
            case 'icon':
                text = `🖼️ *تم تغيير صورة الجروب*\n\n👤 بواسطة: ${tag}`;
                break;
            case 'description':
                text = `📝 *تم تغيير وصف الجروب*\n\n👤 بواسطة: ${tag}`;
                break;
            case 'restrict':
                text = param === 'on'
                    ? `🔒 *تم قفل تعديل بيانات الجروب (للأدمنز فقط)*\n\n👤 بواسطة: ${tag}`
                    : `🔓 *تم فتح تعديل بيانات الجروب للجميع*\n\n👤 بواسطة: ${tag}`;
                break;
            case 'announce':
                text = param === 'on'
                    ? `🔒 *تم قفل الجروب (الأدمنز فقط يرسلون)*\n\n👤 بواسطة: ${tag}`
                    : `🔓 *تم فتح الجروب (الكل يقدر يرسل)*\n\n👤 بواسطة: ${tag}`;
                break;
        }

        await conn.sendMessage(m.chat, {
            text,
            mentions: author ? [author] : [],
            contextInfo: channelContext(),
        });
    } catch (e) {
        console.error('[GroupChange]', e.message);
    }

    // مهم: false عشان باقي الأوامر تكمل شغلها
    return false;
};

handler.command  = ['جروب', 'معلومات_الجروب'];
handler.usage    = ['جروب'];
handler.admin    = true;
handler.category = 'admins';
export default handler;