const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

let control = async (m, { command, text, conn, bot, participants }) => {
    // رد برسالة متحوّلة من القناة
    const reply = (body) =>
        conn.sendMessage(
            m.chat,
            { text: body, contextInfo: channelContext() },
            { quoted: m }
        );

    try {
        const isBotOwner = (userId) => {
            if (!bot.config || !bot.config.owners) return false;
            return bot.config.owners.some(owner =>
                owner.jid === userId || owner.lid === userId
            );
        };

        const getUser = () => {
            if (m.quoted) return m.quoted.sender;
            if (m.mentionedJid && m.mentionedJid.length > 0) return m.mentionedJid[0];
            if (text) return text + "@s.whatsapp.net";
            return null;
        };

        if (command === "ضيف") {
            if (!text) return reply("❌ فين الرقم؟ ✖️");
            if (m.quoted) {
                await conn.groupParticipantsUpdate(m.chat, [m.quoted.sender], 'add');
                return reply("*✅ تمت الإضافة*");
            }
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                await conn.groupParticipantsUpdate(m.chat, [m.mentionedJid[0]], 'add');
                return reply("*✅ تمت الإضافة*");
            }
            await conn.groupParticipantsUpdate(m.chat, [text + "@s.whatsapp.net"], 'add');
            return reply("*✅ تمت الإضافة*");
        }

        if (command === "انطر") {
            let user = getUser();
            if (!user) return reply("❌ منشن أو رد على العضو ✖️");

            if (isBotOwner(user) || user === conn.user.id) {
                await reply("بتهزر ؟");
                return await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            }

            await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
            return reply("✅ تم النطر");
        }

        if (command === "رفع") {
            let user = getUser();
            if (!user) return reply("❌ منشن أو رد على العضو ✖️");
            await conn.groupParticipantsUpdate(m.chat, [user], 'promote');
            return reply("☑️ تم الرفع");
        }

        if (command === "خفض") {
            let user = getUser();
            if (!user) return reply("❌ منشن أو رد على العضو ✖️");
            await conn.groupParticipantsUpdate(m.chat, [user], 'demote');
            return reply("✔️ تم الخفض");
        }

    } catch (error) {
        await reply("❌ " + error.message);
    }
};

control.usage = ['ضيف', 'انطر', 'رفع', 'خفض'];
control.command = ['ضيف', 'انطر', 'رفع', 'خفض'];
control.admin = true;
control.botAdmin = true;
control.category = "admin";
export default control;