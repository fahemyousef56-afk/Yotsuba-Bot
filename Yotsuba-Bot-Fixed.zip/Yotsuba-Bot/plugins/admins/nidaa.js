// نداء - ينادي على عضو داخل الجروب فقط

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const handler = async (m, { conn }) => {
    // رد برسالة متحوّلة من القناة
    const send = (body, mentions = []) =>
        conn.sendMessage(
            m.chat,
            { text: body, mentions, contextInfo: channelContext() },
            { quoted: m }
        );

    if (!String(m.chat).endsWith('@g.us')) return send('*❌ الأمر ده في الجروبات بس*');

    const target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return send('*منشن العضو أو رد على رسالته*');

    // ✅ النداء داخل الجروب بس - مش في الخاص
    return send(
        `📢 *نداء!*\n\n@${String(target).split('@')[0].split(':')[0]} في ناس بيناديك هنا 👋`,
        [target]
    );
};

handler.command  = ['نداء'];
handler.usage    = ['نداء'];
handler.admin    = true;
handler.group    = true;
handler.category = 'admins';
export default handler;