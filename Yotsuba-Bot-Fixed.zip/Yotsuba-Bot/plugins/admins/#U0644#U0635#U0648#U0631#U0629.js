// plugins/لصورة.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸 ⤾

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DECORATION = '~_✿┉═┉══𐦍༘◞🕸◜༘𐦍═┉═┉═✿_~';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const box = (title, icon, body) => `${DECORATION}

╔═══════ ༺ ${icon} ༻ ═══════╗
     ✦ ${title} ✦
╚═══════ ༺ ${icon} ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
${body}
┗━━━━━━━ ✦ ━━━━━━━┛

${DECORATION}
${EMOJI} *${BOT_NAME}*`;

const handler = async (m, { conn }) => {
    if (!m.isGroup) {
        return send(conn, m, box('تـنـبـيـه', '❌', '┃ ❌ هذا الأمر للجروبات فقط'));
    }

    if (!m.isAdmin && !m.isSuperAdmin && !m.isOwner) {
        return send(conn, m, box('تـنـبـيـه', '❌', '┃ ❌ هذا الأمر للمشرفين فقط'));
    }

    // الرد على رسالة، أو الصورة نفسها لو مبعوتة مع الأمر
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || q.mimetype || '';

    if (!/image/.test(mime)) {
        return send(conn, m, box('صُورَةُ الْمَجْمُوعَةِ', '🖼️', `┃ 🖼️ رد على صورة
┃ 💡 مثال: رد على صورة واكتب .لصورة`));
    }

    try {
        await m.react?.(EMOJI);

        const media = await q.download();
        if (!media?.length) throw new Error('تعذر تحميل الصورة');

        await conn.updateProfilePicture(m.chat, media);

        await send(conn, m, box('تَمَّ التَّغْيِيرُ', '✅', `┃ ✅ تم تغيير صورة الجروب
┃ 👤 بواسطة: @${m.sender.split('@')[0]}`), { mentions: [m.sender] });

        await m.react?.('✅');
    } catch (e) {
        console.error('لصورة error:', e);
        await m.react?.('❌');
        await send(conn, m, box('فَشَلَ التَّغْيِيرُ', '❌', `┃ ❌ فشل التغيير
┃ 📌 ${e.message?.slice(0, 100) || 'حاول مرة أخرى'}`));
    }
};

handler.usage = ['لصورة (رد على صورة)'];
handler.category = 'admin';
handler.command = ['لصورة'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;