const CHANNEL_JID = '120363433665479594@newsletter'; // معرف القناة
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';           // اسم القناة

const channelContext = (mentions = []) => ({
    mentionedJid: mentions,
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: 100
    }
});

const isOwner = (userId, bot) => bot.config?.owners?.some(o => o.jid === userId || o.lid === userId);

const handler = async (m, { conn, command, bot }) => {
    let target = m.mentionedJid?.[0];

    if (target && typeof m.lid2jid === 'function') {
        target = await m.lid2jid(target);
    }

    if (!target && m.quoted) {
        if (typeof m.lid2jid === 'function') {
            target = await m.lid2jid(m.quoted.sender);
        } else {
            target = m.quoted.sender;
        }
    }

    if (!target) return m.reply(`*🔇 كتم/فك_كتم @user*\nاو رد على رسالته`);
    if (typeof target !== 'string') return m.reply(`*❌ حدث خطأ في تحديد المستخدم ✖️*`);
    if (isOwner(target, bot)) return m.reply(`*❌ لا يمكن كتم المطور ✖️*`);

    const group = global.db.groups[m.chat] ||= {};
    const muteList = group.mute ||= [];

    const isMuted = muteList.includes(target);

    if (command === "كتم") {
        if (isMuted) {
            await conn.sendMessage(m.chat, {
                text: `*❌ @${target.split('@')[0]} مكتوم*`,
                mentions: [target],
                contextInfo: channelContext([target])
            });
            return;
        }
        muteList.push(target);
        await conn.sendMessage(m.chat, {
            text: `*✅ تم كتم @${target.split('@')[0]}*\n🔒 لن يتمكن من الكلام`,
            mentions: [target],
            contextInfo: channelContext([target])
        });
    } else if (command === "فك_كتم") {
        if (!isMuted) {
            await conn.sendMessage(m.chat, {
                text: `*❌ @${target.split('@')[0]} ليس مكتوماً*`,
                mentions: [target],
                contextInfo: channelContext([target])
            });
            return;
        }
        group.mute = muteList.filter(u => u !== target);
        await conn.sendMessage(m.chat, {
            text: `*✅ تم فك كتم @${target.split('@')[0]}*\n🔓 يمكنه الكلام الآن`,
            mentions: [target],
            contextInfo: channelContext([target])
        });
    }
};

handler.before = async (m, { conn, bot }) => {
    if (!m.isGroup) return;
    if (m.isOwner || m.isAdmin || isOwner(m.sender, bot)) return;

    const muteList = global.db?.groups[m.chat]?.mute;
    if (!muteList || muteList.length === 0) return;

    if (muteList.includes(m.sender)) {
        await conn.sendMessage(m.chat, { delete: m.key });
        return true;
    }
};

handler.command = ["كتم", "فك_كتم"];
handler.admin = true;

export default handler;