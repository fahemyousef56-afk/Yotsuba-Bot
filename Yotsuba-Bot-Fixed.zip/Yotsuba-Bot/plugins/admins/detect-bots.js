const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

// رقم نضيف من أي JID (بيشيل الدومين و الـ device)
const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

const handler = async (m, { conn, bot, command }) => {
    // رد برسالة متحوّلة من القناة
    const send = (body, mentions = []) =>
        conn.sendMessage(
            m.chat,
            { text: body, mentions, contextInfo: channelContext() },
            { quoted: m }
        );

    const owners = bot?.config?.owners || [];
    const isOwnerJid = (jid) => owners.some(o => jid && (jid === o.jid || jid === o.lid));

    if (!String(m.chat).endsWith('@g.us')) return send('*❌ الأمر ده بيشتغل في الجروبات بس*');
    if (!isOwnerJid(m.sender) && !m.isOwner) return send('*❌ الأمر ده للمطورين فقط*');

    /* ───────────── طرد البوتات المكتشفة ───────────── */
    if (command === 'طرد_البوتات') {
        const ids = global.detectedBots?.[m.chat];
        if (!ids?.length) return send('*❌ مفيش قائمة بوتات محفوظة، اكتب .كشف_البوتات الأول*');

        try {
            await conn.groupParticipantsUpdate(m.chat, ids, 'remove');
            delete global.detectedBots[m.chat];
            return send(`*✅ تم طرد ${ids.length} بوت*`);
        } catch (e) {
            return send(`*❌ تعذر الطرد:* ${e.message?.slice(0, 100)}`);
        }
    }

    /* ───────────── كشف البوتات ───────────── */
    await send('*🔍 جاري فحص الجروب...*');

    try {
        const groupMeta = await conn.groupMetadata(m.chat);
        const participants = groupMeta.participants || [];

        // البوتات الفرعية المعروفة
        let subList = [];
        try { subList = global.subBots?.list?.() || []; } catch {}
        const subPhones = subList.filter(b => b.phone).map(b => String(b.phone).replace(/\D/g, ''));

        // أرقام / معرفات البوت الرئيسي
        const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);

        // كل المعرفات الممكنة للعضو (id / jid / phoneNumber)
        const idsOf = (p) => [p.id, p.jid, p.phoneNumber].filter(Boolean);

        const isProtected = (p) => idsOf(p).some(jid => {
            const num = numOf(jid);
            return botNums.includes(num) || subPhones.includes(num) || isOwnerJid(jid);
        });

        const isSub = (p) => idsOf(p).some(jid => subPhones.includes(numOf(jid)));

        // كشف البوت: الـ JID فيه device (رقم:جهاز@s.whatsapp.net)
        const suspectedBots = participants.filter(p => {
            if (isProtected(p)) return false;
            return idsOf(p).some(jid => /^\d+:\d+@/.test(jid));
        });

        const subBotsCount = participants.filter(isSub).length;

        if (!suspectedBots.length) {
            return send(
                `*✅ مفيش بوتات غريبة في الجروب*\n\n` +
                `👥 إجمالي الأعضاء: ${participants.length}\n` +
                `🤖 بوتات فرعية معروفة: ${subBotsCount}`
            );
        }

        const list = suspectedBots.map((p, i) =>
            `${i + 1}. @${numOf(p.id)}${p.admin ? ' 👑 ادمن' : ''}`
        ).join('\n');

        // احفظ القائمة قبل الإرسال عشان طرد_البوتات يلاقيها
        if (!global.detectedBots) global.detectedBots = {};
        global.detectedBots[m.chat] = suspectedBots.map(p => p.id);

        await send(
            `*🤖 نتيجة الفحص*\n\n` +
            `👥 إجمالي الأعضاء: ${participants.length}\n` +
            `✅ بوتات فرعية معروفة: ${subBotsCount}\n` +
            `🚨 بوتات غريبة: ${suspectedBots.length}\n\n` +
            `*القائمة:*\n${list}\n\n` +
            `> اكتب *.طرد_البوتات* عشان تطردهم`,
            suspectedBots.map(p => p.id)
        );

    } catch (e) {
        console.error('[DetectBots]', e);
        await send(`*❌ حصل خطأ:* ${String(e.message || e).slice(0, 100)}`);
    }
};

handler.usage    = ['كشف_البوتات', 'طرد_البوتات'];
handler.category = 'settings';
handler.command  = ['كشف_البوتات', 'طرد_البوتات'];
handler.owner    = true;
handler.group    = true;
export default handler;