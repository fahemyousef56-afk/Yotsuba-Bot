// plugins/لوصف.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸 ⤾

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DECORATION = '~_✿┉═┉══𐦍༘◞🕸◜༘𐦍═┉═┉═✿_~';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const box = (title, icon, body) => `${DECORATION}

╔═══════ ༺ ${icon} ༻ ═══════╗
     ✦ ${title} ✦
╚═══════ ༺ ${icon} ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
${body}
┗━━━━━━━ ✦ ━━━━━━━┛

${DECORATION}
${EMOJI} *${BOT_NAME}*`;

const handler = async (m, { conn, text }) => {
    if (!m.isGroup) {
        return send(conn, m, box('تـنـبـيـه', '❌', '┃ ❌ هذا الأمر للجروبات فقط'));
    }

    if (!m.isAdmin && !m.isSuperAdmin && !m.isOwner) {
        return send(conn, m, box('تـنـبـيـه', '❌', '┃ ❌ هذا الأمر للمشرفين فقط'));
    }

    if (!text?.trim()) {
        return send(conn, m, box('وَصْفُ الْمَجْمُوعَةِ', '📝', `┃ 📝 اكتب الوصف الجديد
┃ 💡 مثال: .لوصف هذا وصف المجموعة`));
    }

    const description = text.trim();

    // واتساب بيسمح بوصف لحد 2048 حرف
    if (description.length > 2048) {
        return send(conn, m, box('تـنـبـيـه', '⚠️', `┃ ⚠️ الوصف طويل جداً
┃ 📏 الحد الأقصى 2048 حرف
┃ 📊 طول وصفك: ${description.length}`));
    }

    try {
        await m.react?.(EMOJI);
        await conn.groupUpdateDescription(m.chat, description);

        await send(conn, m, box('تَمَّ التَّغْيِيرُ', '✅', `┃ ✅ تم تغيير وصف الجروب
┃ 👤 بواسطة: @${m.sender.split('@')[0]}
┃ 📝 الوصف الجديد:
┃ ${description.split('\n').join('\n┃ ')}`), { mentions: [m.sender] });

        await m.react?.('✅');
    } catch (e) {
        console.error('لوصف error:', e);
        await m.react?.('❌');
        await send(conn, m, box('فَشَلَ التَّغْيِيرُ', '❌', `┃ ❌ فشل التغيير
┃ 📌 ${e.message?.slice(0, 100) || 'حاول مرة أخرى'}`));
    }
};

handler.usage = ['لوصف <الوصف الجديد>'];
handler.category = 'admin';
handler.command = ['لوصف'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;