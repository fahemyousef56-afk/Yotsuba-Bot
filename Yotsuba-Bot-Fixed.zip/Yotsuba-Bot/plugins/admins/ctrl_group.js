const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
});

const handler = async (m, { conn, command }) => {
  // رد برسالة متحوّلة من القناة
  const reply = (body) =>
    conn.sendMessage(
      m.chat,
      { text: body, contextInfo: channelContext() },
      { quoted: m }
    );

  if (command === "قفل") {
    await conn.groupSettingUpdate(m.chat, 'announcement');
    await reply('🔒 *تم قفل الشات* 🔒');
  } else if (command === "فتح") {
    await conn.groupSettingUpdate(m.chat, 'not_announcement');
    await reply('🔓 *تم فتح الشات* 🔓');
  }
};

handler.usage = ["قفل", "فتح"];
handler.category = "admin";
handler.command = ["قفل", "فتح"];
handler.admin = true;
handler.botAdmin = true;

export default handler;