const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const handler = async (m, { conn, bot }) => {
    // رد برسالة متحوّلة من القناة
    const send = (body, mentions = []) =>
        conn.sendMessage(
            m.chat,
            { text: body, mentions, contextInfo: channelContext() },
            { quoted: m }
        );

    try {
        const isBotOwner = (id) => bot.config?.owners?.some(o => o.jid === id || o.lid === id);

        const groupData = await conn.groupMetadata(m.chat);
        const admins = groupData.participants.filter(p =>
            p.admin &&
            p.id !== conn.user.id &&
            !isBotOwner(p.id)
        );

        if (!admins.length) return send('*_❌ مفيش ادمنز تقدر تخفضهم ✖️_*');

        await conn.groupParticipantsUpdate(m.chat, admins.map(a => a.id), 'demote');

        const names = admins.map(a => `@${a.id.split('@')[0]}`).join('\n');
        await send(`✅ *تم خفض كل الادمنز* 👇\n\n${names}`, admins.map(a => a.id));

    } catch (e) {
        await send('❌ حصل خطأ: ' + e.message);
    }
};

handler.command = ['تنزيل'];
handler.usage = ['تنزيل'];
handler.category = 'admin';
handler.admin = true;
handler.botAdmin = true;
handler.group = true;

export default handler;
