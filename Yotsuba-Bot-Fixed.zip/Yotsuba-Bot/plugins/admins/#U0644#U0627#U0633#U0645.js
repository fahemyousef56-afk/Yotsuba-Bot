// plugins/لاسم.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸 ⤾

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DECORATION = '~_✿┉═┉══𐦍༘◞🕸◜༘𐦍═┉═┉═✿_~';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const box = (title, icon, body) => `${DECORATION}

╔═══════ ༺ ${icon} ༻ ═══════╗
     ✦ ${title} ✦
╚═══════ ༺ ${icon} ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
${body}
┗━━━━━━━ ✦ ━━━━━━━┛

${DECORATION}
${EMOJI} *${BOT_NAME}*`;

const handler = async (m, { conn, text }) => {
    if (!m.isGroup) {
        return send(conn, m, box('تـنـبـيـه', '❌', '┃ ❌ هذا الأمر للجروبات فقط'));
    }

    if (!m.isAdmin && !m.isSuperAdmin && !m.isOwner) {
        return send(conn, m, box('تـنـبـيـه', '❌', '┃ ❌ هذا الأمر للمشرفين فقط'));
    }

    if (!text?.trim()) {
        return send(conn, m, box('اسْمُ الْمَجْمُوعَةِ', '✏️', `┃ ✏️ اكتب الاسم الجديد
┃ 💡 مثال: .لاسم مجموعة جديدة`));
    }

    const name = text.trim();

    // واتساب بيسمح باسم جروب لحد 100 حرف
    if (name.length > 100) {
        return send(conn, m, box('تـنـبـيـه', '⚠️', `┃ ⚠️ الاسم طويل جداً
┃ 📏 الحد الأقصى 100 حرف
┃ 📊 طول اسمك: ${name.length}`));
    }

    try {
        await m.react?.(EMOJI);

        let oldName = '';
        try {
            oldName = (await conn.groupMetadata(m.chat)).subject;
        } catch {}

        await conn.groupUpdateSubject(m.chat, name);

        await send(conn, m, box('تَمَّ التَّغْيِيرُ', '✅', `┃ ✅ تم تغيير اسم الجروب
${oldName ? `┃ 📛 الاسم القديم: ${oldName}\n` : ''}┃ 🆕 الاسم الجديد: ${name}
┃ 👤 بواسطة: @${m.sender.split('@')[0]}`), { mentions: [m.sender] });

        await m.react?.('✅');
    } catch (e) {
        console.error('لاسم error:', e);
        await m.react?.('❌');
        await send(conn, m, box('فَشَلَ التَّغْيِيرُ', '❌', `┃ ❌ فشل التغيير
┃ 📌 ${e.message?.slice(0, 100) || 'حاول مرة أخرى'}`));
    }
};

handler.usage = ['لاسم <الاسم الجديد>'];
handler.category = 'admin';
handler.command = ['لاسم'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;