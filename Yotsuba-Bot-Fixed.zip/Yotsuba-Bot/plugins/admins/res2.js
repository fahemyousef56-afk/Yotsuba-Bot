const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
});

const handler = async (m, { conn, text }) => {
  // رد برسالة متحوّلة من القناة
  const send = (body) =>
    conn.sendMessage(
      m.chat,
      { text: body, contextInfo: channelContext() },
      { quoted: m }
    );

  try {
    const req = await conn.groupRequestParticipantsList(m.chat);
    if (!req?.length) return send("📭 مفيش ريكوستات");

    // العدد المطلوب: .اقبل_ريكوستات 10  (من غير رقم = الكل)
    const arg = parseInt(String(text ?? m.text ?? '').trim().split(/\s+/).pop());
    const limit = Number.isFinite(arg) && arg > 0 ? arg : req.length;

    const list = req.slice(0, limit);

    let accepted = 0;
    for (const r of list) {
      // الرقم ممكن يجي في phone_number أو jid حسب نسخة Baileys
      const candidates = [r.phone_number, r.jid].filter(Boolean);
      for (const jid of candidates) {
        try {
          await conn.groupRequestParticipantsUpdate(m.chat, [jid], "approve");
          accepted++;
          break;
        } catch {}
      }
      await new Promise(res => setTimeout(res, 400));
    }

    const failed = list.length - accepted;
    await send(
      `✅ تم قبول ${accepted} ريكوست` +
      (failed ? `\n⚠️ تعذر قبول ${failed}` : '')
    );
  } catch (e) {
    await send(`❌ تعذر قبول الريكوستات: ${String(e.message || e).slice(0, 100)}`);
  }
};

handler.command = ["اقبل_ريكوستات", "اقبل_الطلبات"];
handler.usage = ['اقبل_ريكوستات', 'اقبل_الطلبات'];
handler.category = "admins";
handler.admin = true;
handler.botAdmin = true;
handler.group = true;

export default handler;