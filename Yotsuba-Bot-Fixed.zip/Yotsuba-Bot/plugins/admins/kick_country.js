// طرد-دوله - طرد أعضاء من دولة معينة

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const COUNTRY_CODES = {
    'مصر': ['20'], 'السعودية': ['966'], 'الإمارات': ['971'],
    'الكويت': ['965'], 'قطر': ['974'], 'البحرين': ['973'],
    'عمان': ['968'], 'الأردن': ['962'], 'العراق': ['964'],
    'سوريا': ['963'], 'لبنان': ['961'], 'اليمن': ['967'],
    'المغرب': ['212'], 'الجزائر': ['213'], 'تونس': ['216'],
    'ليبيا': ['218'], 'السودان': ['249'], 'الصومال': ['252'],
    'نيجيريا': ['234'], 'روسيا': ['7'], 'ألمانيا': ['49'],
    'فرنسا': ['33'], 'أمريكا': ['1'], 'تركيا': ['90'],
    'إيران': ['98'], 'باكستان': ['92'], 'الهند': ['91'],
};

// توحيد الكتابة: أ/إ/آ → ا ، ة → ه ، ى → ي (عشان "الامارات" و"الإمارات" يشتغلوا)
const norm = (s) => String(s || '')
    .trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/\s+/g, ' ');

const COUNTRY_LOOKUP = Object.fromEntries(
    Object.entries(COUNTRY_CODES).map(([name, codes]) => [norm(name), { name, codes }])
);

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

const handler = async (m, { conn, bot, text }) => {
    // رد برسالة متحوّلة من القناة
    const send = (body) =>
        conn.sendMessage(
            m.chat,
            { text: body, contextInfo: channelContext() },
            { quoted: m }
        );

    if (!text) {
        const list = Object.keys(COUNTRY_CODES).join(' | ');
        return send(`*مثال:* .طرد-دوله نيجيريا\n\n*الدول المتاحة:*\n${list}`);
    }

    const entry = COUNTRY_LOOKUP[norm(text)];
    if (!entry) return send(`*❌ دولة غير معروفة:* ${text.trim()}\n\nاكتب *.طرد-دوله* للقائمة`);

    const { name: country, codes } = entry;

    try {
        const meta = await conn.groupMetadata(m.chat);

        const owners = bot?.config?.owners || [];
        const ownerNums = owners.flatMap(o => [numOf(o.jid), numOf(o.lid)]).filter(Boolean);
        const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);

        let unresolved = 0;

        const toKick = meta.participants.filter(p => {
            if (p.admin) return false;

            // الرقم الحقيقي: phoneNumber / jid لو متاح، أو id لو @s.whatsapp.net
            const phoneJid = [p.phoneNumber, p.jid, p.id].find(j => String(j || '').includes('@s.whatsapp.net'));
            if (!phoneJid) { unresolved++; return false; }   // @lid من غير رقم معروف

            const num = numOf(phoneJid);
            if (botNums.includes(num) || ownerNums.includes(num)) return false;

            return codes.some(code => num.startsWith(code));
        });

        if (!toKick.length) {
            return send(
                `*✅ لا يوجد أعضاء من ${country}*` +
                (unresolved ? `\n\n> _تعذر معرفة رقم ${unresolved} عضو (حسابات مخفية)_` : '')
            );
        }

        await send(`*⏳ جاري طرد ${toKick.length} عضو من ${country}...*`);

        let kicked = 0;
        for (const p of toKick) {
            try {
                await conn.groupParticipantsUpdate(m.chat, [p.id], 'remove');
                kicked++;
                await new Promise(r => setTimeout(r, 500));
            } catch {}
        }

        const failed = toKick.length - kicked;
        await send(
            `✅ *تم طرد ${kicked} عضو من ${country}*` +
            (failed ? `\n⚠️ تعذر طرد ${failed}` : '') +
            (unresolved ? `\n\n> _تعذر معرفة رقم ${unresolved} عضو (حسابات مخفية)_` : '')
        );
    } catch (e) {
        await send(`*❌ خطأ:* ${String(e.message || e).slice(0, 100)}`);
    }
};

handler.command  = ['طرد-دوله', 'طرد_دوله'];
handler.usage    = ['طرد-دوله'];
handler.admin    = true;
handler.botAdmin = true;
handler.group    = true;
handler.category = 'admins';
export default handler;