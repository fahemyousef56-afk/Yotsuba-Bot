// plugins/منشن.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸 ⤾

const EMOJI = '🕸';
const DECORATION = '~_✿┉═┉══𐦍༘◞🕸◜༘𐦍═┉═┉═✿_~';
const DECO_MID = '~✿━━━•﹝🕸﹞•━━━✿~';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const MAX_MEMBERS_SHOWN = 30;

const handler = async (m, { conn, text }) => {
    // ── التأكد من أن الأمر في مجموعة ──────────────────────
    if (!m.isGroup) {
        return send(conn, m, `${DECORATION}\n❌ هذا الأمر للجروبات فقط\n${DECORATION}`);
    }

    // ── التأكد من أن المستخدم مشرف ─────────────────────────
    if (!m.isAdmin && !m.isSuperAdmin && !m.isOwner) {
        return send(conn, m, `${DECORATION}\n❌ هذا الأمر للمشرفين فقط\n${DECORATION}`);
    }

    // ── السبب (اختياري) ─────────────────────────────────────
    const reason = text?.trim() || 'خاص';

    // ── جلب بيانات المجموعة ─────────────────────────────────
    let participants;
    try {
        const metadata = await conn.groupMetadata(m.chat);
        participants = metadata.participants;
    } catch (e) {
        console.error('منشن error:', e);
        return send(conn, m, `${DECORATION}\n❌ تعذر جلب بيانات الجروب\n${DECORATION}`);
    }

    await m.react?.(EMOJI);

    // فصل المالك والمشرفين والأعضاء
    const ownerJid = participants.find(p => p.admin === 'superadmin')?.id || null;
    const groupAdmins = participants.filter(p => p.admin && p.id !== ownerJid).map(p => p.id);
    const groupMembers = participants.filter(p => !p.admin).map(p => p.id);

    // ── قائمة المشرفين ──────────────────────────────────────
    const adminsList = groupAdmins.map(id => `@${id.split('@')[0]}`).join('\n');

    // ── قائمة الأعضاء ───────────────────────────────────────
    let membersList = groupMembers
        .slice(0, MAX_MEMBERS_SHOWN)
        .map(id => `@${id.split('@')[0]}`)
        .join('\n');
    if (groupMembers.length > MAX_MEMBERS_SHOWN) {
        membersList += `\n... و ${groupMembers.length - MAX_MEMBERS_SHOWN} عضو آخر`;
    }

    // ── بناء الرسالة المزخرفة ───────────────────────────────
    const messageText = `${DECORATION}

❀ *مـــنـــشــن جــمــاعــي 🍷*
❀ *الــســبــب*  ⇜  ${reason}
❀ *الــعــدد*  ⇜  ${participants.length} عضو

${DECO_MID}

❀ *الـمـالـڪ* ⇜  『 ${ownerJid ? '@' + ownerJid.split('@')[0] : 'غير معروف'} 』

${DECO_MID}

❀ *الــمــشــرفــيــن* ⤹
${adminsList || 'لا يوجد مشرفين'}

${DECO_MID}

❀ *الاعــضــاء* ⤹
${membersList || 'لا يوجد أعضاء'}

${DECO_MID}

- *تــحــيــات* ⥃ 『   ${BOT_NAME}   』

${DECORATION}`;

    // ── إرسال الرسالة مع منشن الجميع ───────────────────────
    await send(conn, m, messageText, {
        mentions: participants.map(p => p.id)
    });

    await m.react?.('✅');
};

handler.usage = ['جماعي <السبب>', 'منشنهم <السبب>'];
handler.category = 'admin';
handler.command = ['منشن', 'جماعي', 'منشنهم'];
handler.admin = true;
handler.group = true;

export default handler;