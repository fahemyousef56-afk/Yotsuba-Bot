// المتصلين - مين شايف الرسائل

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const handler = async (m, { conn }) => {
    try {
        const meta = await conn.groupMetadata(m.chat);
        const total = meta.participants.length;
        const adminList = meta.participants.filter(p => p.admin);
        const admins = adminList.map(p => `@${p.id.split('@')[0]}`).join(' ');

        await conn.sendMessage(m.chat, {
            text:
                `👥 *معلومات الأعضاء*\n\n` +
                `📊 إجمالي الأعضاء: *${total}*\n` +
                `👑 الادمنية: ${admins || 'لا يوجد'}\n\n` +
                `> _هذه المعلومات لحظية_`,
            mentions: adminList.map(p => p.id),
            contextInfo: channelContext(),
        }, { quoted: m });
    } catch {
        await conn.sendMessage(m.chat, {
            text: '*❌ تعذر جلب البيانات*',
            contextInfo: channelContext(),
        }, { quoted: m });
    }
};

handler.command  = ['المتصلين', 'الاعضاء'];
handler.usage    = ['المتصلين'];
handler.admin    = true;
handler.category = 'admins';
export default handler;
