// قبول / دعوه / تجديد

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const handler = async (m, { conn, command, text }) => {
    // رد برسالة متحوّلة من القناة
    const send = (chat, body, quoted) =>
        conn.sendMessage(
            chat,
            { text: body, contextInfo: channelContext() },
            quoted ? { quoted } : {}
        );
    const reply = (body) => send(m.chat, body, m);

    if (command === 'قبول') {
        // قبول طلبات الانضمام
        try {
            const reqs = await conn.groupRequestParticipantsList(m.chat);
            if (!reqs?.length) return reply('*لا يوجد طلبات انضمام*');
            for (const r of reqs) {
                try { await conn.groupRequestParticipantsUpdate(m.chat, [r.jid], 'approve'); } catch {}
            }
            return reply(`*✅ تم قبول ${reqs.length} طلب انضمام*`);
        } catch {
            return reply('*❌ لا يوجد طلبات انضمام*');
        }
    }

    if (command === 'دعوه') {
        // إرسال دعوة لشخص
        const target = m.mentionedJid?.[0] || (text ? text.trim() + '@s.whatsapp.net' : null);
        if (!target) return reply('*مثال:* .دعوه @شخص');
        try {
            const code = await conn.groupInviteCode(m.chat);
            const link = `https://chat.whatsapp.com/${code}`;
            await send(target, `📨 *دعوة للانضمام*\n\n${link}`);
            return reply('*✅ تم إرسال الدعوة*');
        } catch {
            return reply('*❌ تعذر الإرسال*');
        }
    }

    if (command === 'تجديد') {
        // تجديد رابط الجروب
        try {
            await conn.groupRevokeInvite(m.chat);
            const newCode = await conn.groupInviteCode(m.chat);
            return reply(`🔄 *تم تجديد رابط الجروب*\n\nhttps://chat.whatsapp.com/${newCode}`);
        } catch {
            return reply('*❌ تعذر التجديد*');
        }
    }
};

handler.command  = ['قبول', 'دعوه', 'تجديد'];
handler.usage    = ['قبول', 'دعوه', 'تجديد'];
handler.admin    = true;
handler.botAdmin = true;
handler.category = 'admins';
export default handler;