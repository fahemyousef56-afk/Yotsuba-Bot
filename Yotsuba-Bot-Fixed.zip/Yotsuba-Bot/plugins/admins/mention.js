// منشن الأعضاء - مع rate limit لتجنب spam

const IMAGE_URL = 'https://i.ibb.co/TqFb5K8r/file-00000000c2188210a01267648b0c57f5.png';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const cooldown = new Map();
const COOLDOWN_MS = 60 * 1000; // مرة كل دقيقة بس

const tagOf = (id) => `@${String(id).split('@')[0].split(':')[0]}`;

const handler = async (m, { conn }) => {
    // رد نصي برسالة متحوّلة من القناة
    const send = (body, mentions = []) =>
        conn.sendMessage(
            m.chat,
            { text: body, mentions, contextInfo: channelContext() },
            { quoted: m }
        );

    // رد بصورة + كابشن (للمنشن)
    const sendImage = async (caption, mentions = []) => {
        try {
            return await conn.sendMessage(
                m.chat,
                {
                    image: { url: IMAGE_URL },
                    caption,
                    mentions,
                    contextInfo: { ...channelContext(), mentionedJid: mentions },
                },
                { quoted: m }
            );
        } catch {
            // لو الصورة فشلت ابعت نص عادي
            return send(caption, mentions);
        }
    };

    if (!String(m.chat).endsWith('@g.us')) return send('*❌ الأمر ده في الجروبات بس*');

    // rate limit
    const now = Date.now();
    const last = cooldown.get(m.chat) || 0;
    if (now - last < COOLDOWN_MS) {
        const rem = Math.ceil((COOLDOWN_MS - (now - last)) / 1000);
        return send(`*⏳ انتظر ${rem} ثانية قبل المنشن تاني*`);
    }

    try {
        const metadata = await conn.groupMetadata(m.chat);
        const participants = metadata.participants || [];

        const admins  = participants.filter(p => p.admin).map(p => p.id);
        const members = participants.filter(p => !p.admin).map(p => p.id);

        let text = '';
        text += `🗃️│ الاسم: ${metadata.subject}\n`;
        text += `📯│ التاريخ: ${new Date().toLocaleDateString('ar-EG')}\n\n`;
        text += `👑 *المشرفين (${admins.length})*\n`;
        admins.forEach((id, i) => { text += `🔰│ ${i + 1}. ${tagOf(id)}\n`; });
        text += `\n👥 *الأعضاء (${members.length})*\n`;
        members.forEach((id, i) => { text += `│ ${i + 1}. ${tagOf(id)}\n`; });
        text += `\n> *الإجمالي: ${participants.length}*`;
        text += `\n> ${BOT_NAME}`;

        await sendImage(text, participants.map(p => p.id));

        // سجّل الـ cooldown بعد نجاح الإرسال بس
        cooldown.set(m.chat, now);
    } catch (e) {
        await send(`*❌ خطأ:* ${String(e.message || e).slice(0, 100)}`);
    }
};

handler.usage    = ['منشن'];
handler.category = 'admins';
handler.command  = ['منشن', 'منشنز', 'mention'];
handler.admin    = true;
handler.group    = true;
export default handler;