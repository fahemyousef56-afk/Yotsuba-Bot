import { exec } from "child_process";
import fs from "fs";
import path from "path";
import { promisify } from "util";

const execAsync = promisify(exec);

const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
};

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m });

const toAudio = async (m, { conn }) => {
  let video, audio;

  try {
    if (!m.quoted) {
      return send(conn, m, "*_رد على فيديو عشان أحوله لصوت_*");
    }

    const mime = (m.quoted.msg || m.quoted).mimetype || m.quoted.mediaType || '';
    const isVideo = /video/.test(mime) || /video/i.test(m.quoted.mtype || '');

    if (!isVideo) {
      return send(conn, m, "*⚠️ الرسالة اللي رديت عليها مش فيديو*");
    }

    await m.react?.('🕸');

    const tmp = path.join(process.cwd(), "tmp");
    if (!fs.existsSync(tmp)) fs.mkdirSync(tmp, { recursive: true });

    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    video = path.join(tmp, `${id}.mp4`);
    audio = path.join(tmp, `${id}.mp3`);

    const buffer = await m.quoted.download();
    if (!buffer?.length) throw new Error('تعذر تحميل الفيديو');

    fs.writeFileSync(video, buffer);

    await execAsync(`ffmpeg -i "${video}" -vn -acodec libmp3lame "${audio}" -y`);

    if (!fs.existsSync(audio)) throw new Error('فشل استخراج الصوت (الفيديو ممكن يكون من غير صوت)');

    await conn.sendMessage(m.chat, {
      audio: fs.readFileSync(audio),
      mimetype: "audio/mpeg",
      contextInfo: channelInfo
    }, { quoted: m });
  } catch (e) {
    console.error('toAudio error:', e);
    await send(conn, m, `❌ تعذر التحويل: ${e.message}`);
  } finally {
    for (const file of [video, audio]) {
      try { if (file && fs.existsSync(file)) fs.unlinkSync(file); } catch {}
    }
  }
};

toAudio.usage = ["لصوت"];
toAudio.category = "tools";
toAudio.command = ["لصوت", "tomp3"];
export default toAudio;