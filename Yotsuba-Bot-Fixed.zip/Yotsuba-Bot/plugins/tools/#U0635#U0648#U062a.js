// 🕸 ملف: صوت.js - استخراج الفويس اللي اتبعت مرة واحدة (viewOnce)

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const handler = async (m, { conn }) => {
    try {
        const q = m.quoted;

        // ─── التحقق من وجود رسالة ──────────────────────────
        if (!q) {
            return send(conn, m, `${EMOJI} 📌 *رد على فويس اتبعت مرة واحدة فقط.*`);
        }

        const msg = q.msg || q;
        const mime = msg.mimetype || q.mediaType || '';
        const isViewOnce = q.viewOnce || msg.viewOnce || /viewOnce/i.test(q.mtype || '');
        const isAudio = /audio/.test(mime) || /audio/i.test(q.mtype || '');

        if (!isViewOnce) {
            return send(conn, m, `${EMOJI} ⚠️ *الرسالة دي مش مرة واحدة.*`);
        }

        if (!isAudio) {
            return send(conn, m, `${EMOJI} ⚠️ *الرسالة دي مش فويس.* لو صورة أو فيديو استخدم أمر *فضح*.`);
        }

        // ─── رد فعل مؤقت ──────────────────────────────────
        await conn.sendMessage(m.chat, { react: { text: '👀', key: m.key } });

        // ─── تحميل الفويس ──────────────────────────────────
        const buffer = await q.download();
        if (!buffer?.length) throw new Error('تعذر تحميل الفويس');

        // ─── إرسال الفويس كفويس نوت حقيقي ──────────────────
        await conn.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            contextInfo: channelInfo
        }, { quoted: m });

        await send(conn, m, `${EMOJI} تم استخراج الفويس 👀\n\n> ${BOT_NAME}`);

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error(`${EMOJI} خطأ في أمر صوت:`, error);
        await send(conn, m, `${EMOJI} ❌ *حدث خطأ في تنفيذ الأمر*\n📌 ${error.message || 'يرجى المحاولة مرة أخرى'}`);
    }
};

// ────────────────[إعدادات الأمر]────────────────
handler.usage = ['صوت (رد على فويس مرة واحدة)'];
handler.category = 'media';
handler.command = ['صوت'];
handler.description = '🎙️ استخراج الفويس اللي اتبعت للسماع مرة واحدة';

export default handler;