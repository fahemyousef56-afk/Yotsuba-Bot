// 🍁 ملف: جوده.js - تحسين جودة الصور باستخدام Sharp - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import sharp from 'sharp';
import axios from 'axios';
import https from 'https';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

// ========== تحسين الصورة باستخدام Sharp ==========
async function enhanceImage(imageBuffer) {
    try {
        const image = sharp(imageBuffer);
        const metadata = await image.metadata();

        let width = metadata.width || 800;
        let height = metadata.height || 600;

        if (width < 1920 || height < 1080) {
            const scale = Math.min(1920 / width, 1080 / height);
            width = Math.round(width * scale * 1.5);
            height = Math.round(height * scale * 1.5);
        }

        const enhanced = await image
            .resize(width, height, {
                fit: 'contain',
                background: { r: 255, g: 255, b: 255, alpha: 1 }
            })
            .sharpen({
                sigma: 1.5,
                m1: 1.0,
                m2: 2.0,
                x1: 2.0,
                y2: 10.0,
                y3: 0.0
            })
            .modulate({
                brightness: 1.05,
                saturation: 1.1
            })
            .normalize()
            .withMetadata()
            .jpeg({
                quality: 100,
                progressive: true,
                trellisQuantisation: true,
                overshootDeringing: true,
                optimiseScans: true
            })
            .toBuffer();

        return enhanced;

    } catch (error) {
        console.error(`${EMOJI} خطأ في تحسين الصورة:`, error);
        return imageBuffer;
    }
}

// ────────────────[الأمر الرئيسي]────────────────
const handler = async (m, { conn }) => {
    try {
        const chatId = m.chat;

        // ─── التحقق من وجود صورة ──────────────────────────
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || q.mediaType || "";

        if (!mime) {
            return send(conn, m, `${EMOJI} 📌 *رد على صورة اولاً*\nمثال: رد على صورة ثم اكتب .جودة`);
        }

        if (!/image\/(jpe?g|png|webp)/.test(mime)) {
            return send(conn, m, `${EMOJI} ❌ *صيغة غير مدعومة*\nادعم الصور فقط (jpg, jpeg, png, webp)`);
        }

        // ─── رد فعل مؤقت ──────────────────────────────────
        await conn.sendMessage(chatId, {
            react: { text: '🔄', key: m.key }
        });

        await send(conn, m, `${EMOJI} *🔄 جاري تحسين الصورة إلى FHD...*\n⏳ قد يستغرق 5-10 ثواني`);

        // ─── تحميل الصورة ──────────────────────────────────
        let img = await q.download?.();

        if (typeof img === 'string') {
            const response = await axios.get(img, {
                responseType: 'arraybuffer',
                httpsAgent: new https.Agent({ rejectUnauthorized: false })
            });
            img = Buffer.from(response.data);
        }

        const originalSize = (img.length / 1024).toFixed(2);

        // ─── تحسين الصورة ──────────────────────────────────
        const enhanced = await enhanceImage(img);
        const enhancedSize = (enhanced.length / 1024).toFixed(2);

        const improvement = ((enhanced.length - img.length) / img.length * 100).toFixed(1);
        const status = improvement > 0 ? `✅ تم تحسين الصورة (+${improvement}%)` : '🟡 تم الحفاظ على الجودة';

        // ─── بناء الرسالة ──────────────────────────────────
        const caption = `${EMOJI}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${EMOJI}
    *✨ تَحْسِينُ جَوْدَةِ الصُّورَةِ*
${EMOJI}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${EMOJI}

📊 *الحجم الأصلي:* ${originalSize} KB
📈 *الحجم الجديد:* ${enhancedSize} KB
📌 *الدقة:* FHD (1920×1080)
💡 *الحالة:* ${status}

${EMOJI}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${EMOJI}
🔧 *تم تحسين:*
├ الوضوح (Sharpness)
├ التباين (Contrast)  
├ السطوع (Brightness)
└ الألوان (Saturation)

${EMOJI}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${EMOJI}
${EMOJI} *${BOT_NAME}*
${EMOJI}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${EMOJI}`;

        // ─── إرسال الصورة المحسنة ──────────────────────────
        await conn.sendMessage(chatId, {
            image: enhanced,
            caption: caption,
            contextInfo: channelInfo
        }, { quoted: m });

        await conn.sendMessage(chatId, {
            react: { text: '✅', key: m.key }
        });

    } catch (error) {
        console.error(`${EMOJI} خطأ في تحسين الصورة:`, error);

        // ─── إذا فشل التحسين، نرسل الصورة الأصلية ──────
        try {
            let q = m.quoted ? m.quoted : m;
            let img = await q.download?.();

            if (typeof img === 'string') {
                const response = await axios.get(img, {
                    responseType: 'arraybuffer',
                    httpsAgent: new https.Agent({ rejectUnauthorized: false })
                });
                img = Buffer.from(response.data);
            }

            await conn.sendMessage(m.chat, {
                image: img,
                caption: `${EMOJI} ⚠️ *تعذر تحسين الصورة*\n📌 تم إرسال الصورة الأصلية\n📌 ${error.message || 'يرجى المحاولة مرة أخرى'}`,
                contextInfo: channelInfo
            }, { quoted: m });
        } catch {
            await send(conn, m, `${EMOJI} ❌ *فشل تحسين الصورة*\n📌 ${error.message || 'يرجى المحاولة مرة أخرى'}`);
        }
    }
};

// ────────────────[إعدادات الأمر]────────────────
handler.usage = ['جودة (رد على صورة)'];
handler.category = 'media';
handler.command = ['جودة', 'جوده', 'تحسين', 'hd', 'fhd'];
handler.description = '✨ تحسين جودة الصور إلى FHD باستخدام Sharp';

export default handler;