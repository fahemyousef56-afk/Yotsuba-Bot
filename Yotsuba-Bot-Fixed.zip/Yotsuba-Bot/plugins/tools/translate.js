import fetch from 'node-fetch';

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

async function ترجمة(نص, لغة = 'ar') {
    const url = new URL('https://translate.googleapis.com/translate_a/single');
    url.searchParams.append('client', 'gtx');
    url.searchParams.append('sl', 'auto');
    url.searchParams.append('tl', لغة);
    url.searchParams.append('dt', 't');
    url.searchParams.append('q', نص);

    const res = await fetch(url.href);
    if (!res.ok) throw new Error(`فشل الاتصال بخدمة الترجمة (${res.status})`);
    const json = await res.json();
    if (!json?.[0]) throw new Error('فشل الاتصال بخدمة الترجمة');
    return json[0].map(item => item[0]).join('');
}

const isLangCode = (s) => /^[a-z]{2,3}(-[a-z]{2,4})?$/i.test(s || '');

const handler = async (m, { conn, text, args, command }) => {
    const quotedText = m.quoted?.text || m.quoted?.caption || '';

    // إذا ما في نص وما في رد
    if (!text && !quotedText) {
        return send(conn, m,
            `*🌐 أمر الترجمة*\n\n` +
            `*الاستخدام:*\n` +
            `• .${command} مرحبا ← يترجم للإنجليزي تلقائياً\n` +
            `• .${command} ar Hello ← يترجم للعربي\n` +
            `• .${command} en مرحبا ← يترجم للإنجليزي\n` +
            `• رد على رسالة بـ .${command} ← يترجمها للعربي\n` +
            `• رد على رسالة بـ .${command} en ← يترجمها للإنجليزي\n\n` +
            `*أكواد اللغات الشائعة:*\n` +
            `ar = عربي | en = إنجليزي | fr = فرنسي\n` +
            `es = إسباني | de = ألماني | tr = تركي`
        );
    }

    await m.react?.('⏳');

    try {
        let لغة_مقصودة;
        let نص_للترجمة;

        if (quotedText) {
            // رد على رسالة: ممكن يكون معاه كود لغة أو لأ
            نص_للترجمة = quotedText;
            لغة_مقصودة = isLangCode(args[0]) && args.length === 1 ? args[0].toLowerCase() : 'ar';
        } else if (args.length >= 2 && isLangCode(args[0])) {
            // أول كلمة كود لغة
            لغة_مقصودة = args[0].toLowerCase();
            نص_للترجمة = args.slice(1).join(' ');
        } else {
            // عربي → إنجليزي، وأي لغة تانية → عربي
            نص_للترجمة = text;
            لغة_مقصودة = /[\u0600-\u06FF]/.test(نص_للترجمة) ? 'en' : 'ar';
        }

        const ناتج = await ترجمة(نص_للترجمة, لغة_مقصودة);

        await send(conn, m, `*🌐 الترجمة:*\n\n${ناتج}\n\n> ${BOT_NAME}`);

        await m.react?.('✅');
    } catch (e) {
        console.error('Translate error:', e);
        await m.react?.('❌');
        await send(conn, m, `*❌ فشل الترجمة:* ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ['ترجمة'];
handler.command = ['ترجمة', 'translate', 'tr'];
handler.category = 'tools';

export default handler;