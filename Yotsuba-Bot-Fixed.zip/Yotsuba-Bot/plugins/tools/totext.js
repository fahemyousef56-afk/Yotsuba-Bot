/*
 * 🕸 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸
 * 📢 واتساب : https://whatsapp.com/channel/0029Vb8xTot1t90ks8pCah1O
 * 📨 تيليجرام : https://t.me/+-ZIIcYxN18w4ZGM8
 */

import axios from 'axios';
import FormData from 'form-data';

const OCR_API_KEY = process.env.OCR_API_KEY || '';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

async function استخراج_نص(buffer) {
    if (!OCR_API_KEY) throw new Error('اضبط OCR_API_KEY في أسرار البيئة');
    const form = new FormData();
    form.append('file', buffer, { filename: 'image.jpg' });
    form.append('language', 'ara');
    form.append('isOverlayRequired', 'false');
    form.append('OCREngine', '1');

    const res = await axios.post('https://api8.ocr.space/parse/image', form, {
        headers: {
            ...form.getHeaders(),
            'Apikey': OCR_API_KEY
        },
        timeout: 45000
    });

    if (res.data.IsErroredOnProcessing) {
        const msg = Array.isArray(res.data.ErrorMessage)
            ? res.data.ErrorMessage.join('\n')
            : res.data.ErrorMessage;
        throw new Error(msg || 'خطأ في خدمة الـ OCR');
    }
    const نص = res.data.ParsedResults?.[0]?.ParsedText;
    if (!نص?.trim()) throw new Error('ما قدرت أستخرج نص من الصورة');
    return نص;
}

const handler = async (m, { conn }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!mime.startsWith('image')) {
        return send(conn, m, '*❌ رد على صورة تحتوي على نص عشان أستخرجه*');
    }

    await m.react?.('⏳');
    try {
        const buffer = await q.download();
        if (!buffer?.length) throw new Error('تعذر تحميل الصورة');

        const نص = await استخراج_نص(buffer);

        await send(conn, m, `*📝 النص المستخرج:*\n\n${نص.trim()}\n\n> *${BOT_NAME}*`);

        await m.react?.('✅');
    } catch (e) {
        console.error('OCR error:', e);
        await m.react?.('❌');
        await send(conn, m, `*❌ فشل الاستخراج:* ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ['نص_صورة'];
handler.command = ['نص_صورة', 'totext', 'استخرج_نص'];
handler.category = 'tools';

export default handler;