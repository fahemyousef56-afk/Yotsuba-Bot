// 🕸 ملف: vd.js - استخراج الفيديو اللي اتبعت مرة واحدة (viewOnce)

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const handler = async (m, { conn }) => {
    try {
        const q = m.quoted;

        // ─── التحقق من وجود رسالة ──────────────────────────
        if (!q) {
            return send(conn, m, `${EMOJI} 📌 *رد على فيديو اتبعت مرة واحدة فقط.*`);
        }

        const msg = q.msg || q;
        const mime = msg.mimetype || q.mediaType || '';
        const isViewOnce = q.viewOnce || msg.viewOnce || /viewOnce/i.test(q.mtype || '');
        const isVideo = /video/.test(mime) || /video/i.test(q.mtype || '');

        if (!isViewOnce) {
            return send(conn, m, `${EMOJI} ⚠️ *الرسالة دي مش مرة واحدة.*`);
        }

        if (!isVideo) {
            return send(conn, m, `${EMOJI} ⚠️ *الرسالة دي مش فيديو.* لو صورة استخدم أمر *فضح*، ولو فويس استخدم أمر *صوت*.`);
        }

        // ─── رد فعل مؤقت ──────────────────────────────────
        await conn.sendMessage(m.chat, { react: { text: '👀', key: m.key } });

        // ─── تحميل الفيديو ──────────────────────────────────
        const buffer = await q.download();
        if (!buffer?.length) throw new Error('تعذر تحميل الفيديو');

        const caption = (msg.caption ? `${msg.caption}\n\n` : '') + `${EMOJI} تم استخراج الفيديو 👀\n\n> ${BOT_NAME}`;

        // ─── إرسال الفيديو ──────────────────────────────────
        await conn.sendMessage(m.chat, {
            video: buffer,
            mimetype: 'video/mp4',
            caption,
            contextInfo: channelInfo
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error(`${EMOJI} خطأ في أمر vd:`, error);
        await send(conn, m, `${EMOJI} ❌ *حدث خطأ في تنفيذ الأمر*\n📌 ${error.message || 'يرجى المحاولة مرة أخرى'}`);
    }
};

// ────────────────[إعدادات الأمر]────────────────
handler.usage = ['vd (رد على فيديو مرة واحدة)'];
handler.category = 'media';
handler.command = ['vd'];
handler.description = '🎬 استخراج الفيديو اللي اتبعت للسماع مرة واحدة';

export default handler;