const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const handler = async (m, { conn, text }) => {
    const expr = text?.trim();
    if (!expr) return send(conn, m, '*⚠️ اكتب المعادلة أو العملية الحسابية*\n> مثال: `حاسبة 5*(3+2)^2`\n> أو: `حاسبة sqrt(144)`');

    try {
        if (!/^[0-9+\-*/().%\s^]+$/.test(expr)) {
            throw new Error('unsupported expression');
        }
        const result = Function(`"use strict"; return (${expr.replace(/\^/g, '**')})`)();
        return send(conn, m, `🧮 *${expr}*\n\n= *${result}*`);
    } catch {
        return send(conn, m, '*❌ معادلة غلط أو صيغة مش مفهومة، حاول تاني*');
    }
};

handler.usage    = ['حاسبة'];
handler.category = 'tools';
handler.command  = ['حاسبة'];
handler.cooldown = 1500;

export default handler;