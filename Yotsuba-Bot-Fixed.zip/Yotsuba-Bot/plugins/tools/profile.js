const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
};

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m });

const handler = async (m, { conn, text }) => {
  // 1) منشن  2) رد على رسالة  3) رقم مكتوب  4) صاحب الرسالة نفسه
  let target = m.mentionedJid?.[0] || m.quoted?.sender;

  if (!target && text) {
    const number = text.replace(/[^0-9]/g, '');
    if (number.length >= 7) target = `${number}@s.whatsapp.net`;
  }

  target = target || m.sender;
  const jid = target.includes('@') ? target : `${target}@s.whatsapp.net`;
  const number = jid.split('@')[0];

  try {
    await m.react?.('🕸');

    // الصورة بجودة عالية، ولو مفيش نجرب الصورة المصغرة
    let url = await conn.profilePictureUrl(jid, 'image').catch(() => null);
    if (!url) url = await conn.profilePictureUrl(jid, 'preview').catch(() => null);

    if (!url) {
      return send(conn, m, `🖼️ لا توجد صورة بروفايل عامة لـ @${number}\n\n> ممكن يكون مخفيها أو مفيش عنده صورة.`, {
        mentions: [jid]
      });
    }

    // الحالة (البايو) لو متاحة
    let bio = '';
    try {
      const status = await conn.fetchStatus?.(jid);
      const raw = Array.isArray(status) ? status[0]?.status : status;
      const statusText = raw?.status || raw;
      if (typeof statusText === 'string' && statusText.trim()) {
        bio = `\n📝 *الحالة:* ${statusText.trim()}`;
      }
    } catch {}

    await conn.sendMessage(m.chat, {
      image: { url },
      caption: `👤 *صورة بروفايل* @${number}\n📱 *الرقم:* +${number}${bio}`,
      mentions: [jid],
      contextInfo: { ...channelInfo, mentionedJid: [jid] }
    }, { quoted: m });
  } catch (error) {
    console.error('Profile error:', error);
    await send(conn, m, '❌ تعذر جلب صورة البروفايل حالياً.');
  }
};

handler.command = ['بروفايل', 'profile'];
handler.usage = ['بروفايل @منشن', 'بروفايل (رد على رسالة)', 'بروفايل 201234567890'];
handler.category = 'tools';
export default handler;