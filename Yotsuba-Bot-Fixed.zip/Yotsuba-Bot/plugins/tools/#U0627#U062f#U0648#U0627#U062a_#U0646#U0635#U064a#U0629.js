import axios from 'axios';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const handler = async (m, { conn, command, text }) => {
    if (command === 'حساب_الحروف') {
        if (!text?.trim()) return send(conn, m, '*⚠️ اكتب النص اللي عايز تحسبه*\n> مثال: `حساب_الحروف اهلا بالعالم`');
        const clean = text.trim();
        const chars = [...clean].length;
        const charsNoSpaces = [...clean.replace(/\s/g, '')].length;
        const words = clean.split(/\s+/).filter(Boolean).length;
        return send(conn, m,
            `╭─┈─┈─⟞🔤⟝─┈─┈─╮\n┃ *إحصائيات النص*\n╰─┈─┈─⟞📊⟝─┈─┈─╯\n\n` +
            `┃ 🔠 عدد الحروف (بالمسافات): ${chars}\n` +
            `┃ 🔡 عدد الحروف (من غير مسافات): ${charsNoSpaces}\n` +
            `┃ 📝 عدد الكلمات: ${words}`
        );
    }

    if (command === 'اختصر') {
        const url = text?.trim();
        if (!url || !/^https?:\/\//.test(url)) return send(conn, m, '*⚠️ اكتب رابط صحيح يبدأ بـ http:// أو https://*\n> مثال: `اختصر https://example.com`');
        try {
            const { data } = await axios.get(`https://tinyurl.com/api-create.php`, { params: { url }, timeout: 10000 });
            if (!data || !data.startsWith('http')) return send(conn, m, '*❌ معرفتش أختصر الرابط ده*');
            return send(conn, m, `🔗 *الرابط المختصر:*\n${data}`);
        } catch {
            return send(conn, m, '*❌ حصلت مشكلة أثناء الاختصار، حاول تاني*');
        }
    }

    if (command === 'هيدر') {
        const url = text?.trim();
        if (!url || !/^https?:\/\//.test(url)) return send(conn, m, '*⚠️ اكتب رابط صحيح*\n> مثال: `هيدر https://example.com`');
        try {
            const res = await axios.head(url, { timeout: 10000, validateStatus: () => true });
            const headers = Object.entries(res.headers).slice(0, 15).map(([k, v]) => `*${k}:* ${v}`).join('\n');
            return send(conn, m, `╭─┈─┈─⟞📡⟝─┈─┈─╮\n┃ *Headers*\n╰─┈─┈─⟞🌐⟝─┈─┈─╯\n\n📶 الحالة: ${res.status}\n\n${headers}`);
        } catch {
            return send(conn, m, '*❌ معرفتش أوصل للموقع ده*');
        }
    }
};

handler.usage    = ['حساب_الحروف', 'اختصر', 'هيدر'];
handler.category = 'tools';
handler.command  = ['حساب_الحروف', 'اختصر', 'هيدر'];
handler.cooldown = 2000;

export default handler;