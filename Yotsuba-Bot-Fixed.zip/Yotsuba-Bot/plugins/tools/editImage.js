import fs from 'fs';
import axios from 'axios';
import FormData from 'form-data';
import { uploadToCatbox } from "../../system/utils.js";

// بديل لو Api البوت مش شغال: Gemini لتعديل الصور (محتاج GEMINI_API_KEY في المتغيرات)
async function geminiEdit(buffer, mime, prompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error('GEMINI_API_KEY مش مضبوط');
  const res = await axios.post(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=${encodeURIComponent(key)}`,
    {
      contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: mime, data: buffer.toString('base64') } }] }],
      generationConfig: { responseModalities: ['IMAGE'] },
    },
    { timeout: 120000 }
  );
  const part = res.data?.candidates?.[0]?.content?.parts?.find((p) => p.inlineData || p.inline_data);
  const b64 = (part?.inlineData || part?.inline_data)?.data;
  if (!b64) throw new Error('Gemini مرجعش صورة');
  return Buffer.from(b64, 'base64');
}

// المحاولة الأولى: Api البوت (رفع + انتظار نتيجة). بترجع رابط النتيجة أو null.
async function apiEdit(bot, buffer, prompt) {
  if (typeof bot?.Api?.tools?.editImage !== 'function') return null;
  const imageUrl = await uploadToCatbox(buffer);
  const editRes = await bot.Api.tools.editImage({ imageUrl, prompt });
  if (!editRes?.status || !editRes?.recordId) return null;
  for (let j = 0; j < 30; j++) {
    await new Promise((r) => setTimeout(r, 5000));
    const checkRes = await bot.Api.tools.checkResult({ rid: editRes.recordId });
    if (checkRes?.completed && checkRes?.resultUrl) return checkRes.resultUrl;
  }
  return null;
}

let handler = async (m, { conn, bot, text }) => {
  try {
    if (!m.quoted?.mimetype) return m.reply("*✖️ رد علي الصوره اولاً ✖️*");
    if (!m.quoted.mimetype.startsWith('image/')) return m.reply("*✖️ ده مش ملف صوره ✖️*");
    if (!text) return m.reply("*💬 اكتب التعديل المطلوب *");
    
    await m.react("🔨");

    const buffer = await m.quoted.download();
    await m.reply("*🎨  جاري تعديل الصورة... قد يستغرق هذا دقيقة 🐔*");

    let image = null;
    try {
      const url = await apiEdit(bot, buffer, text);
      if (url) image = { url };
    } catch (e) {
      console.error('Api edit فشل:', e?.message);
    }

    if (!image) {
      try {
        image = await geminiEdit(buffer, m.quoted.mimetype, text);
      } catch (e) {
        console.error('Gemini edit فشل:', e?.message);
      }
    }

    if (!image) {
      await m.react("❌");
      return m.reply("*✖️ فشل تعديل الصورة، خدمة التعديل مش متاحة دلوقتي ✖️*");
    }

    await conn.sendMessage(m.chat, {
      image: Buffer.isBuffer(image) ? image : { url: image.url },
      caption: `✔️ تم التعديل بنجاح\n- *(${text})*`,
    }, { quoted: m });
    await m.react("✅");

  } catch (error) {
    console.error(error);
    return m.reply("*✖️ حدث خطأ أثناء تعديل الصورة ✖️*");
  }
};

handler.usage = ["تعديل"];
handler.command = ["editimage", "تعديل"];
handler.category = "tools";

export default handler;