import { Convert } from "meowsab";

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

let handler = async (m, { conn }) => {
    if (!m.quoted) return send(conn, m, '🎏 رد على الاستيكر ~');

    const mime = (m.quoted.msg || m.quoted).mimetype || m.quoted.mimetype || '';
    if (!/webp/.test(mime)) return send(conn, m, '⚠️ ده مش استيكر');

    try {
        await m.react?.('🕸');

        const buffer = await m.quoted.download();
        if (!buffer?.length) throw new Error('تعذر تحميل الاستيكر');

        const smp4 = await Convert.WebpToMp4(buffer);
        if (!smp4) throw new Error('فشل التحويل لفيديو');

        await conn.sendMessage(m.chat, {
            video: { url: smp4 },
            caption: `> *${BOT_NAME}*`,
            contextInfo: channelInfo
        }, { quoted: m });
    } catch (e) {
        console.error('tovideo error:', e);
        await send(conn, m, `❌ تعذر التحويل: ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ["لفيديو"];
handler.category = "tools";
handler.command = /^(tovideo|tovid|tomp4|لفيديو)$/i;

export default handler;