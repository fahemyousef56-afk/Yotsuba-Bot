import axios from 'axios';
import FormData from 'form-data';

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const makeForm = (field, buffer, اسم_ملف, نوع_mime) => {
    const form = new FormData();
    form.append(field, buffer, {
        filename: اسم_ملف,
        contentType: نوع_mime
    });
    return form;
};

async function رفع_ملف(buffer, اسم_ملف, نوع_mime) {
    // نجرب tmpfiles.org أولاً
    try {
        const form = makeForm('file', buffer, اسم_ملف, نوع_mime);
        const res = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
            headers: form.getHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity
        });
        if (res.data?.data?.url) {
            // تحويل الرابط للتنزيل المباشر
            return res.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
        }
    } catch (e) {
        console.error('tmpfiles error:', e.message);
    }

    // بديل: telegra.ph
    try {
        const form = makeForm('file', buffer, اسم_ملف, نوع_mime);
        const res = await axios.post('https://telegra.ph/upload', form, {
            headers: form.getHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity
        });
        if (res.data?.[0]?.src) {
            return 'https://telegra.ph' + res.data[0].src;
        }
    } catch (e) {
        console.error('telegraph error:', e.message);
    }

    // بديل آخر: qu.ax
    try {
        const form = makeForm('files[]', buffer, اسم_ملف, نوع_mime);
        const res = await axios.post('https://qu.ax/upload.php', form, {
            headers: form.getHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity
        });
        if (res.data?.files?.[0]?.url) return res.data.files[0].url;
    } catch (e) {
        console.error('qu.ax error:', e.message);
    }

    throw new Error('فشل الرفع على كل السيرفرات');
}

const handler = async (m, { conn, text }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!mime) {
        return send(conn, m, '*❌ رد على صورة أو ملف عشان أرفعه وأعطيك رابطه*');
    }

    await m.react?.('⏳');
    try {
        const buffer = await q.download();
        if (!buffer?.length) throw new Error('تعذر تحميل الملف');

        // تحديد نوع الملف
        const ext = mime.split('/').pop()?.split(';')[0] || 'bin';
        const اسم = `file_${Date.now()}.${ext}`;

        const رابط = await رفع_ملف(buffer, اسم, mime);

        await send(conn, m, `✅ *تم رفع الملف بنجاح*\n\n🔗 *الرابط:*\n${رابط}\n\n> الرابط صالح لفترة محدودة\n> ${BOT_NAME}`);

        await m.react?.('✅');
    } catch (e) {
        console.error('Upload error:', e);
        await m.react?.('❌');
        await send(conn, m, `*❌ فشل الرفع:* ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ['لرابط2'];
handler.command = ['لرابط3', 'tourl', 'ارفع_ملف'];
handler.category = 'tools';

export default handler;