import sharp from 'sharp';

const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
};

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m });

const toimg = async (m, { conn }) => {
  try {
    if (!m.quoted) {
      return send(conn, m, "*_رد على ستيكر عشان أحوله لصوره_*");
    }

    const mime = (m.quoted.msg || m.quoted).mimetype || m.quoted.mediaType || '';
    const isSticker = /webp/.test(mime) || m.quoted.mtype === 'stickerMessage';

    if (!isSticker) {
      return send(conn, m, "*⚠️ الرسالة اللي رديت عليها مش ستيكر*");
    }

    const buffer = await m.quoted.download();
    if (!buffer?.length) throw new Error('تعذر تحميل الستيكر');

    const isAnimated = (m.quoted.msg || m.quoted).isAnimated;

    if (isAnimated) {
      // الستيكر المتحرك: يتبعت كفيديو/جيف (لو الـ base بتاعك مش بيدعم التحويل، هيتبعت كستيكر متحرك)
      await conn.sendMessage(m.chat, {
        video: buffer,
        gifPlayback: true,
        contextInfo: channelInfo
      }, { quoted: m });
      return;
    }

    // الستيكر الثابت: تحويل WebP إلى PNG
    const png = await sharp(buffer).png().toBuffer();

    await conn.sendMessage(m.chat, {
      image: png,
      caption: '🕸 تم التحويل لصورة',
      contextInfo: channelInfo
    }, { quoted: m });
  } catch (e) {
    console.error('toimg error:', e);
    await send(conn, m, `❌ تعذر التحويل: ${e.message}`);
  }
};

toimg.usage = ["لصوره"];
toimg.category = "tools";
toimg.command = ["لصوره", "toimage", "toimg"];
export default toimg;