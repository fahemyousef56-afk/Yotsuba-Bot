// كود الإبلاغ الجماعي عن الأرقام من البوت الرئيسي وجميع البوتات الفرعية
//حقوق yorha تعديل 个𝐘.𝐓.𝐑 𝐃𝐄𝐕个

const handler = async (m, { conn, text }) => {
    if (!text) {
        return m.reply(
            '🚨 *نظام الإبلاغ الجماعي*\n\n' +
            '📌 *الاستخدام:*\n' +
            '• `.ابلاغ <رقم>` - إبلاغ عن رقم من البوت وجميع البوتات الفرعية\n\n' +
            '📌 *مثال:*\n' +
            '`.ابلاغ 201234567890`'
        )
    }

    const phone = text.replace(/[^0-9]/g, '')
    if (phone.length < 10) {
        return m.reply('❌ *رقم غير صحيح*\nيرجى إدخال رقم صحيح')
    }

    const jid = `${phone}@s.whatsapp.net`
    await m.react('⏳')
    await m.reply(`🚨 جاري الإبلاغ عن الرقم ${phone} من جميع البوتات...`)

    try {
        let results = []
        let success = 0
        let failed = 0

        // إبلاغ من البوت الرئيسي
        try {
            const mainResult = await conn.query({
                tag: 'iq',
                attrs: {
                    id: conn.generateMessageTag(),
                    type: 'set',
                    to: 's.whatsapp.net',
                    xmlns: 'spam'
                },
                content: [
                    {
                        tag: 'spam_list',
                        attrs: {
                            jid: jid,
                            spam_flow: 'account_info_report'
                        }
                    }
                ]
            })

            if (mainResult) {
                results.push({ bot: 'الرئيسي', success: true })
                success++
            } else {
                results.push({ bot: 'الرئيسي', success: false, error: 'فشل الإبلاغ' })
                failed++
            }
        } catch (error) {
            results.push({ bot: 'الرئيسي', success: false, error: error.message })
            failed++
        }

        // إبلاغ من البوتات الفرعية
        if (Array.isArray(global.conns)) {
            let botCount = 0
            for (const bot of global.conns) {
                botCount++
                try {
                    const result = await bot.query({
                        tag: 'iq',
                        attrs: {
                            id: bot.generateMessageTag(),
                            type: 'set',
                            to: 's.whatsapp.net',
                            xmlns: 'spam'
                        },
                        content: [
                            {
                                tag: 'spam_list',
                                attrs: {
                                    jid: jid,
                                    spam_flow: 'account_info_report'
                                }
                            }
                        ]
                    })

                    const botId = bot.user?.id?.split(':')[0] || `فرعي ${botCount}`
                    if (result) {
                        results.push({ bot: botId, success: true })
                        success++
                    } else {
                        results.push({ bot: botId, success: false, error: 'فشل الإبلاغ' })
                        failed++
                    }
                } catch (error) {
                    const botId = bot.user?.id?.split(':')[0] || `فرعي ${botCount}`
                    results.push({ bot: botId, success: false, error: error.message })
                    failed++
                }
            }
        }

        // بناء رسالة النتيجة
        let msg = '🚨 *نتائج الإبلاغ الجماعي*\n\n'
        msg += `📞 *الرقم:* ${phone}\n`
        msg += `📊 *عدد البوتات:* ${results.length}\n`
        msg += `✅ *نجح:* ${success}\n`
        msg += `❌ *فشل:* ${failed}\n\n`
        msg += `📋 *التفاصيل:*\n`

        results.forEach((res, i) => {
            const status = res.success ? '✅' : '❌'
            msg += `${status} البوت ${i + 1}: ${res.bot}\n`
        })

        await m.reply(msg)
        await m.react(success > 0 ? '✅' : '❌')

    } catch (error) {
        await m.react('❌')
        await m.reply(`❌ *فشل الإبلاغ:* ${error.message}`)
    }
}

handler.command = ['بلاغ_رقم', 'report']

export default handler