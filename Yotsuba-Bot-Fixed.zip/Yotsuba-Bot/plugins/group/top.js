const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

// شريط النسبة: ▰▰▰▰▰▱▱▱▱▱
const bar = (p) => {
    const filled = Math.min(10, Math.round(p / 10));
    return '▰'.repeat(filled) + '▱'.repeat(10 - filled);
};

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// نطاق النسبة لكل مركز (الأول الأعلى)
const RANGES = [
    [90, 100],
    [80, 95],
    [70, 85],
    [60, 75],
    [50, 65]
];

const MEDALS = ['🥇', '🥈', '🥉'];
const EMOJIS = ['😂', '🤬', '🙂', '😎'];

// خلط عادل (Fisher-Yates) بدل sort العشوائي
const shuffle = (arr) => {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
};

const handler = async (m, { conn, args }) => {
    if (!m.chat?.endsWith('@g.us')) {
        return send(conn, m, '*⚠️ الأمر ده يشتغل جوه الجروبات بس*');
    }

    let participants;
    try {
        const metadata = await conn.groupMetadata(m.chat);
        participants = metadata.participants;
    } catch {
        return send(conn, m, '*❌ تعذر جلب بيانات الجروب*');
    }

    const jids = participants.map(p => p.id);

    if (jids.length < 2) {
        return send(conn, m, `${EMOJI} *المجموعة صغيرة جداً*`);
    }

    const topic = args.join(' ').trim() || 'حاجة غامضة';
    const em = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
    const topUsers = shuffle(jids).slice(0, Math.min(10, jids.length));

    // نسب مرتبة تنازلياً عشان الأول يبقى فعلاً الأعلى
    const percentages = topUsers
        .map((_, i) => {
            const [min, max] = RANGES[i] || [30, 70];
            return rand(min, max);
        })
        .sort((a, b) => b - a);

    const rows = topUsers.map((user, i) => {
        const medal = MEDALS[i] || '👤';
        const p = percentages[i];
        return `┃ ${medal} *${i + 1}.* @${user.split('@')[0]}\n┃    📊 *${p}%*  ${bar(p)}`;
    }).join('\n┃\n');

    const text = `╔═══════ ༺ 🏆 ༻ ═══════╗
     ✦ تـوب ${topUsers.length} ✦
╚═══════ ༺ 🏆 ༻ ═══════╝

${em} *اكـتـر ${topUsers.length} فـي: ${topic}* ${em}

┏━━━━━━━ ✦ ━━━━━━━┓
${rows}
┗━━━━━━━ ✦ ━━━━━━━┛

╭─═━━━━ ❁ ━━━━═─╮
  ❝ ${topUsers.length > 0 ? 'الـنـتـيـجـة نـهـائـيـة ومـفـيـش اسـتـئـنـاف 😂' : ''} ❞
╰─═━━━━ ❁ ━━━━═─╯

${EMOJI} *${BOT_NAME}*`;

    return send(conn, m, text, { mentions: topUsers });
};

handler.usage = ["توب"];
handler.category = "group";
handler.command = ["توب"];

export default handler;