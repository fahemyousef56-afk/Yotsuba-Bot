const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

let handler = async (m, { conn }) => {
    try {
        await m.react?.(EMOJI);

        const metadata = await conn.groupMetadata(m.chat);
        const subject = metadata.subject;
        const code = await conn.groupInviteCode(m.chat);
        const members = metadata.participants?.length || 0;

        const text = `╔═══════ ༺ 🔗 ༻ ═══════╗
     ✦ رَابِطُ الْمَجْمُوعَةِ ✦
╚═══════ ༺ 🔗 ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
┃ 🌸 *الاسم:* ${subject}
┃ 👥 *الأعضاء:* ${members}
┃ 🔗 *الرابط:*
┃ https://chat.whatsapp.com/${code}
┗━━━━━━━ ✦ ━━━━━━━┛

╭─═━━━━ ❁ ━━━━═─╮
  ❝ وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ❞
  ✦ ﴾ سورة المائدة ٢ ﴿ ✦
╰─═━━━━ ❁ ━━━━═─╯

${EMOJI} *${conn.user?.name || BOT_NAME}*`;

        await send(conn, m, text);
        await m.react?.('✅');
    } catch (e) {
        console.error('link error:', e);

        const botJid = conn.user.id.split(':')[0].split('@')[0] + '@s.whatsapp.net';

        await send(conn, m, `╔═══════ ༺ ⚠️ ༻ ═══════╗
     ✦ تَنْبِيهٌ ✦
╚═══════ ༺ ⚠️ ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
┃ 🌷 يـجـب تـعـيـيـن @${botJid.split('@')[0]}
┃ كـمـشـرف لـلـتـمـكـن مـن
┃ اسـتـخـدام هـذا الأمـر!
┗━━━━━━━ ✦ ━━━━━━━┛

${EMOJI} *${BOT_NAME}*`, { mentions: [botJid] });
    }
};

handler.usage = ["لينك"];
handler.category = "group";
handler.command = ["لينك", "link"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;