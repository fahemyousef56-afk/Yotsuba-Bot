const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

// شريط النسبة: ▰▰▰▰▰▱▱▱▱▱
const bar = (p) => {
    const filled = Math.round(p / 10);
    return '▰'.repeat(filled) + '▱'.repeat(10 - filled);
};

const MODES = {
    'بيحبني': {
        icon: '💗',
        title: 'مـيـن بـيـحـبـك',
        headline: 'اكـتـر واحـد بـيـحـبـك يـا قـلـبـي',
        label: 'نـسـبـة حـبـه لـيـك',
        who: '💞 الـعـاشـق',
        outro: '💕',
        comment: (p) => p >= 80 ? 'ده بيموت فيك 😍' : p >= 50 ? 'حب حلو ومحترم 🥰' : 'حب هادي بس صادق 🌸'
    },
    'بيكرهني': {
        icon: '😡',
        title: 'مـيـن بـيـكـرهـك',
        headline: 'اكـتـر واحـد بـيـكـرهـك',
        label: 'نـسـبـة كـرهـه لـيـك',
        who: '😈 الـكـارِه',
        outro: '🌚',
        comment: (p) => p >= 80 ? 'احـذره جامد 😨' : p >= 50 ? 'مش طايقك خالص 😒' : 'كره خفيف ممكن يتصلح 😅'
    },
    'بيكراش': {
        icon: '💘',
        title: 'مـيـن مـعـجـب فـيـك',
        headline: 'اكـتـشـفـت مـيـن مـعـجـب فـيـك',
        label: 'نـسـبـة اعـجـابـه بـيـك',
        who: '😍 الـمـعـجـب',
        outro: '😍',
        comment: (p) => p >= 80 ? 'كراش خطير 🔥' : p >= 50 ? 'معجب بيك بس مكسوف 🙈' : 'إعجاب من بعيد لبعيد 👀'
    }
};

const handler = async (m, { conn, command }) => {
    const mode = MODES[command];
    if (!mode) return;

    if (!m.chat?.endsWith('@g.us')) {
        return send(conn, m, '*⚠️ الأمر ده يشتغل جوه الجروبات بس*');
    }

    let participants;
    try {
        const metadata = await conn.groupMetadata(m.chat);
        participants = metadata.participants;
    } catch {
        return send(conn, m, '*❌ تعذر جلب بيانات الجروب*');
    }

    // استبعاد الشخص نفسه من الاختيار
    const jids = participants.map(p => p.id).filter(id => id !== m.sender);

    if (jids.length < 1) {
        return send(conn, m, `${EMOJI} *المجموعة صغيرة جداً*`);
    }

    const randomUser = jids[Math.floor(Math.random() * jids.length)];
    const percentage = Math.floor(Math.random() * 100) + 1;

    const text = `╔═══════ ༺ ${mode.icon} ༻ ═══════╗
     ✦ ${mode.title} ✦
╚═══════ ༺ ${mode.icon} ༻ ═══════╝

${mode.icon} *${mode.headline}* ${mode.icon}

┏━━━━━━━ ✦ ━━━━━━━┓
┃ ${mode.who}: @${randomUser.split('@')[0]}
┃ 📊 ${mode.label}: *${percentage}%*
┃ ${bar(percentage)}
┗━━━━━━━ ✦ ━━━━━━━┛

╭─═━━━━ ❁ ━━━━═─╮
  ❝ ${mode.comment(percentage)} ❞
╰─═━━━━ ❁ ━━━━═─╯

${mode.outro} ${EMOJI} *${BOT_NAME}*`;

    return send(conn, m, text, { mentions: [randomUser] });
};

handler.usage = ["بيحبني", "بيكرهني", "بيكراش"];
handler.category = "group";
handler.command = ["بيحبني", "بيكرهني", "بيكراش"];

export default handler;