const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const MARRIAGE_IMAGE = 'https://i.ibb.co/QF3tVBXR/file-00000000302c82108c9b9510416a598e.png';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

// شريط النسبة: ▰▰▰▰▰▱▱▱▱▱
const bar = (p) => {
    const filled = Math.round(p / 10);
    return '▰'.repeat(filled) + '▱'.repeat(10 - filled);
};

const comment = (a, b) => {
    const avg = (a + b) / 2;
    if (avg >= 80) return 'حب من أول نظرة 😍🔥';
    if (avg >= 50) return 'ثنائي جميل ربنا يتمم لكم 🥰';
    if (avg >= 30) return 'لسه محتاجين وقت يتعرفوا 🌸';
    return 'جواز صالونات واضح 😂';
};

const handler = async (m, { conn }) => {
    if (!m.chat?.endsWith('@g.us')) {
        return send(conn, m, '*⚠️ الأمر ده يشتغل جوه الجروبات بس*');
    }

    let participants;
    try {
        const metadata = await conn.groupMetadata(m.chat);
        participants = metadata.participants;
    } catch {
        return send(conn, m, '*❌ تعذر جلب بيانات الجروب*');
    }

    const jids = participants.map(p => p.id);

    if (jids.length < 2) {
        return send(conn, m, `${EMOJI} *المجموعة صغيرة جداً*`);
    }

    // اختيار شخصين مختلفين
    const index1 = Math.floor(Math.random() * jids.length);
    let index2;
    do {
        index2 = Math.floor(Math.random() * jids.length);
    } while (index2 === index1);

    const user1 = jids[index1];
    const user2 = jids[index2];
    const num1 = Math.floor(Math.random() * 100) + 1;
    const num2 = Math.floor(Math.random() * 100) + 1;

    const text = `╔═══════ ༺ 💍 ༻ ═══════╗
     ✦ عـقـد قـران ✦
╚═══════ ༺ 💍 ༻ ═══════╝

🥳 *مـبـروك الـزواج تـمـنـي لـكـم كـل خـيـر* 🥳

┏━━━━━━━ ✦ ━━━━━━━┓
┃ 🤵🏻 *الـعـريـس:* @${user1.split('@')[0]}
┃ 😍 *نـسـبـة حـبـه لـلـعـروسـة:* ${num1}%
┃ ${bar(num1)}
┃
┃ 👰🏻‍♀️ *الـعـروسـة:* @${user2.split('@')[0]}
┃ 😍 *نـسـبـة حـبـهـا لـلـعـريـس:* ${num2}%
┃ ${bar(num2)}
┗━━━━━━━ ✦ ━━━━━━━┛

╭─═━━━━ ❁ ━━━━═─╮
  ❝ ${comment(num1, num2)} ❞
╰─═━━━━ ❁ ━━━━═─╯

💐 *بـالـرفـاء والـبـنـيـن* 💐

${EMOJI} *${BOT_NAME}*`;

    // نبعت الصورة مع النص، ولو فشلت الصورة نبعت النص لوحده
    try {
        return await conn.sendMessage(m.chat, {
            image: { url: MARRIAGE_IMAGE },
            caption: text,
            mentions: [user1, user2],
            contextInfo: { ...channelInfo, mentionedJid: [user1, user2] }
        }, { quoted: m });
    } catch (e) {
        console.error('فشل إرسال الصورة:', e?.message);
        return send(conn, m, text, { mentions: [user1, user2] });
    }
};

handler.usage = ["زواج"];
handler.category = "group";
handler.command = ["زواج"];

export default handler;