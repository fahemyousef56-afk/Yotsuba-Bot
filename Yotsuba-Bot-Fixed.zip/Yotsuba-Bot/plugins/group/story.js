const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const frame = (title, icon = '📢') => `╔═══════ ༺ ${icon} ༻ ═══════╗
     ✦ ${title} ✦
╚═══════ ༺ ${icon} ༻ ═══════╝`;

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mimetype || '';
    const sender = `@${m.sender.split('@')[0]}`;

    try {
        // ─── ميديا (صورة / فيديو / صوت) ───────────────────
        if (/image|video|audio/.test(mime)) {
            await m.react?.(EMOJI);

            const media = await q.download();
            if (!media?.length) {
                return send(conn, m, `${EMOJI} ❌ *فشل تحميل الوسائط، حاول مرة أخرى.*`);
            }

            const type = mime.split('/')[0];

            const caption = `${frame('إِعْلَانُ الْمَجْمُوعَةِ')}

${text ? `📝 ${text}\n\n` : ''}┏━━━━━━━ ✦ ━━━━━━━┓
┃ 👤 *الناشر:* ${sender}
┗━━━━━━━ ✦ ━━━━━━━┛

${EMOJI} *${BOT_NAME}*`;

            if (type === 'image') {
                await conn.sendMessage(m.chat, {
                    image: media, caption, mentions: [m.sender], contextInfo: channelInfo
                }, { quoted: m });
            } else if (type === 'video') {
                await conn.sendMessage(m.chat, {
                    video: media, caption, mentions: [m.sender], contextInfo: channelInfo
                }, { quoted: m });
            } else {
                await conn.sendMessage(m.chat, {
                    audio: media, mimetype: mime, ptt: true, contextInfo: channelInfo
                }, { quoted: m });
                if (text) await send(conn, m, caption, { mentions: [m.sender] });
            }

            await m.react?.('✅');
            return;
        }

        // ─── نص فقط ───────────────────────────────────────
        if (text) {
            await m.react?.(EMOJI);

            const body = `${frame('سْتُورِي الْمَجْمُوعَةِ')}

┏━━━━━━━ ✦ ━━━━━━━┓
┃ 📝 ${text}
┗━━━━━━━ ✦ ━━━━━━━┛

╭─═━━━━ ❁ ━━━━═─╮
  ❝ وَقُولُوا لِلنَّاسِ حُسْنًا ❞
  ✦ ﴾ سورة البقرة ٨٣ ﴿ ✦
╰─═━━━━ ❁ ━━━━═─╯

👤 *الناشر:* ${sender}
${EMOJI} *${BOT_NAME}*`;

            await send(conn, m, body, { mentions: [m.sender] });
            await m.react?.('✅');
            return;
        }

        // ─── طريقة الاستخدام ──────────────────────────────
        return send(conn, m, `${frame('طَرِيقَةُ الِاسْتِخْدَامِ', '⚠️')}

┏━━━━━━━ ✦ ━━━━━━━┓
┃ 🖼 *للميديا (صورة/فيديو/صوت):*
┃ رد عليها واكتب *${prefix}${command}*
┃
┃ 📝 *لنشر نص:*
┃ *${prefix}${command} النص هنا*
┗━━━━━━━ ✦ ━━━━━━━┛

${EMOJI} *${BOT_NAME}*`);

    } catch (e) {
        console.error('story error:', e);
        await m.react?.('❌');
        await send(conn, m, `${EMOJI} ❌ *حصل خطأ:* ${e.message?.slice(0, 100) || 'حاول مرة أخرى'}`);
    }
};

handler.help = ['story'];
handler.tags = ['group'];
handler.usage = ['ستوري'];
handler.category = 'group';
handler.command = /^(ستوري|story|حالة|الحاله)$/i;

handler.group = true;
handler.admin = true;

export default handler;