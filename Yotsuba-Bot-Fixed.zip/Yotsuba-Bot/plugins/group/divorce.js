const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const DIVORCE_IMAGE = 'https://i.ibb.co/60H4cYM5/file-0000000072ac8210828dd3443375fc14.png';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const REASONS = [
    'الـخـلاف عـلـى الـريـمـوت 📺',
    'الـغـيـرة مـن كـثـرة الـرسـايـل 📱',
    'الـعـشـا بـرده مـتـأخـر 🍽️',
    'الـسـهـر عـلـى الـجـروب 🌙',
    'عـدم الـرد عـلـى الـمـاسـنـجـر 💬',
    'الـخـلاف عـلـى مـوعـد الـنـوم 😴'
];

const handler = async (m, { conn }) => {
    if (!m.chat?.endsWith('@g.us')) {
        return send(conn, m, '*⚠️ الأمر ده يشتغل جوه الجروبات بس*');
    }

    let participants;
    try {
        const metadata = await conn.groupMetadata(m.chat);
        participants = metadata.participants;
    } catch {
        return send(conn, m, '*❌ تعذر جلب بيانات الجروب*');
    }

    const jids = participants.map(p => p.id);

    if (jids.length < 2) {
        return send(conn, m, `${EMOJI} *المجموعة صغيرة جداً*`);
    }

    // اختيار شخصين مختلفين
    const index1 = Math.floor(Math.random() * jids.length);
    let index2;
    do {
        index2 = Math.floor(Math.random() * jids.length);
    } while (index2 === index1);

    const user1 = jids[index1];
    const user2 = jids[index2];
    const reason = REASONS[Math.floor(Math.random() * REASONS.length)];

    const text = `╔═══════ ༺ ⚖️ ༻ ═══════╗
     ✦ مـحـكـمـة الأسـرة ✦
╚═══════ ༺ ⚖️ ༻ ═══════╝

👨🏻‍⚖️ *مـبـروك الـطـلاق تـمـنـي لـكـم كـل خـيـر* 👩🏻‍⚖️

┏━━━━━━━ ✦ ━━━━━━━┓
┃ 🤵 *الـعـريـس:* @${user1.split('@')[0]}
┃ 👰 *الـعـروسـة:* @${user2.split('@')[0]}
┃ 📜 *الـسـبـب:* ${reason}
┃ 🔨 *الـحـكـم:* طـلاق بـائـن
┗━━━━━━━ ✦ ━━━━━━━┛

╭─═━━━━ ❁ ━━━━═─╮
  ❝ تـعـلـن الـمـحـكـمـة طـلاق
  الـعـريـس مـن الـعـروسـة ❞
╰─═━━━━ ❁ ━━━━═─╯

> *ادفع النفقة بقى ومتنساش النفقة* 😂

${EMOJI} *${BOT_NAME}*`;

    // نبعت الصورة مع النص، ولو فشلت الصورة نبعت النص لوحده
    try {
        return await conn.sendMessage(m.chat, {
            image: { url: DIVORCE_IMAGE },
            caption: text,
            mentions: [user1, user2],
            contextInfo: { ...channelInfo, mentionedJid: [user1, user2] }
        }, { quoted: m });
    } catch (e) {
        console.error('فشل إرسال الصورة:', e?.message);
        return send(conn, m, text, { mentions: [user1, user2] });
    }
};

handler.usage = ["طلاق"];
handler.category = "group";
handler.command = ["طلاق"];

export default handler;