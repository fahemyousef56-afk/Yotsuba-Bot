const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const caption = (title, icon, who) => `╔═══════ ༺ ${icon} ༻ ═══════╗
     ✦ ${title} ✦
╚═══════ ༺ ${icon} ༻ ═══════╝

┏━━━━━━━ ✦ ━━━━━━━┓
┃ ${icon} *${who}*
┃ 💞 تـطـقـيـم حـلـو لـيـكـم
┗━━━━━━━ ✦ ━━━━━━━┛

${EMOJI} *${BOT_NAME}*`;

const handler = async (m, { conn }) => {
    let data;
    try {
        await m.react?.(EMOJI);
        const res = await (await import("meowsab")).Scrapy.Matching();
        // الـ API ممكن يرجّع نص JSON أو كائن جاهز
        const parsed = typeof res === 'string' ? JSON.parse(res) : res;
        data = parsed?.data;
        if (!data?.boy || !data?.girl) throw new Error('بيانات التطقيم ناقصة');
    } catch (e) {
        console.error('matching error:', e);
        return send(conn, m, `${EMOJI} ❌ *تعذر جلب التطقيم حالياً، جرّب تاني بعد لحظة.*`);
    }

    const newsletter = { name: CHANNEL_NAME, jid: CHANNEL_JID };

    try {
        // ─── صورة الولد ─────────────────────────────────
        await conn.sendButtonNormal(m.chat, {
            media: { url: data.boy },
            mediaType: 'image',
            caption: caption('تـطـقـيـم ولاد', '🚹', 'Boy'),
            buttons: [
                { name: "cta_url", params: { display_text: "📎╎ قــنــاتــي ", url: CHANNEL_LINK } }
            ],
            mentions: [m.sender],
            newsletter
        }, global.reply_status);

        // ─── صورة البنت ─────────────────────────────────
        await conn.sendButtonNormal(m.chat, {
            media: { url: data.girl },
            mediaType: 'image',
            caption: caption('تـطـقـيـم بـنـات', '🚺', 'Girl'),
            buttons: [
                { name: "quick_reply", params: { display_text: "▶️ ╎ الـتـالـي ", id: ".تطقيم" } }
            ],
            mentions: [m.sender],
            newsletter
        }, global.reply_status);

        await m.react?.('✅');
    } catch (e) {
        console.error('matching send error:', e);
        // fallback: صور عادية لو الأزرار فشلت
        try {
            await conn.sendMessage(m.chat, {
                image: { url: data.boy },
                caption: caption('تـطـقـيـم ولاد', '🚹', 'Boy'),
                contextInfo: channelInfo
            }, { quoted: m });
            await conn.sendMessage(m.chat, {
                image: { url: data.girl },
                caption: `${caption('تـطـقـيـم بـنـات', '🚺', 'Girl')}\n\n📢 ${CHANNEL_LINK}\n▶️ للتالي اكتب: .تطقيم`,
                contextInfo: channelInfo
            }, { quoted: m });
        } catch (err) {
            console.error('matching fallback error:', err);
            await send(conn, m, `${EMOJI} ❌ *تعذر إرسال الصور.*`);
        }
    }
};

handler.usage = ["تطقيم"];
handler.category = "group";
handler.command = ["ماتشينج", "تطقيم"];

export default handler;