let handler = async (m, { conn }) => {
    await conn.sendMessage(m.chat, {
        image: { url: "https://i.ibb.co/j9VskLBx/IMG-20261025-222953-147.jpg" },
        caption: "🖼️ صورة مباشرة من يوتسوبا"
    }, { quoted: m });
}

handler.command = ["بوم"];
handler.usage     = ['بوم'];
handler.usePrefix = false;

export default handler;
