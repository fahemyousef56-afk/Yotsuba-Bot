const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const getGroupData = (chat) => {
    if (!global.db) return null;
    if (!global.db.groupExtra) global.db.groupExtra = {};
    if (!global.db.groupExtra[chat]) {
        global.db.groupExtra[chat] = { polls: {}, giveaways: {}, attendance: null, slowmode: 0, chatCount: {} };
    }
    return global.db.groupExtra[chat];
};

const isGroupAdmin = (m) => m.isAdmin || m.isSuperAdmin;

const handler = async (m, { conn, command, text }) => {
    if (!m.chat?.endsWith('@g.us')) return send(conn, m, '*⚠️ الأمر ده يشتغل جوه الجروبات بس*');

    const data = getGroupData(m.chat);
    if (!data) return send(conn, m, '*❌ قاعدة البيانات مش متاحة حالياً*');

    // ─── تصويت ──────────────────────────────────────
    if (command === 'تصويت') {
        if (!isGroupAdmin(m)) return send(conn, m, '*❌ للأدمن بس*');
        const parts = (text || '').split('|').map(s => s.trim()).filter(Boolean);
        if (parts.length < 3) return send(conn, m, '*⚠️ الصيغة:*\n`تصويت السؤال | اختيار1 | اختيار2 | ...`');
        const [question, ...options] = parts;
        const pollId = `P${Date.now()}`;
        data.polls[pollId] = { question, options, votes: {} };

        let txt = `╭─┈─┈─⟞🗳️⟝─┈─┈─╮\n┃ *${question}*\n╰─┈─┈─⟞📊⟝─┈─┈─╯\n\n`;
        options.forEach((o, i) => { txt += `${i + 1}. ${o}\n`; });
        txt += `\n> صوّت بكتابة: \`صوت ${pollId} رقم_الاختيار\``;
        return send(conn, m, txt);
    }

    // ─── صوت ────────────────────────────────────────
    if (command === 'صوت') {
        const [pollId, choiceStr] = (text || '').trim().split(/\s+/);
        const poll = data.polls[pollId];
        const choice = parseInt(choiceStr, 10);
        if (!poll || !choice || choice < 1 || choice > poll.options.length) {
            return send(conn, m, '*⚠️ اكتب رقم التصويت والاختيار صح*\n> مثال: `صوت P123 1`');
        }
        poll.votes[m.sender] = choice;
        return send(conn, m, '*✅ اتسجل صوتك*');
    }

    // ─── نتيجة التصويت ──────────────────────────────
    if (command === 'نتيجة_التصويت') {
        const pollId = text?.trim();
        const poll = data.polls[pollId];
        if (!poll) return send(conn, m, '*⚠️ التصويت ده مش موجود*');
        const counts = poll.options.map((_, i) => Object.values(poll.votes).filter(v => v === i + 1).length);
        let txt = `╭─┈─┈─⟞📊⟝─┈─┈─╮\n┃ *${poll.question}*\n╰─┈─┈─⟞🗳️⟝─┈─┈─╯\n\n`;
        poll.options.forEach((o, i) => { txt += `${o}: ${counts[i]} صوت\n`; });
        return send(conn, m, txt);
    }

    // ─── هدية جماعية ────────────────────────────────
    if (command === 'هدية_جماعية') {
        if (!isGroupAdmin(m)) return send(conn, m, '*❌ للأدمن بس*');
        const prize = text?.trim();
        if (!prize) return send(conn, m, '*⚠️ اكتب الجايزة*\n> مثال: `هدية_جماعية اشتراك مميز لمدة شهر`');
        const giveawayId = `G${Date.now()}`;
        data.giveaways[giveawayId] = { prize, participants: [], startedBy: m.sender, active: true };
        return send(conn, m,
            `╭─┈─┈─⟞🎁⟝─┈─┈─╮\n┃ *هدية جماعية جديدة!*\n╰─┈─┈─⟞🎉⟝─┈─┈─╯\n\n` +
            `🏆 الجايزة: ${prize}\n\n` +
            `> شارك بكتابة: \`اشترك ${giveawayId}\`\n` +
            `> الأدمن يقفل السحب بـ: \`اسحب_الفايز ${giveawayId}\``
        );
    }

    // ─── اشترك ──────────────────────────────────────
    if (command === 'اشترك') {
        const gid = text?.trim();
        const giveaway = data.giveaways[gid];
        if (!giveaway || !giveaway.active) return send(conn, m, '*⚠️ الهدية دي مش موجودة أو خلصت*');
        if (giveaway.participants.includes(m.sender)) return send(conn, m, '*✅ انت مشترك بالفعل*');
        giveaway.participants.push(m.sender);
        return send(conn, m, '*🎉 اتسجلت في السحب، بالتوفيق!*');
    }

    // ─── اسحب الفايز ────────────────────────────────
    if (command === 'اسحب_الفايز') {
        if (!isGroupAdmin(m)) return send(conn, m, '*❌ للأدمن بس*');
        const gid = text?.trim();
        const giveaway = data.giveaways[gid];
        if (!giveaway) return send(conn, m, '*⚠️ الهدية دي مش موجودة*');
        if (!giveaway.active) return send(conn, m, '*⚠️ السحب ده اتقفل قبل كده*');
        if (giveaway.participants.length === 0) return send(conn, m, '*😅 محدش اشترك للأسف*');
        const winner = giveaway.participants[Math.floor(Math.random() * giveaway.participants.length)];
        giveaway.active = false;
        return send(conn, m, `🎊 *مبروك! الفايز بـ "${giveaway.prize}" هو:*\n@${winner.split('@')[0]}`, {
            mentions: [winner]
        });
    }

    // ─── تسجيل حضور ─────────────────────────────────
    if (command === 'تسجيل_حضور') {
        if (!isGroupAdmin(m)) return send(conn, m, '*❌ للأدمن بس*');
        data.attendance = { list: [], startedAt: Date.now(), active: true };
        return send(conn, m, '*✅ اتفتح تسجيل الحضور، اكتبوا `حاضر` عشان تتسجلوا*');
    }

    // ─── حاضر ───────────────────────────────────────
    if (command === 'حاضر') {
        if (!data.attendance?.active) return send(conn, m, '*⚠️ مفيش تسجيل حضور مفتوح دلوقتي*');
        if (data.attendance.list.includes(m.sender)) return send(conn, m, '*✅ انت متسجل بالفعل*');
        data.attendance.list.push(m.sender);
        return send(conn, m, '*✅ اتسجل حضورك*');
    }

    // ─── قائمة الحضور ───────────────────────────────
    if (command === 'قائمة_الحضور') {
        if (!data.attendance) return send(conn, m, '*⚠️ مفيش تسجيل حضور حصل لسه*');
        const list = data.attendance.list;
        if (list.length === 0) return send(conn, m, '*📭 لسه محدش سجل حضور*');
        let txt = `╭─┈─┈─⟞📋⟝─┈─┈─╮\n┃ *الحاضرين (${list.length})*\n╰─┈─┈─⟞✅⟝─┈─┈─╯\n\n`;
        list.forEach((j, i) => { txt += `${i + 1}. @${j.split('@')[0]}\n`; });
        return send(conn, m, txt, { mentions: list });
    }

    // ─── الأكثر دردشة ───────────────────────────────
    if (command === 'الأكثر_دردشة') {
        let meta;
        try {
            meta = await conn.groupMetadata(m.chat);
        } catch {
            return send(conn, m, '*❌ تعذر جلب بيانات الجروب*');
        }
        const ranked = meta.participants
            .map(p => ({ jid: p.id, count: Number(global.db?.users?.[p.id]?.msgcount) || 0 }))
            .filter(u => u.count > 0)
            .sort((a, b) => b.count - a.count)
            .slice(0, 10);
        if (ranked.length === 0) return send(conn, m, '*📭 مفيش بيانات كفاية لسه*');
        let txt = `╭─┈─┈─⟞💬⟝─┈─┈─╮\n┃ *الأكثر دردشة في الجروب*\n╰─┈─┈─⟞🏆⟝─┈─┈─╯\n\n`;
        ranked.forEach((u, i) => { txt += `${i + 1}. @${u.jid.split('@')[0]} — ${u.count} رسالة\n`; });
        return send(conn, m, txt, { mentions: ranked.map(u => u.jid) });
    }
};

handler.usage    = ['تصويت', 'صوت', 'نتيجة_التصويت', 'هدية_جماعية', 'اشترك', 'اسحب_الفايز', 'تسجيل_حضور', 'حاضر', 'قائمة_الحضور', 'الأكثر_دردشة'];
handler.category = 'group';
handler.command  = ['تصويت', 'صوت', 'نتيجة_التصويت', 'هدية_جماعية', 'اشترك', 'اسحب_الفايز', 'تسجيل_حضور', 'حاضر', 'قائمة_الحضور', 'الأكثر_دردشة'];
handler.cooldown = 1500;

export default handler;