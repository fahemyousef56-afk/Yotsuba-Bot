// 🕸 ملف: بنج.js - قياس سرعة البوت

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const IMG = 'https://i.ibb.co/wrMj7wNN/IMG-20261025-222748-114.jpg';

const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
};

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m });

const handler = async (m, { conn }) => {
  // قياس الاستجابة الحقيقية: وقت إرسال رسالة واحدة
  const start = process.hrtime.bigint();
  const sent = await send(conn, m, `🏓 ${EMOJI} جاري القياس...`);
  const end = process.hrtime.bigint();
  const ping = Number(end - start) / 1e6;

  const status = ping < 300 ? '🟢 ممتازة' : ping < 800 ? '🟡 متوسطة' : '🔴 بطيئة';

  const text = `╭━━━━━━━━━━━━━━━━━━━╮
   ❖ ⚡ سـرعـة الـبـوت ⚡ ❖
╰━━━━━━━━━━━━━━━━━━━╯

 ┏━━━━━━━━━━━━━━━┓
 ┃ 🏓 الاستجابة ⟵ ${ping.toFixed(2)}ms
 ┃ 📶 الحالة ⟵ ${status}
 ┃ ${EMOJI} ${BOT_NAME}
 ┃ 👨‍💻 ${DEVELOPER}
 ┗━━━━━━━━━━━━━━━┛`;

  try {
    // الطريقة الأصلية (لو الـ base بتاعك بيدعمها)
    if (typeof conn.msgUrl === 'function') {
      await conn.msgUrl(m.chat, text, {
        img: IMG,
        title: '𝐒𝐩𝐞𝐞𝐝 / 𝐓𝐞𝐬𝐭',
        body: '𝐓𝐞𝐬𝐭𝐢𝐧𝐠 𝐭𝐡𝐞 𝐛𝐨𝐭\'𝐬 𝐬𝐩𝐞𝐞𝐝: 𝐈𝐬 𝐢𝐭 𝐟𝐚𝐬𝐭 𝐨𝐫 𝐧𝐨𝐭?',
        big: false
      }, global.reply_status);
      return;
    }
    throw new Error('msgUrl غير متاحة');
  } catch (e) {
    // fallback: رسالة عادية مع بيانات القناة وصورة مصغرة
    await conn.sendMessage(m.chat, {
      text,
      contextInfo: {
        ...channelInfo,
        externalAdReply: {
          title: '𝐒𝐩𝐞𝐞𝐝 / 𝐓𝐞𝐬𝐭',
          body: BOT_NAME,
          thumbnailUrl: IMG,
          sourceUrl: CHANNEL_LINK,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  }
};

handler.command = ["بنج", "ping"];
handler.category = "info";
handler.usage = ["بنج"];
export default handler;