// 🕸 ملف: معلومات.js - عرض معلومات البوت - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import os from 'os';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/j9VskLBx/IMG-20261025-222953-147.jpg';

// 🕸 سياق الرسالة
const getContext = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: 100
    },
    externalAdReply: {
        title: `${EMOJI} ${BOT_NAME}`,
        body: `👑 من تطوير ${DEVELOPER}`,
        thumbnailUrl: img || MAIN_IMAGE,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: true
    }
});

const pad = (n) => String(n).padStart(2, '0');

const handler = async (m, { conn, bot }) => {
    // ✅ معلومات الذاكرة
    const mem = process.memoryUsage();
    const usedRam = (mem.rss / 1024 / 1024).toFixed(1);
    const heapUsed = (mem.heapUsed / 1024 / 1024).toFixed(1);
    const heapTotal = (mem.heapTotal / 1024 / 1024).toFixed(1);
    const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
    const freeRam = (os.freemem() / 1024 / 1024 / 1024).toFixed(1);

    // ✅ معلومات المعالج
    const cpus = os.cpus() || [];
    const cpuCores = cpus.length || 1;
    const cpuModel = cpus[0]?.model || 'Unknown';
    const cpuSpeed = ((cpus[0]?.speed || 0) / 1000).toFixed(1);
    // loadavg مش نسبة مئوية، فبنقسمه على عدد النوى
    const cpuUsage = Math.min(100, (os.loadavg()[0] / cpuCores) * 100).toFixed(1);

    // ✅ معلومات النظام
    const platform = os.platform();
    const arch = os.arch();
    const hostname = os.hostname();

    // ✅ مدة التشغيل
    const uptime = process.uptime();
    const uptimeDays = Math.floor(uptime / 86400);
    const uptimeHours = Math.floor((uptime % 86400) / 3600);
    const uptimeMins = Math.floor((uptime % 3600) / 60);
    const uptimeSecs = Math.floor(uptime % 60);
    const uptimeText = `${uptimeDays ? uptimeDays + ' يوم ' : ''}${pad(uptimeHours)}:${pad(uptimeMins)}:${pad(uptimeSecs)}`;

    // ✅ معلومات المجموعات
    let groupCount = 0;
    try {
        const groups = await conn.groupFetchAllParticipating();
        groupCount = Object.keys(groups).length;
    } catch (e) {
        console.error(`${EMOJI} فشل جلب المجموعات:`, e);
    }

    // ✅ معلومات البوتات الفرعية
    let subList = [];
    try {
        subList = global.subBots?.list?.() || [];
    } catch {}
    const subCount = subList.length;
    const subConnected = subList.filter(b => b.connected).length;

    // ✅ معلومات البوت
    const botName = conn.user?.name || BOT_NAME;
    const botNumber = conn.user?.id?.split(':')[0]?.split('@')[0] || 'غير معروف';

    // ✅ المطورين
    const owners = bot?.config?.owners || [];
    const mainOwner = owners[0] || { name: DEVELOPER, jid: '221774033156@s.whatsapp.net' };

    // ✅ بناء الرسالة
    const msg = `${EMOJI}━━━[ *معلومات البوت* ]━━━${EMOJI}

——> *الـبـوت 🤖*
- *الاسم:* ${botName}
- *الرقم:* wa.me/${botNumber}
- *شغال منذ:* ${uptimeText}

——> *الـنـظـام 💻*
- *النظام:* ${platform} ${arch}
- *الجهاز:* ${hostname}
- *المعالج:* ${cpuModel.slice(0, 30)}...
- *النوى:* ${cpuCores} نواة @ ${cpuSpeed}GHz
- *الحمل:* ${cpuUsage}%

——> *الـذاكـرة 🧠*
- *الرام المستخدم:* ${usedRam}MB / ${totalRam}GB
- *الرام الفارغ:* ${freeRam}GB
- *Heap:* ${heapUsed}MB / ${heapTotal}MB

——> *احـصـائـيـات 📊*
- *المجموعات:* ${groupCount}

——> *الـبـوتـات الـفـرعـيـه 🤖*
- *الإجمالي:* ${subCount}
- *المتصل:* ${subConnected}
- *المنفصل:* ${subCount - subConnected}

——> *الـمـالـكـيـن 👑*
- *العدد:* ${owners.length}
- *الرئيسي:* ${mainOwner.name || DEVELOPER} (${mainOwner.jid?.split('@')[0] || '221774033156'})

${EMOJI} *${BOT_NAME}* | الإصدار 3.0
👨‍💻 *المطور:* ${DEVELOPER}
📢 ${CHANNEL_LINK}`;

    // ✅ إرسال الرسالة
    await conn.sendMessage(m.chat, {
        text: msg,
        contextInfo: getContext(m.sender, MAIN_IMAGE)
    }, { quoted: m });
};

handler.command = ["معلومات", "info", "botinfo", "حالة", "stats"];
handler.category = "info";
handler.usage = ["معلومات"];

export default handler;