// plugins/استوري.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩𝜺𝑻⃝🕸 ⤾

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

const DECORATION = '_~✿━━━•﹝🕸﹞•━━━✿~_';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩𝜺𝑻⃝🕸';
const NEWSLETTER_JID = '120363433665479594@newsletter';
const IMAGE_URL = 'https://i.ibb.co/wrMj7wNN/IMG-20261025-222748-114.jpg';
const RED_COLOR = 0xFFFF0000; 


function buildContext(jid, mentions = []) {
    return {
        mentionedJid: [jid, ...mentions],
        isForwarded: true,
        forwardingScore: 1,
        forwardedNewsletterMessageInfo: {
            newsletterJid: NEWSLETTER_JID,
            newsletterName: BOT_NAME,
            serverMessageId: 0
        }
    };
}

let handler = async (m, { conn, text }) => {
    let q = m.quoted;
    let mime = q ? ((q.msg || q).mimetype || '') : '';
    let isImage = mime.includes('image');
    let isVideo = mime.includes('video');
    let isAudio = mime.includes('audio');
    let isVoice = mime.includes('audio/ogg') || q?.msg?.audioMessage?.ptt;

    
    let postText = text ? text.trim() : '';

    if (!postText && !isImage && !isVideo && !isAudio && !isVoice) {
        return m.reply(`${DECORATION}
🕸 *نـظـام سـتـوࢪي الـجـࢪوب ⤹*

📌 *الاستخدام:*
.استوري <نص>
• رد على صورة/فيديو/صوت +  .استوري

💡 *مثال:*
.استوري مرحباً بالجميع

${DECORATION}`);
    }

    try {
       
        if (isImage || isVideo || isAudio || isVoice) {
            let media = await q.download();
            let mediaType = isImage ? 'image' : isVideo ? 'video' : 'audio';
            let mediaOptions = { [mediaType]: media };
            if (isVoice) mediaOptions = { audio: media, mimetype: 'audio/ogg; codecs=opus', ptt: false };

            let prepared = await prepareWAMessageMedia(mediaOptions, { upload: conn.waUploadToServer });
            let messageKey = isImage ? 'imageMessage' : isVideo ? 'videoMessage' : 'audioMessage';

            const contentMsg = {
                [messageKey]: {
                    ...prepared[messageKey],
                    caption: postText || '',
                    contextInfo: {
                        isGroupStatus: true,
                        pairedMediaType: 'NOT_PAIRED_MEDIA',
                        statusAudienceMetadata: {
                            audienceType: 0 // عام
                        }
                    }
                }
            };

            const webMsg = proto.Message.fromObject(contentMsg);
            const waMsg = generateWAMessageFromContent(m.chat, webMsg, { userJid: conn.user.id, quoted: m });
            await conn.relayMessage(m.chat, waMsg.message, { messageId: waMsg.key.id });
            await m.react('✅');
            return;
        }

        
        const groupMetadata = await conn.groupMetadata(m.chat);
        const statusJidList = groupMetadata.participants.map(p => p.id);

        await conn.relayMessage(m.chat, {
            statusJidList,
            messageContextInfo: {
                messageSecret: Buffer.from(Array(32).fill(0).map(() => Math.floor(Math.random() * 256)))
            },
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: `${DECORATION}\n\n${postText}\n\n${DECORATION}`,
                        thumbnailUrl: IMAGE_URL,
                        textArgb: 0xFFFFFFFF, // أبيض
                        backgroundArgb: RED_COLOR, // أحمر ثابت
                        font: 5,
                        previewType: 0,
                        contextInfo: {
                            statusAttributions: [{ type: 10 }],
                            featureEligibilities: { canBeReshared: true, canReceiveMultiReact: true },
                            statusSourceType: 4,
                            statusAudienceMetadata: {
                                audienceType: 0 // عام
                            }
                        },
                        inviteLinkGroupTypeV2: 0
                    }
                }
            }
        }, {});

        await m.react('✅');
    } catch (e) {
        console.error('❌ خطأ:', e);
        await m.react('❌');
        m.reply(`${DECORATION}\n❌ حدث خطأ: ${e.message}\n${DECORATION}`);
    }
};


handler.help = ['استوري'];
handler.tags = ['admin'];
handler.command = /^(استوري|ستوري)$/i;
handler.group = true;
handler.admin = false;

export default handler;