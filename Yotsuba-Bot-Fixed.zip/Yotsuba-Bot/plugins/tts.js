import { spawn } from 'child_process';

const TTS_ENDPOINT = 'https://translate.google.com/translate_tts';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

// تحويل MP3 إلى OGG/Opus (الصيغة المطلوبة للفويس نوت في واتساب)
const toOpus = (buffer) =>
    new Promise((resolve, reject) => {
        const ff = spawn('ffmpeg', [
            '-i', 'pipe:0',
            '-vn',
            '-c:a', 'libopus',
            '-b:a', '48k',
            '-ar', '48000',
            '-ac', '1',
            '-f', 'ogg',
            'pipe:1'
        ]);

        const chunks = [];
        ff.stdout.on('data', (c) => chunks.push(c));
        ff.stderr.on('data', () => {});
        ff.on('error', reject);
        ff.on('close', (code) => {
            const out = Buffer.concat(chunks);
            if (code === 0 && out.length) resolve(out);
            else reject(new Error(`ffmpeg exited with code ${code}`));
        });

        ff.stdin.on('error', () => {});
        ff.stdin.end(buffer);
    });

const handler = async (m, { conn, text }) => {
    const phrase = String(text || '')
        .replace(/^انطق\s*/i, '')
        .trim();

    if (!phrase) {
        return send(conn, m, '🔊 اكتب الكلام بعد الأمر.\nمثال: .انطق 🤖 معاك');
    }

    if (phrase.length > 200) {
        return send(conn, m, '⚠️ النص طويل. خلي الرسالة أقل من 200 حرف عشان يتحول لفويس.');
    }

    try {
        await m.react('🔊');

        const url = `${TTS_ENDPOINT}?ie=UTF-8&client=tw-ob&tl=ar&q=${encodeURIComponent(phrase)}`;
        const response = await fetch(url, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });

        if (!response.ok) {
            throw new Error(`TTS HTTP ${response.status}`);
        }

        const mp3 = Buffer.from(await response.arrayBuffer());
        if (!mp3.length) throw new Error('empty audio');

        let message;
        try {
            const opus = await toOpus(mp3);
            message = {
                audio: opus,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true,
            };
        } catch (convErr) {
            // لو ffmpeg مش موجود أو فشل: يتبعت كملف صوتي عادي بدل ما يفشل تماماً
            console.error('ffmpeg convert error:', convErr);
            message = {
                audio: mp3,
                mimetype: 'audio/mpeg',
                ptt: false,
                fileName: 'bot-tts.mp3',
            };
        }

        await conn.sendMessage(m.chat, {
            ...message,
            contextInfo: channelInfo,
        }, { quoted: m });
    } catch (error) {
        console.error('TTS error:', error);
        await send(conn, m, '❌ تعذر تحويل النص لفويس حالياً، جرّب تاني بعد لحظة.');
    }
};

handler.command = ['انطق', 'نطق', 'tts'];
handler.usage = ['انطق النص'];
handler.category = 'tools';

export default handler;