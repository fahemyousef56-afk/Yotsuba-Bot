/* 
by: JOO ~ VENOM
*/

const example = async (m, { conn }) => {

await conn.sendMessage(m.chat, {
  text: '*🔥 Special Offer*\n\n50% OFF\nLimited time',
  mentions: ['201234567890@s.whatsapp.net', '201111111111@s.whatsapp.net']
}, { quoted: m });

};

example.usage = ["تست1"]


/* ↓ قسم الأمر ↓ */
example.category = "example"


/* ↓ استخدم الأوامر ↓ */
example.command = ["تست1"] 


/* ↓ بتعمل ايقاف ل الأمر ↓ */
example.disabled = false // لو عملتها true الأمر كده مش هيشتغل

/* ↓ استخدام الأمر بعد ثانيه من الاستخدام لمنع الاسبام ↓ */
example.cooldown = 1000; // تقدر تزود الثواني 


/* ↓ استخدام الأمر ب بدايه أو لا ↓ */
example.usePrefix = false; // لو عملتها true الأمر هيبقي من غير بدايه 

export default example;