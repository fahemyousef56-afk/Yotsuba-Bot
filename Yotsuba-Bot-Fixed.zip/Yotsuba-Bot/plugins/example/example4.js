const example = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    image: { url: "https://i.ibb.co/dwRnNBxj/IMG-20261013-114123-968.jpg" },
    caption: "🖼️ معرض الصور المباشر من يوتسوبا"
  }, { quoted: m });

};
example.usage = ["تست4"]
example.category = "example";
example.command = ["تست4"]
export default example;