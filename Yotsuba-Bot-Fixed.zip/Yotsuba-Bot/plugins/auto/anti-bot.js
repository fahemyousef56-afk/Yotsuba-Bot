/**
 * 🛡️ anti-bot.js
 * يمنع البوتات التانية من التدخل في أوامر بوتنا
 * ويمنع بوتنا من التفاعل مع رسائل البوتات الأخرى
 */

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

const isMyBot = (sender, conn) => {
    const mine = [numOf(conn?.user?.id), numOf(conn?.user?.lid)].filter(Boolean);
    return mine.includes(numOf(sender));
};

const isMySubBot = (sender) => {
    try {
        const subList = global.subBots?.list?.() || [];
        const senderNum = numOf(sender);
        return subList.some(b => String(b.phone) === senderNum || String(b.number) === senderNum);
    } catch { return false; }
};

const isOwner = (sender, bot) =>
    !!bot?.config?.owners?.some(o => sender && (o.jid === sender || o.lid === sender));

/**
 * كشف رسالة من بوت:
 * 1) الـ JID الخام للمرسل فيه device  (رقم:جهاز@s.whatsapp.net)
 * 2) معرّف الرسالة بيبدأ بـ BAE5 وطوله 16 (النمط الافتراضي لمكتبات البوتات)
 */
const looksLikeBot = (m) => {
    const rawSender = m.key?.participant || m.sender || '';
    if (/^\d+:\d+@s\.whatsapp\.net$/.test(rawSender)) return true;

    const id = String(m.key?.id || '');
    if (id.startsWith('BAE5') && id.length === 16) return true;

    return false;
};

export default async function before(m, { conn, bot }) {
    if (!String(m.chat || '').endsWith('@g.us')) return false;
    if (m.fromMe) return false;

    const sender = m.sender || m.key?.participant || '';
    if (!sender) return false;

    // البوت الرئيسي ومطورين - مرور
    if (isMyBot(sender, conn)) return false;
    if (isOwner(sender, bot)) return false;

    // البوتات الفرعية بتاعتنا - مرور
    if (isMySubBot(sender)) return false;

    // كشف البوت
    if (!looksLikeBot(m)) return false;

    // هنا: بوت أجنبي - بس لو antiBots مفعل في الجروب ده
    const settings = global._gs?.[m.chat];
    if (!settings?.antiBots) return false; // لو مش مفعل: سماح

    if (settings.antiBotMode === 'kick') {
        try {
            const meta = await conn.groupMetadata(m.chat);
            const parts = meta.participants || [];
            const idsOf = (p) => [p.id, p.jid, p.phoneNumber].filter(Boolean).map(numOf);

            const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);
            const botIsAdmin = parts.some(p => p.admin && idsOf(p).some(n => botNums.includes(n)));
            const senderIsAdmin = parts.some(p => p.admin && idsOf(p).includes(numOf(sender)));

            if (botIsAdmin && !senderIsAdmin) {
                await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
                await conn.sendMessage(m.chat, {
                    text: `🤖 تم طرد بوت أجنبي: @${numOf(sender)}`,
                    mentions: [sender],
                    contextInfo: channelContext(),
                });
            }
        } catch (e) {
            console.error('[AntiBot]', e.message);
        }
        return true;
    }

    // تجاهل الرسالة بدون طرد
    return true;
}
