import { readFileSync, existsSync } from 'fs';

const ADHAN_FILE = './system/adhan_config.json';

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

/* ───────────── الدولة حسب رقم البوت (كود الدولة) ─────────────
   city / country بالإنجليزي عشان API الأذان، ar للعرض، method طريقة الحساب (اختياري) */
const COUNTRY_BY_CODE = {
    '20':  { ar: 'مصر',      country: 'Egypt',                city: 'Cairo',        method: 5 },
    '966': { ar: 'السعودية', country: 'Saudi Arabia',         city: 'Riyadh',       method: 4 },
    '971': { ar: 'الإمارات', country: 'United Arab Emirates', city: 'Dubai',        method: 4 },
    '965': { ar: 'الكويت',   country: 'Kuwait',               city: 'Kuwait City',  method: 9 },
    '974': { ar: 'قطر',      country: 'Qatar',                city: 'Doha',         method: 10 },
    '973': { ar: 'البحرين',  country: 'Bahrain',              city: 'Manama',       method: 4 },
    '968': { ar: 'عمان',     country: 'Oman',                 city: 'Muscat',       method: 4 },
    '962': { ar: 'الأردن',   country: 'Jordan',               city: 'Amman',        method: 4 },
    '964': { ar: 'العراق',   country: 'Iraq',                 city: 'Baghdad',      method: 4 },
    '963': { ar: 'سوريا',    country: 'Syria',                city: 'Damascus',     method: 4 },
    '961': { ar: 'لبنان',    country: 'Lebanon',              city: 'Beirut',       method: 4 },
    '970': { ar: 'فلسطين',   country: 'Palestine',            city: 'Jerusalem',    method: 4 },
    '967': { ar: 'اليمن',    country: 'Yemen',                city: 'Sanaa',        method: 4 },
    '212': { ar: 'المغرب',   country: 'Morocco',              city: 'Rabat',        method: 21 },
    '213': { ar: 'الجزائر',  country: 'Algeria',              city: 'Algiers',      method: 19 },
    '216': { ar: 'تونس',     country: 'Tunisia',              city: 'Tunis',        method: 18 },
    '218': { ar: 'ليبيا',    country: 'Libya',                city: 'Tripoli',      method: 5 },
    '249': { ar: 'السودان',  country: 'Sudan',                city: 'Khartoum',     method: 5 },
    '252': { ar: 'الصومال',  country: 'Somalia',              city: 'Mogadishu',    method: 3 },
    '90':  { ar: 'تركيا',    country: 'Turkey',               city: 'Ankara',       method: 13 },
    '98':  { ar: 'إيران',    country: 'Iran',                 city: 'Tehran',       method: 7 },
    '92':  { ar: 'باكستان',  country: 'Pakistan',             city: 'Islamabad',    method: 1 },
    '62':  { ar: 'إندونيسيا', country: 'Indonesia',           city: 'Jakarta',      method: 20 },
    '60':  { ar: 'ماليزيا',  country: 'Malaysia',             city: 'Kuala Lumpur', method: 17 },
};

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

// أطول كود دولة بيطابق بداية رقم البوت
const locationFromNumber = (num) => {
    const codes = Object.keys(COUNTRY_BY_CODE).sort((a, b) => b.length - a.length);
    const code = codes.find(c => String(num).startsWith(c));
    return code ? COUNTRY_BY_CODE[code] : null;
};

const loadConfig = () => {
    try { return existsSync(ADHAN_FILE) ? JSON.parse(readFileSync(ADHAN_FILE, 'utf-8')) : {}; } catch { return {}; }
};

/* ───────────── مواقيت الصلاة (مع كاش يومي) ───────────── */
const timesCache = {};   // key -> { date, timings, tz }

const fetchTimes = async ({ city, country, method }) => {
    const url =
        `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}` +
        `&country=${encodeURIComponent(country || '')}&method=${method || 4}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
    const data = await res.json();
    if (data.code !== 200) throw new Error('not found');
    return { timings: data.data.timings, tz: data.data.meta?.timezone || 'UTC' };
};

// الوقت والتاريخ بتوقيت المدينة نفسها (مش توقيت السيرفر)
const nowIn = (tz) => {
    const now = new Date();
    const time = new Intl.DateTimeFormat('en-GB', {
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: tz,
    }).format(now);
    const date = new Intl.DateTimeFormat('en-CA', {
        year: 'numeric', month: '2-digit', day: '2-digit', timeZone: tz,
    }).format(now);
    return { time, date };
};

const getTimes = async (loc) => {
    const key = `${loc.city}|${loc.country || ''}|${loc.method || 4}`;
    const cached = timesCache[key];
    if (cached) {
        const today = nowIn(cached.tz).date;
        if (cached.date === today) return cached;
    }
    const fresh = await fetchTimes(loc);
    const entry = { ...fresh, date: nowIn(fresh.tz).date };
    timesCache[key] = entry;
    return entry;
};

const PRAYER_LABELS = {
    Fajr: '🌅 الفجر', Dhuhr: '🌞 الظهر',
    Asr: '🌤️ العصر', Maghrib: '🌆 المغرب', Isha: '🌙 العشاء'
};

const lastNotified = {};

/* ───────────── الفحص الدوري (كل 60 ثانية) ───────────── */
const tick = async () => {
    const conn = global._conn;
    if (!conn) return;

    const cfg = loadConfig();
    if (!Object.keys(cfg).length) return;

    // دولة صاحب البوت (من الرقم المربوط) — تُستخدم لو الشات مالوش مدينة محددة
    const ownerLoc = locationFromNumber(numOf(conn.user?.id));

    const send = (chatId, body) =>
        conn.sendMessage(chatId, { text: body, contextInfo: channelContext() });

    for (const [chatId, chatCfg] of Object.entries(cfg)) {
        if (!chatCfg?.active) continue;

        // المدينة: من إعداد الشات، وإلا من دولة صاحب البوت
        const loc = chatCfg.city
            ? { city: chatCfg.city, country: chatCfg.country || '', method: chatCfg.method || 4, ar: chatCfg.city }
            : ownerLoc && { ...ownerLoc, ar: `${ownerLoc.city}، ${ownerLoc.ar}` };
        if (!loc) continue;

        try {
            const { timings, tz } = await getTimes(loc);
            const { time: currentTime } = nowIn(tz);

            for (const [prayer, label] of Object.entries(PRAYER_LABELS)) {
                const pTime = timings[prayer]?.slice(0, 5); // HH:MM
                if (!pTime || pTime !== currentTime) continue;

                const notifyKey = `${chatId}_${prayer}_${currentTime}`;
                if (lastNotified[notifyKey]) continue;
                lastNotified[notifyKey] = true;
                setTimeout(() => { delete lastNotified[notifyKey]; }, 120000);

                // تذكير الصلاة
                await send(chatId,
                    `🕌 *حان وقت صلاة ${label}*\n\n` +
                    `📍 ${loc.ar}\n` +
                    `⏰ ${pTime}\n\n` +
                    `> _اللهم أعنا على ذكرك وشكرك وحسن عبادتك_ 🤲`
                );

                // قفل الجروب لو مفعل
                if (chatCfg.lockGroup && prayer !== 'Fajr' && String(chatId).endsWith('@g.us')) {
                    try {
                        await conn.groupSettingUpdate(chatId, 'announcement');
                        await send(chatId, `🔒 *تم قفل الجروب لأداء الصلاة*\n\nسيُفتح بعد 30 دقيقة إن شاء الله`);

                        // فتح بعد 30 دقيقة
                        setTimeout(async () => {
                            try {
                                await conn.groupSettingUpdate(chatId, 'not_announcement');
                                await send(chatId, `🔓 *تم فتح الجروب بعد الصلاة*\n\nتقبل الله منا ومنكم 🤲`);
                            } catch {}
                        }, 30 * 60 * 1000);
                    } catch {}
                }
            }
        } catch {}
    }
};

// الدالة بتتحدث مع كل إعادة تحميل للملف
global.__prayerTick = tick;

// 🛡️ حماية من التكرار: interval واحد بس حتى لو الملف اتحمّل أكتر من مرة،
// وهو بينادي على آخر نسخة من tick فالتعديلات بتتطبق من غير ريستارت
if (!global.__prayerReminderInterval) {
    global.__prayerReminderInterval = setInterval(() => {
        Promise.resolve(global.__prayerTick?.()).catch(() => {});
    }, 60_000);
}

export default async function before(m, { conn }) {
    // حفظ آخر conn في global عشان الـ interval يقدر يستخدمه (بيتحدث لو البوت أعاد الاتصال)
    global._conn = conn;
    return false;
}

