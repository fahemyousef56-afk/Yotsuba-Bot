// 🍁 ملف: welcome_new.js - الترحيب والوداع - 𝑩𝜣𝑻⃝𖤐

const EMOJI = '👻';
const BOT_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑩𝜺𝑻⃝👻';
const DEVELOPER = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂';
const OWNER_PHONE = '221774033156'; // ✅ تم إضافة رقم المطور
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '..๋࣭𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍.๋࣭';
const CHANNEL_LINK = '..';
const MAIN_IMAGE = 'https://i.ibb.co/kstvMJdZ/IMG-20261025-222746-549.jpg';

// 🍁 رسائل ترحيب للمطور
const OWNER_WELCOME = [
    `╭━━━━━━━━━━━━━━━━━━━╮
   ❖ 👑 دخـل الـمـطـور 👑 ❖
╰━━━━━━━━━━━━━━━━━━━╯

👑 *@${OWNER_PHONE}*
🔥 *النظام تحت أمرك يا سيد يوتسوبا*

${EMOJI} *${BOT_NAME}*`,
    `${EMOJI} *🔥 المطور نزل على الجروب*\n\n👑 @${OWNER_PHONE} هنا`
];

// 🍁 رسائل وداع للمطور
const OWNER_BYE = [
    `${EMOJI} *👑 المطور غادر الجروب*\n\n> النظام في وضع الحراسة الذاتية 🕸`,
    `${EMOJI} *⚡ المطور خرج*\n\n> من يجرؤ الآن؟ 🔥`
];

// 🍁 دالة الحصول على صورة المستخدم
async function getUserAvatar(conn, jid) {
    try {
        return await conn.profilePictureUrl(jid, 'image');
    } catch {
        return MAIN_IMAGE;
    }
}

// 🍁 دالة الحصول على اسم المجموعة
async function getGroupName(conn, chatId) {
    try {
        const meta = await conn.groupMetadata(chatId);
        return meta.subject || 'المجموعة';
    } catch {
        return 'المجموعة';
    }
}

// 🍁 دالة الحصول على عدد الأعضاء
async function getMemberCount(conn, chatId) {
    try {
        const meta = await conn.groupMetadata(chatId);
        return meta.participants?.length || 0;
    } catch {
        return 0;
    }
}

export default async function before(m, { conn, bot }) {
    if (!m.isGroup) return false;
    if (!m.messageStubType) return false;

    const stubType = m.messageStubType;
    const stubParams = m.messageStubParameters || [];
    if (!stubParams.length) return false;

    // 🍁 أنواع الأحداث
    // 21 = GROUP_PARTICIPANT_ADD (دخول)
    // 22 = GROUP_PARTICIPANT_REMOVE (خروج)
    // 23 = GROUP_PARTICIPANT_LEAVE (مغادرة)
    const isAdd = [21, 'GROUP_PARTICIPANT_ADD', 'GROUP_PARTICIPANT_INVITE'].includes(stubType);
    const isRemove = [22, 23, 'GROUP_PARTICIPANT_REMOVE', 'GROUP_PARTICIPANT_LEAVE'].includes(stubType);

    if (!isAdd && !isRemove) return false;

    // 🍁 التحقق من تعطيل الترحيب
    const disabled = global._gs?.[m.chat]?.welcomeDisabled;
    if (disabled) return false;

    const userJid = stubParams[0];
    if (!userJid) return false;

    const username = userJid.split('@')[0];
    const mention = '@' + username;

    // 🍁 جلب بيانات المجموعة
    const groupName = await getGroupName(conn, m.chat);
    const memberCount = await getMemberCount(conn, m.chat);
    const avatarUrl = await getUserAvatar(conn, userJid);

    // 🍁 التحقق من أن المستخدم مطور
    const owners = bot?.config?.owners || [];
    const isOwner = owners.some(o => userJid === o.jid || userJid === o.lid);

    // 🍁 تأخير قبل الإرسال
    await new Promise(r => setTimeout(r, 2000));

    // 🍁 إذا كان مطوراً
    if (isOwner) {
        const msgs = isAdd ? OWNER_WELCOME : OWNER_BYE;
        const msg = msgs[Math.floor(Math.random() * msgs.length)];
        await conn.sendMessage(m.chat, {
            text: msg,
            mentions: [userJid]
        });
        return false;
    }

    // 🍁 رسالة الترحيب
    if (isAdd) {
        const txt = `${EMOJI}━━━[ *🎉 أهلاً بك* ]━━━${EMOJI}

🌟 *الضيف:* ${mention}
🏰 *المجموعة:* ${groupName}
👥 *الأعضاء:* ${memberCount}

${EMOJI} *نصائح الملك:*
▸ استخدم .اوامر لعرض الأوامر
▸ استخدم .قائمة للتنقل

${EMOJI} *${BOT_NAME}*`;

        try {
            await conn.sendMessage(m.chat, {
                image: { url: avatarUrl },
                caption: txt,
                mentions: [userJid],
                contextInfo: {
                    mentionedJid: [userJid],
                    isForwarded: true,
                    forwardingScore: 1,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: CHANNEL_JID,
                        newsletterName: CHANNEL_NAME,
                        serverMessageId: 0
                    }
                }
            });
        } catch {
            await conn.sendMessage(m.chat, {
                text: txt,
                mentions: [userJid]
            });
        }
    }

    // 🍁 رسالة الوداع
    if (isRemove) {
        const txt = `${EMOJI}━━━[ *💔 وداعاً* ]━━━${EMOJI}

🌟 *المغادر:* ${mention}
🏰 *المجموعة:* ${groupName}
👥 *الأعضاء الآن:* ${memberCount}

${EMOJI} *نتمنى لك الخير* 🌹

${EMOJI} *${BOT_NAME}*`;

        try {
            await conn.sendMessage(m.chat, {
                image: { url: avatarUrl },
                caption: txt,
                mentions: [userJid]
            });
        } catch {
            await conn.sendMessage(m.chat, {
                text: txt,
                mentions: [userJid]
            });
        }
    }

    return false;
}