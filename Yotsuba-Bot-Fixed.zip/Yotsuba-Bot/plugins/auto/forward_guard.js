// ════════════════════════════════════════
//  مضاد إعادة التوجيه (anti-forward)
//  ملحوظة: إنفاذ الكتم بقى جوه plugins/protection/mute.js نفسه (handler.before)
//  ════════════════════════════════════════

import { getG, isOwnerFn } from '../../system/admin_utils.js';

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

// يجيب contextInfo من أي نوع رسالة (نص / صورة / فيديو / ملصق / صوت / ملف ...) حتى لو مغلفة
const getContextInfo = (message) => {
    let msg = message;
    for (let i = 0; i < 4 && msg; i++) {
        const inner = msg.ephemeralMessage?.message
            || msg.viewOnceMessage?.message
            || msg.viewOnceMessageV2?.message
            || msg.documentWithCaptionMessage?.message;
        if (!inner) break;
        msg = inner;
    }
    if (!msg) return {};

    const type = Object.keys(msg).find(k => k !== 'messageContextInfo');
    return msg[type]?.contextInfo || {};
};

export default async function before(m, { conn, bot }) {
    if (!String(m.chat || '').endsWith('@g.us')) return false;
    if (m.fromMe) return false;

    const g = getG(m.chat);
    if (!g?.antiForward) return false;

    // ═══ مضاد إعادة التوجيه (anti-forward) ═══
    const ctx = getContextInfo(m.message);
    const isForwarded = !!ctx.isForwarded || (ctx.forwardingScore || 0) >= 1;
    if (!isForwarded) return false;

    const sender = m.sender || m.key?.participant;
    if (!sender) return false;

    // المطور مستثنى
    if (isOwnerFn(sender, bot, conn)) return false;

    // صلاحيات من بيانات الجروب (بنتحقق بس لما نلاقي رسالة متحوّلة)
    let parts = [];
    try {
        const meta = await conn.groupMetadata(m.chat);
        parts = meta.participants || [];
    } catch {
        return false;
    }
    const idsOf = (p) => [p.id, p.jid, p.phoneNumber].filter(Boolean).map(numOf);

    // الادمن مستثنى
    if (m.isAdmin || parts.some(p => p.admin && idsOf(p).includes(numOf(sender)))) return false;

    // لازم البوت يكون ادمن عشان يحذف
    const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);
    const botIsAdmin = parts.some(p => p.admin && idsOf(p).some(n => botNums.includes(n)));
    if (!botIsAdmin) return false;

    try { await conn.sendMessage(m.chat, { delete: m.key }); } catch {}
    try {
        await conn.sendMessage(m.chat, {
            text: `🚫 *ممنوع إعادة توجيه الرسايل هنا يا @${numOf(sender)}*`,
            mentions: [sender],
            contextInfo: channelContext(),
        });
    } catch {}

    return true;
}
