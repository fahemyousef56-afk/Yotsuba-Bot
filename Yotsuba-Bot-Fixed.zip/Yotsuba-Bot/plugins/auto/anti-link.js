const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

// من غير flag g عشان .test() ماتبقاش stateful
const groupLinkRegex = /(https?:\/\/)?(chat\.whatsapp\.com|whatsapp\.com\/channel)\/[A-Za-z0-9]+/i;

export default async function before(m, { conn, bot }) {
    if (!String(m.chat || '').endsWith('@g.us')) return false;
    if (m.fromMe) return false;

    const text = m.text || m.body || '';
    if (!text || !groupLinkRegex.test(text)) return false;

    const sender = m.sender || m.key?.participant;
    if (!sender) return false;

    // قاعدة البيانات
    if (!global.db) global.db = {};
    if (!global.db.groups) global.db.groups = {};
    const g = global.db.groups[m.chat] || (global.db.groups[m.chat] = {});

    // لو اتقفل من أمر .تفعيل ايقاف_مضاد_الروابط
    if (g.antiLink === false) return false;

    // المطور مستثنى
    const owners = bot?.config?.owners || [];
    if (m.isOwner || owners.some(o => sender === o.jid || sender === o.lid)) return false;

    // الصلاحيات من بيانات الجروب
    let meta;
    try { meta = await conn.groupMetadata(m.chat); } catch { return false; }
    const parts = meta.participants || [];
    const idsOf = (p) => [p.id, p.jid, p.phoneNumber].filter(Boolean).map(numOf);

    const senderIsAdmin = m.isAdmin || parts.some(p => p.admin && idsOf(p).includes(numOf(sender)));
    if (senderIsAdmin) return false;

    // لازم البوت يكون ادمن عشان يحذف ويطرد
    const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);
    const botIsAdmin = parts.some(p => p.admin && idsOf(p).some(n => botNums.includes(n)));
    if (!botIsAdmin) return false;

    // يعمل تلقائياً: أول رابطين حذف + تحذير، والثالث طرد.
    g.linkWarnings ??= {};
    const count = (g.linkWarnings[sender] || 0) + 1;
    g.linkWarnings[sender] = count;

    try { await conn.sendMessage(m.chat, { delete: m.key }); } catch {}

    const tag = `@${numOf(sender)}`;

    if (count >= 3) {
        try {
            await conn.sendMessage(m.chat, {
                text: `🚫 تم طرد ${tag} بعد إرسال 3 روابط`,
                mentions: [sender],
                contextInfo: channelContext(),
            });
            await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
        } catch (e) {
            console.error('[AntiLink]', e.message);
        }
        delete g.linkWarnings[sender];
        return true;
    }

    try {
        await conn.sendMessage(m.chat, {
            text: `🚫 *تم حذف الرابط*\n\n${tag} هذا تحذير تلقائي رقم ${count}/3\n\n> عند الوصول إلى 3 روابط سيتم الطرد`,
            mentions: [sender],
            contextInfo: channelContext(),
        });
    } catch {}

    return true;
}