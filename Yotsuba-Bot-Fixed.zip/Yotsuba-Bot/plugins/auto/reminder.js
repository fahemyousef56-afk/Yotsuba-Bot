// نظام التذكيرات
// نوعين:
// 1) وقت محدد:  .تذكير شرب الدواء 14:30
// 2) كل كام دقيقة: .تذكير الصلاة على النبي كل 30
// + رسالة تلقائية (صلاة على النبي + ذكر) كل 5 ساعات لشخص/شات واحد

/* ───────────── إعدادات ───────────── */
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const TIMEZONE = 'Africa/Cairo';          // توقيت التذكيرات بالوقت المحدد
const AUTO_INTERVAL_HOURS = 5;            // الرسالة التلقائية كل كام ساعة
const AUTO_TARGET_JID = '';               // ← رقم/شات واحد بالشكل 201234567890@s.whatsapp.net
                                          //   لو سيبته فاضي: بيتبعت لأول مطور في bot.config.owners
const MAX_REMINDERS_PER_CHAT = 20;

const channelContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const SALAWAT = [
    '🌹 *اللهم صلِّ على سيدنا محمد وعلى آله وصحبه وسلم*',
    '🌹 *صلوا على النبي ﷺ - اللهم صل وسلم وبارك على سيدنا محمد*',
    '🌹 *اللهم صلِّ على محمد وعلى آل محمد كما صليت على إبراهيم*',
    '🌹 *صلى الله عليه وسلم - أكثروا من الصلاة على النبي يوم الجمعة*',
    '🌹 *اللهم صلِّ وسلم وبارك على نبينا محمد ﷺ*',
];

const DUA = [
    '> _بسم الله الرحمن الرحيم_',
    '> _اللهم اجعل أعمالنا خالصة لوجهك الكريم_',
    '> _سبحان الله وبحمده سبحان الله العظيم_',
    '> _لا حول ولا قوة إلا بالله العلي العظيم_',
    '> _الحمد لله على كل حال_',
    '> _استغفر الله العظيم وأتوب إليه_',
];

const getRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

const getReminders = () => {
    if (!global._gs) global._gs = {};
    if (!global._gs.__reminders) global._gs.__reminders = [];
    return global._gs.__reminders;
};

// أرقام عربية → إنجليزية
const toLatinDigits = (s) => String(s || '')
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));

// تحليل وقت محدد "14:30" أو "8:00ص" أو "2:30م"
const parseTime = (str) => {
    if (!str) return null;
    const m = toLatinDigits(str).match(/^(\d{1,2}):(\d{2})([صم]?)$/);
    if (!m) return null;
    let h = parseInt(m[1]);
    const min = parseInt(m[2]);
    if (m[3] === 'م' && h < 12) h += 12;
    if (m[3] === 'ص' && h === 12) h = 0;
    if (h < 0 || h > 23 || min < 0 || min > 59) return null;
    return { h, min };
};

// الساعة والدقيقة الحالية بتوقيت TIMEZONE
const nowParts = () => {
    const parts = new Intl.DateTimeFormat('en-GB', {
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: TIMEZONE,
    }).formatToParts(new Date());
    return {
        h: Number(parts.find(p => p.type === 'hour').value),
        min: Number(parts.find(p => p.type === 'minute').value),
    };
};

// بناء رسالة التذكير
const buildMsg = (r) => ({
    text:
        `╭─┈─┈─┈─⟞🔔⟝─┈─┈─┈─╮\n` +
        `┃ *تذكير ORACLE*\n` +
        `╰─┈─┈─┈─⟞🔔⟝─┈─┈─┈─╯\n\n` +
        (r.intervalMin
            ? `🔄 *كل ${r.intervalMin} دقيقة*\n\n`
            : `⏰ *${r.time}*\n\n`) +
        `📌 *${r.text}*\n\n` +
        `${getRandom(DUA)}\n\n` +
        `${getRandom(SALAWAT)}` +
        (r.sender ? `\n\n┃ @${numOf(r.sender)}` : ''),
    mentions: r.sender ? [r.sender] : []
});

// الرسالة التلقائية كل 5 ساعات
const buildAutoMsg = () =>
    `╭─┈─┈─┈─⟞🌹⟝─┈─┈─┈─╮\n` +
    `┃ *ذكر وصلاة على النبي ﷺ*\n` +
    `╰─┈─┈─┈─⟞🌹⟝─┈─┈─┈─╯\n\n` +
    `${getRandom(DUA)}\n\n` +
    `${getRandom(SALAWAT)}`;

/* ───────────── المُجدوِل (كل 30 ثانية) ───────────── */
const tick = async () => {
    const conn = global._conn;
    if (!conn) return;

    const now = Date.now();
    const list = getReminders();

    // 1) التذكيرات الدورية (كل X دقيقة) + بالوقت المحدد
    const { h, min } = nowParts();
    const due = [];

    for (const r of list) {
        if (r.intervalMin) {
            if (now >= r.nextAt) {
                r.nextAt = now + r.intervalMin * 60_000;
                due.push(r);
            }
        } else if (r.h === h && r.min === min) {
            due.push(r);
        }
    }

    // التذكيرات بالوقت المحدد بتتشال قبل الإرسال عشان ماتتكررش
    const oneShotIds = due.filter(r => !r.intervalMin).map(r => r.id);
    if (oneShotIds.length) {
        global._gs.__reminders = getReminders().filter(r => !oneShotIds.includes(r.id));
    }

    for (const r of due) {
        try {
            const { text, mentions } = buildMsg(r);
            await conn.sendMessage(r.chat, { text, mentions, contextInfo: channelContext() });
        } catch {}
    }

    // 2) الرسالة التلقائية كل AUTO_INTERVAL_HOURS ساعة
    if (!global.__autoRemindNextAt) {
        global.__autoRemindNextAt = now + AUTO_INTERVAL_HOURS * 3_600_000;
    } else if (now >= global.__autoRemindNextAt) {
        global.__autoRemindNextAt = now + AUTO_INTERVAL_HOURS * 3_600_000;

        const owners = global.__reminderBot?.config?.owners || [];
        const target = AUTO_TARGET_JID || owners.find(o => o?.jid)?.jid;

        if (target) {
            try {
                await conn.sendMessage(target, { text: buildAutoMsg(), contextInfo: channelContext() });
            } catch {}
        }
    }
};

// الدالة بتتحدث مع كل إعادة تحميل للملف
global.__reminderTick = tick;

// 🛡️ interval واحد بس حتى لو الملف اتحمّل أكتر من مرة
if (!global.__reminderInterval) {
    global.__reminderInterval = setInterval(() => {
        Promise.resolve(global.__reminderTick?.()).catch(() => {});
    }, 30_000);
}

/* ───────────── Handler ───────────── */
const handler = async (m, { conn, text, command }) => {
    // رد برسالة متحوّلة من القناة
    const send = (body, mentions = []) =>
        conn.sendMessage(
            m.chat,
            { text: body, mentions, contextInfo: channelContext() },
            { quoted: m }
        );

    const isReminderCmd = ['تذكير', 'reminder'].includes(command);
    const arg = text?.trim() || '';

    // عرض التذكيرات
    if (command === 'تذكيراتي' ||
        (isReminderCmd && ['قائمة', 'قائمه', 'list'].includes(arg))) {
        const all = getReminders().filter(r => r.chat === m.chat);
        if (!all.length) return send(
            '*📋 مفيش تذكيرات حالياً*\n\n' +
            'أمثلة:\n' +
            '*.تذكير شرب الدواء 14:30*\n' +
            '*.تذكير الصلاة على النبي كل 30*'
        );
        const lines = all.map((r, i) =>
            `${i + 1}. ${r.intervalMin ? `🔄 كل ${r.intervalMin}د` : `⏰ ${r.time}`}\n   📌 ${r.text}`
        ).join('\n\n');
        return send(`*🔔 التذكيرات:*\n\n${lines}\n\n*.تذكير حذف <رقم>*`);
    }

    if (!isReminderCmd) return;

    // حذف تذكير
    if (arg.startsWith('حذف')) {
        const num = parseInt(toLatinDigits(arg.split(/\s+/)[1]));
        const chatR = getReminders().filter(r => r.chat === m.chat);
        if (!num || !chatR[num - 1]) return send('*❌ رقم غلط* — استخدم *.تذكيراتي*');
        const target = chatR[num - 1];
        global._gs.__reminders = getReminders().filter(r => r.id !== target.id);
        return send(`*✅ تم حذف:* ${target.text}`);
    }

    // مسح الكل
    if (['مسح', 'clear'].includes(arg)) {
        const mine = getReminders().filter(r => r.chat === m.chat);
        global._gs.__reminders = getReminders().filter(r => r.chat !== m.chat);
        return send(`*✅ تم مسح ${mine.length} تذكير*`);
    }

    // ===== إضافة تذكير جديد =====
    if (!arg) return send(
        '*🔔 أمر التذكير*\n\n' +
        '*وقت محدد:*\n.تذكير شرب الدواء 14:30\n\n' +
        '*كل كام دقيقة:*\n.تذكير الصلاة على النبي كل 30\n\n' +
        '*.تذكيراتي* — عرض التذكيرات\n' +
        '*.تذكير حذف 1* — حذف برقمه\n' +
        '*.تذكير مسح* — مسح الكل'
    );

    if (getReminders().filter(r => r.chat === m.chat).length >= MAX_REMINDERS_PER_CHAT) {
        return send(`*❌ وصلت للحد الأقصى (${MAX_REMINDERS_PER_CHAT} تذكير)* — احذف تذكير قبل ما تضيف جديد`);
    }

    const parts = arg.split(/\s+/);
    const newId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    // ─ نوع "كل X دقيقة" ─ (كلمة كل لازم يجي بعدها رقم، عشان "كل الاعضاء" مثلاً ماتتفهمش غلط)
    const kelIdx = parts.findIndex((p, i) => p === 'كل' && /^[\d٠-٩]+$/.test(parts[i + 1] || ''));
    if (kelIdx !== -1) {
        const mins = parseInt(toLatinDigits(parts[kelIdx + 1]));
        if (!mins || mins < 1 || mins > 1440) {
            return send('*❌ عدد الدقائق غلط* (بين 1 و 1440)');
        }

        const reminderText = parts.slice(0, kelIdx).join(' ');
        if (!reminderText) return send('*❌ اكتب نص التذكير قبل كلمة كل*');

        getReminders().push({
            id:          newId(),
            chat:        m.chat,
            sender:      m.sender,
            text:        reminderText,
            intervalMin: mins,
            nextAt:      Date.now() + mins * 60_000,
            addedAt:     Date.now(),
        });

        return send(
            `*✅ تم تسجيل التذكير!*\n\n` +
            `📌 *${reminderText}*\n` +
            `🔄 *كل ${mins} دقيقة*\n\n` +
            `${getRandom(SALAWAT)}`
        );
    }

    // ─ نوع وقت محدد ─
    const timeStr = toLatinDigits(parts[parts.length - 1]);
    const parsed  = parseTime(timeStr);

    if (!parsed) {
        return send(
            '*❌ صيغة الوقت غلط*\n\n' +
            'أمثلة:\n' +
            '*.تذكير شرب الدواء 14:30*\n' +
            '*.تذكير الصلاة على النبي كل 30*'
        );
    }

    const reminderText = parts.slice(0, -1).join(' ');
    if (!reminderText) return send('*❌ اكتب نص التذكير قبل الوقت*');

    getReminders().push({
        id:      newId(),
        chat:    m.chat,
        sender:  m.sender,
        text:    reminderText,
        time:    timeStr,
        h:       parsed.h,
        min:     parsed.min,
        addedAt: Date.now(),
    });

    return send(
        `*✅ تم تسجيل التذكير!*\n\n` +
        `📌 *${reminderText}*\n` +
        `⏰ *${timeStr}* (بتوقيت ${TIMEZONE})\n\n` +
        `${getRandom(SALAWAT)}`
    );
};

// حفظ conn و bot عشان المُجدوِل يقدر يستخدمهم (بيتحدثوا مع كل رسالة)
handler.before = async (m, { conn, bot }) => {
    global._conn = conn;
    if (bot) global.__reminderBot = bot;
    return false;
};

handler.command  = ['تذكير', 'تذكيراتي', 'reminder'];
handler.usage    = ['تذكير <نص> <وقت>', 'تذكير <نص> كل <دقائق>'];
handler.category = 'auto';

export default handler;
