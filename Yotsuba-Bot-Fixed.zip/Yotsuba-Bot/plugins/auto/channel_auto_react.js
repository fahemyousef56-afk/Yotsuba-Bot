//  🌸  تفاعل تلقائي مع رسائل القناة - 🌸 ⏤͟͞𝒀𝑼𝑲𝑰 - 𝑩𝜺𝑻⃝🌸

const REACT_EMOJIS = [
    '😂','🫩','🙃','😉','💋','❤','✨','🌚','✅',
    '🐥','🎭','🙀','🤲🏻','⚜️','🚫','🤖','🥹',
    '🙂‍↔️','🖐🏻','😳','😥','🍁','🔥','👑'
];

// القناة الأساسية (بتتفاعل عليها تلقائي من غير ما تفعّلها)
const CHANNEL_JID = '120363433665479594@newsletter';

const randomEmoji = () => REACT_EMOJIS[Math.floor(Math.random() * REACT_EMOJIS.length)];

// منع التفاعل مرتين على نفس الرسالة
if (!global._channelReactSeen) global._channelReactSeen = new Set();

// تفاعل على رسالة قناة بأفضل طريقة متاحة
const reactTo = async (sock, channelJid, key, emoji) => {
    const serverId = key.server_id || key.serverId || key.id;

    // الطريقة الرسمية لتفاعلات القنوات في Baileys
    if (typeof sock.newsletterReactMessage === 'function') {
        return sock.newsletterReactMessage(channelJid, String(serverId), emoji);
    }

    // بديل لو الدالة مش موجودة
    return sock.sendMessage(channelJid, { react: { text: emoji, key } });
};

export default async function before(m, { conn }) {
    // ✅ التحقق من أن الرسالة من قناة
    const channelJid = m.key?.remoteJid;
    if (!channelJid?.includes('@newsletter')) return false;
    if (m.key?.fromMe) return false;

    // ✅ القناة الأساسية شغالة دايماً، والقنوات التانية بالتفعيل
    const enabled = channelJid === CHANNEL_JID || global._channelReact?.[channelJid];
    if (!enabled) return false;

    // ✅ منع التكرار
    const uid = `${channelJid}:${m.key.server_id || m.key.id}`;
    if (global._channelReactSeen.has(uid)) return false;
    global._channelReactSeen.add(uid);
    if (global._channelReactSeen.size > 300) {
        global._channelReactSeen.delete(global._channelReactSeen.values().next().value);
    }

    // ✅ تفاعل البوت الرئيسي
    try {
        await reactTo(conn, channelJid, m.key, randomEmoji());
    } catch (e) {
        console.log(' 🌸  فشل إرسال التفاعل:', e.message);
    }

    // ✅ تفاعلات البوتات الفرعية (في الخلفية عشان مانعطلش باقي البلجنز)
    (async () => {
        try {
            const subList = global.subBots?.list?.() || [];
            for (const subBot of subList) {
                const subSock = global.subBots?.get?.(subBot.id)?.sock;
                if (!subSock) continue;
                try {
                    await reactTo(subSock, channelJid, m.key, randomEmoji());
                } catch (e) {
                    console.log(' 🌸  فشل تفاعل البوت الفرعي:', e.message);
                }
                await new Promise(r => setTimeout(r, 500));
            }
        } catch (e) {
            console.log(' 🌸  فشل تفاعل البوتات الفرعية:', e.message);
        }
    })();

    return false;
}