const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

// ← عدّل اسم المطور ورقمه هنا
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const DEVELOPER_NUMBER = '221774033156';

const channelContext = () => ({
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
});

export default async function before(m, { conn, bot }) {
  // تجاهل رسائل البوت نفسه والرسائل اللي مش نص
  if (m.fromMe || m.isBaileys) return false;
  if (typeof m.text !== 'string' || !m.text.trim()) return false;

  const BOT_NAME = bot?.config?.info?.nameBot || 'البوت';

  const triggers = {
    "السلام عليكم": ["*وعليكم السلام ورحمة الله وبركاته 🧸*"],
    "تست": ["*_والله شغال_*"],
    "هلا": ["*🧸 هلا وغلا 🧸*", "*🧸 هلا بيك/ي 🧸*"],
    "باي": ["*مع السلامة*", "*باي باي*", "*الله معاك*"],
    "صباح الخير": ["*🧸 صباح النور 🧸*", "*🧸 صباح العسل عليك/ك 🧸*", "*🧸 صباح الفل 🧸*"],
    "صباح النور": ["صباح الخير ازي معرفش 🧸"],
    "مساء الخير": ["*🧸 مساء النور 🧸*", "*🧸 مساء الورود 🧸*", "*🧸 مساء الفل 🧸*", "*🧸 مساء العسل ي عسل 🧸*"],
    "مساء النور": ["*🧸 مساء الخير 🧸*", "*🧸 مساء الفل 🧸*", "*الله نورك*"],
    "هاي": ["*🧸 انا الذكاء الاصطناعي بتاع جو 🧸*"],
    "بوت": [`🍁 أنا *${BOT_NAME}*\n👑 من تطوير ${DEVELOPER}`],
    "المطور": [`🍁 المطور: *${DEVELOPER}*\n📱 wa.me/${DEVELOPER_NUMBER}`],
    "اسمك ايه": ["*_🧸 انا ai لم يجي الشخص الي رابط البوت هيرد عليك وفي الاخر المطور بيحبك 🧸_*"],
  };

  const replies = triggers[m.text.trim()];
  if (!replies) return false;

  const ranReply = replies[Math.floor(Math.random() * replies.length)];

  try {
    await conn.sendMessage(
      m.chat,
      { text: ranReply, contextInfo: channelContext() },
      { quoted: m }
    );
  } catch (e) {
    console.error('[AutoReply]', e.message);
  }

  return false;
}