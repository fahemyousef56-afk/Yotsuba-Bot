const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const channelContext = () => ({
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
});

const BAD_WORDS = [
  'يا غبي', 'غبي', 'حمار', 'كلب', 'خرا', 'شرموط', 'متناك',
  'كس امك', 'كسمك', 'كسم', 'ابن الكلب', 'يلعن', 'امك', 'يلعن البوت'
];

const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0];

// توحيد الكتابة (نفس تطبيع النص عشان الكلمات والرسالة يتقارنوا بنفس الشكل)
const normalize = (s) => String(s || '')
  .toLowerCase()
  .replace(/[أإآ]/g, 'ا')
  .replace(/ى/g, 'ي')
  .replace(/[ًٌٍَُِّْـ]/g, '')
  .replace(/(.)\1{2,}/g, '$1')          // "كلللب" → "كلب"
  .replace(/[^\p{L}\p{N}\s]/gu, ' ')     // شيل علامات الترقيم
  .replace(/\s+/g, ' ')
  .trim();

// مطابقة الكلمة كاملة (مع حرف و/ف اختياري قبلها) — عشان "امكانيات" و"خراب" ماتتحذفش غلط
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const BAD_REGEXES = BAD_WORDS.map(w =>
  new RegExp(`(^|\\s)[وف]?${escapeRe(normalize(w))}(\\s|$)`, 'u')
);

export default async function before(m, { conn, bot }) {
  if (!String(m.chat || '').endsWith('@g.us')) return false;
  if (m.fromMe) return false;

  const text = normalize(m.text || m.body || '');
  if (!text) return false;
  if (!BAD_REGEXES.some(re => re.test(text))) return false;

  const sender = m.sender || m.key?.participant;
  if (!sender) return false;

  // المطور مستثنى
  const owners = bot?.config?.owners || [];
  if (m.isOwner || owners.some(o => sender === o.jid || sender === o.lid)) return false;

  // الصلاحيات من بيانات الجروب
  let parts = [];
  try {
    const meta = await conn.groupMetadata(m.chat);
    parts = meta.participants || [];
  } catch {
    return false;
  }
  const idsOf = (p) => [p.id, p.jid, p.phoneNumber].filter(Boolean).map(numOf);

  // الادمن مستثنى
  if (m.isAdmin || parts.some(p => p.admin && idsOf(p).includes(numOf(sender)))) return false;

  // لازم البوت يكون ادمن عشان يحذف رسايل غيره
  const botNums = [numOf(conn.user?.id), numOf(conn.user?.lid)].filter(Boolean);
  const botIsAdmin = parts.some(p => p.admin && idsOf(p).some(n => botNums.includes(n)));
  if (!botIsAdmin) return false;

  await conn.sendMessage(m.chat, { delete: m.key }).catch(() => {});
  await conn.sendMessage(m.chat, {
    text: `🧹 تم حذف الشتيمة من رسالة @${numOf(sender)}\n> خلّوا الكلام باحترام`,
    mentions: [sender],
    contextInfo: channelContext(),
  }).catch(() => {});

  return true;
}