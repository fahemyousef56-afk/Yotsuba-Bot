// 🕸 ملف: خمن.js - لعبة خمن الشخصية - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import fetch from 'node-fetch';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/n8kt35J9/IMG-20261026-220710-367.jpg';

let timeout = 60000;
let poin = 1000;

if (!global.games) {
    global.games = {};
}

// ⭐⭐⭐ الأسئلة مدمجة مباشرة في الكود ⭐⭐⭐
const emojiQuestions = [
    { question: "👊🏻👨🏻‍🦲🦸🏻‍♂️", response: "سايتما" },
    { question: "🍎✍🏻📓", response: "لايت" },
    { question: "🫎🧑🏻‍⚕️❄️", response: "تشوبر" },
    { question: "🔥👱🏻‍♂️❄️", response: "تودوروكي" },
    { question: "🧑‍🍳🦵🏻🚬", response: "سانجي" },
    { question: "🐗⚔️👦🏻", response: "اينوسكي" },
    { question: "💀🎸👑", response: "بروك" },
    { question: "🔥🧑🏻‍🚒🚒", response: "شينزا" },
    { question: "💇🏻‍♀️🌸🙍🏻‍♀️", response: "ساكورا" },
    { question: "👨🏻‍🦰🏜️🏺", response: "غارا" },
    { question: "🦊🍜🍥", response: "ناروتو" },
    { question: "🍀📖👿", response: "استا" },
    { question: "☀️🗡️😮‍💨", response: "يوريتشي" },
    { question: "🐍😛🔬", response: "اوروتشيماو" },
    { question: "⚫⚪☁️", response: "زيتسو" },
    { question: "🤡🃏👦🏻", response: "هيسوكا" },
    { question: "🧑🏻🔙🧑", response: "تاكيميتشي" },
    { question: "👒🍖🏴‍☠", response: "لوفي" },
    { question: "🥪👦🏻👊🏻", response: "ماش" },
    { question: "🧛🏻‍♂️☀️👿", response: "موزان" },
    { question: "⛓️👀🧑", response: "كورابيكا" },
    { question: "🏴‍☠️⚓︎🤥", response: "يوسوب" },
    { question: "⚔️🌊🧑🏻", response: "غيو" },
    { question: "⚔️🔥🧑", response: "رينغوكو" },
    { question: "⚔️💨🧑🏻", response: "سانيمي" },
    { question: "⚔️🧑🏻☁️", response: "توكيتو" },
    { question: "⚔️👩🏻🦋", response: "شينوبو" },
    { question: "⚔️👩🏻🩷", response: "ميتسوري" },
    { question: "🧑🏻🪨⚔️", response: "جيومي" },
    { question: "⚔️🧑🏻🎇🎆", response: "تينغن" },
    { question: "🧑🎩🔥", response: "سابو" },
    { question: "🐜👑💪🏻", response: "ميريوم" },
    { question: "😈🏺", response: "جيوكو" },
    { question: "🎭👩🏻👁️", response: "الوكا" },
    { question: "😈🎻👩🏻", response: "ناكيمي" },
    { question: "😎🥶❄️👁️", response: "غوجو" },
    { question: "😊👩🏻💰", response: "نامي" },
    { question: "💰☠️👑🏴‍☠️", response: "روجر" },
    { question: "👦🏻🛹⚡", response: "كيلوا" },
    { question: "🌙🦑🧑🏻‍🏫", response: "كورو" },
    { question: "🐸🍻🔞", response: "جيرايا" },
    { question: "🎤🦑⚔️", response: "كيلر بي" },
    { question: "🕵🏻‍♂️💊🛹", response: "كونان" },
    { question: "👁️🗨️👦🏻🔴", response: "ساسكي" },
    { question: "👨🏻‍🦳⚔️👁️", response: "مادارا" },
    { question: "🎭👨🏻🦊", response: "ايتاتشي" },
    { question: "👨🏻‍🦲👁️⚫", response: "كاكاشي" },
    { question: "👩🏻💜👁️", response: "هيناتا" },
    { question: "👦🏻🔵🍃", response: "غون" },
    { question: "👨🏻💥🧨", response: "باكوغو" },
    { question: "👦🏻🟢💪🏻", response: "ميدوريا" },
    { question: "👨🏻⚡🔵", response: "كيلوا" },
    { question: "👨🏻🎩🎲", response: "هيسوكا" },
    { question: "👦🏻🧡👊🏻", response: "ايتشيغو" },
    { question: "👨🏻👒⚔️", response: "زورو" },
    { question: "👨🏻🍖👑", response: "لوفي" },
    { question: "👨🏻‍🍳🚬🦵🏻", response: "سانجي" },
    { question: "👩🏻🍊🧭", response: "نامي" },
    { question: "💀🎸🎶", response: "بروك" },
    { question: "👩🏻🌹📚", response: "روبن" },
    { question: "🤖🔩💪🏻", response: "فرانكي" },
    { question: "👑🐉🔥", response: "اكاينو" },
    { question: "👩🏻🐍🔪", response: "بوا هانكوك" },
    { question: "👨🏻⚓️👑", response: "وايت بيرد" },
    { question: "👨🏻🌪️👁️", response: "دراغون" },
    { question: "👦🏻🔴👊🏻", response: "ناروتو" },
    { question: "👨🏻🔵❄️", response: "هاكو" },
    { question: "👩🏻🌸💊", response: "تسونادي" },
    { question: "👨🏻🟡⚡", response: "ميناتو" },
    { question: "👩🏻🔴💃", response: "ميراي" },
    { question: "👦🏻🟢🐉", response: "غوكو" },
    { question: "👨🏻🔵👑", response: "فيجيتا" },
    { question: "👨🏻🟡🍚", response: "غوهان" },
    { question: "👨🏻🟣💀", response: "بيكولو" },
    { question: "👩🏻🔵👽", response: "بولما" },
    { question: "👨🏻🟠🐱", response: "كيرو" },
    { question: "👦🏻⚫👁️", response: "ساسكي" },
    { question: "👩🏻🟡💫", response: "هيناتا" },
    { question: "👨🏻🟢🍃", response: "ياماتو" },
    { question: "👩🏻🔴🎭", response: "كونان" },
    { question: "👨🏻🟣🗡️", response: "اينوسكي" },
    { question: "👩🏻🟢🐍", response: "ميتسوري" },
    { question: "👨🏻🔵💧", response: "غيو" },
    { question: "👩🏻🟣🦋", response: "شينوبو" },
    { question: "👨🏻🟡🔥", response: "رينغوكو" },
    { question: "👩🏻🟠💨", response: "سانيمي" },
    { question: "👨🏻⚪☁️", response: "توكيتو" },
    { question: "👨🏻🟤🪨", response: "جيومي" },
    { question: "👨🏻🎇🎆", response: "تينغن" },
    { question: "👩🏻👁️🎭", response: "الوكا" },
    { question: "👨🏻🥶❄️", response: "غوجو" },
    { question: "👩🏻💰🧭", response: "نامي" },
    { question: "👑💀🏴‍☠️", response: "روجر" },
    { question: "👨🏻🛹⚡", response: "كيلوا" },
    { question: "👨🏻‍🏫🦑🌙", response: "كورو" },
    { question: "👨🏻🍻🐸", response: "جيرايا" },
    { question: "👨🏻🎤🦑", response: "كيلر بي" },
    { question: "👦🏻💊🕵️", response: "كونان" },
    { question: "👨🏻👊🏻🦲", response: "سايتما" },
    { question: "👦🏻📓🍎", response: "لايت" }
];

let handler = async (m, { conn, usedPrefix }) => {
    try {
        const chatId = m.chat;
        
        if (global.games.emoji && global.games.emoji[chatId]) {
            await m.reply(`${EMOJI} *يوجد سؤال نشط هنا!*`);
            return;
        }

        let json = emojiQuestions[Math.floor(Math.random() * emojiQuestions.length)];

        const bodyText = `${EMOJI}━━━[ *🎮 لعبة تخمين الإيموجي* ]━━━${EMOJI}

🎭 *الإيموجيات:* ${json.question}

⏰ *الوقت:* ${(timeout / 1000)} ثانية
🎯 *الجائزة:* ${poin} نقطة

${EMOJI} *فك الشفرة واكتب الإجابة في الرد*`;

        // ✅ إرسال الصورة + أزرار
        await conn.sendButton(m.chat, {
            imageUrl: MAIN_IMAGE,
            bodyText: bodyText,
            footerText: `${EMOJI} ${BOT_NAME}`,
            buttons: [
                {
                    name: 'quick_reply',
                    params: {
                        display_text: `${EMOJI} انسحب`,
                        id: `.انسحب`
                    }
                }
            ],
            mentions: [m.sender],
            newsletter: {
                name: CHANNEL_NAME,
                jid: CHANNEL_JID
            },
            interactiveConfig: { buttons_limits: 1 }
        }, m);

        global.games.emoji = global.games.emoji || {};
        global.games.emoji[chatId] = {
            answer: json.response.toLowerCase(),
            correctAnswer: json.response,
            emojis: json.question,
            startTime: Date.now(),
            timeout: setTimeout(async () => {
                if (global.games.emoji && global.games.emoji[chatId]) {
                    await m.reply(`${EMOJI} *⏰ انتهى الوقت!*\n🎭 *الإيموجيات:* ${json.question}\n✅ *الإجابة:* ${json.response}`);
                    delete global.games.emoji[chatId];
                }
            }, timeout),
            attempts: 0,
            hintsGiven: []
        };

    } catch (error) {
        console.error(`${EMOJI} خطأ:`, error);
        await m.reply(`${EMOJI} *حدث خطأ في تشغيل اللعبة!*`);
    }
}

// ✅ معالج الإجابات
handler.before = async (m, { conn }) => {
    try {
        if (m.isBaileys || !m.text) return false;
        
        const chatId = m.chat;
        const game = global.games.emoji ? global.games.emoji[chatId] : null;
        
        if (!game) return false;

        let userAnswer = m.text.toLowerCase().trim();

        // ✅ معالجة زر الانسحاب
        if (m.body === '.انسحب' || userAnswer === 'انسحب') {
            clearTimeout(game.timeout);
            await m.reply(`${EMOJI} *🚪 تم الانسحاب!*\n🎭 *الإيموجيات:* ${game.emojis}\n✅ *الإجابة:* ${game.correctAnswer}`);
            delete global.games.emoji[chatId];
            return true;
        }

        // ✅ الإجابة الصحيحة
        if (userAnswer === game.answer) {
            clearTimeout(game.timeout);
            
            const timeTaken = Math.floor((Date.now() - game.startTime) / 1000);
            
            // ✅ إضافة النقاط
            if (global.db?.users[m.sender]) {
                global.db.users[m.sender].xp = (global.db.users[m.sender].xp || 0) + poin;
            }
            
            await m.reply(`${EMOJI}━━━[ *🎉 إجابة صحيحة!* ]━━━${EMOJI}

🏆 *الفائز:* ${m.pushName || 'مستخدم'}
🎭 *الإيموجيات:* ${game.emojis}
✅ *الإجابة:* ${game.correctAnswer}
💰 *الجائزة:* ${poin} نقطة
⏱️ *الوقت:* ${timeTaken} ثانية

${EMOJI} *${BOT_NAME}*`);
            
            delete global.games.emoji[chatId];
            return true;
        }

        // ✅ إجابة خاطئة
        game.attempts++;
        
        let extraHint = '';
        if (game.attempts >= 2 && !game.hintsGiven.includes('firstLetter')) {
            extraHint = `\n💡 *الحرف الأول:* ${game.correctAnswer.charAt(0)}`;
            game.hintsGiven.push('firstLetter');
        } else if (game.attempts >= 4 && !game.hintsGiven.includes('length')) {
            extraHint = `\n💡 *عدد الأحرف:* ${game.correctAnswer.length}`;
            game.hintsGiven.push('length');
        }

        await m.reply(`${EMOJI} *❌ إجابة خاطئة!*${extraHint}\n🎭 *الإيموجيات:* ${game.emojis}\n📊 *المحاولة:* ${game.attempts}`);

        return true;

    } catch (error) {
        console.error(`${EMOJI} خطأ في معالجة الإجابة:`, error);
        return false;
    }
}

handler.help = ['ايموجي'];
handler.tags = ['game'];
handler.command = /^(ايموجي|emoji)$/i;
handler.group = true;

export default handler;