// 🕸 ملف: ترتيب.js - لعبة ترتيب الحروف - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const GAME_TIME = 60000;
const REWARD = 500;
const MAX_WRONG_REACTS = 3;

const buildContext = () => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

// ─────────────── أدوات مساعدة ───────────────

// توحيد النص: بيشيل التشكيل والهمزات والمسافات الزايدة
const normalize = (str) =>
    String(str || '')
        .toLowerCase()
        .replace(/[\u064B-\u0652\u0640]/g, '')
        .replace(/[أإآٱ]/g, 'ا')
        .replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه')
        .replace(/\s+/g, ' ')
        .trim();

const getUsers = () => {
    if (!global.db) global.db = {};
    if (global.db.data?.users) return global.db.data.users;
    if (global.db.users) return global.db.users;
    if (!global.db.data) global.db.data = {};
    if (!global.db.data.users) global.db.data.users = {};
    return global.db.data.users;
};

const getUser = (jid) => {
    const users = getUsers();
    if (!users[jid]) users[jid] = { exp: 0 };
    return users[jid];
};

const loadQuestions = () => {
    const candidates = [
        path.join(__dirname, '../../src/game/miku3.json'),
        path.join(process.cwd(), 'src/game/miku3.json'),
        path.join(process.cwd(), 'game/miku3.json'),
        path.join(__dirname, '../miku3.json'),
    ];

    const filePath = candidates.find((p) => fs.existsSync(p));
    if (!filePath) throw new Error('NOT_FOUND');

    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const list = Array.isArray(data) ? data.filter((x) => x?.question && x?.response) : [];
    if (!list.length) throw new Error('EMPTY');

    console.log(`${EMOJI} ملف الأسئلة: ${filePath}`);
    return list;
};

const endGame = (conn, id) => {
    const game = conn.tekateki?.[id];
    if (!game) return;
    clearTimeout(game.timer);
    delete conn.tekateki[id];
};

// ─────────────── الأمر الرئيسي ───────────────

const handler = async (m, { conn, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const id = m.chat;

    conn.tekateki = conn.tekateki || {};

    const send = async (text, quoted = m) => {
        try {
            return await conn.sendMessage(id, { text, contextInfo: buildContext() }, { quoted });
        } catch (e) {
            console.error(`${EMOJI} فشل إرسال رسالة:`, e?.message);
            return null;
        }
    };

    if (conn.tekateki[id]) {
        return send(`${EMOJI} ❌ *هناك لعبة ترتيب نشطة بالفعل!*\n💡 للخروج اكتب: استسلم`);
    }

    // قراءة الأسئلة
    let questions;
    try {
        questions = loadQuestions();
    } catch (e) {
        console.error(`${EMOJI} خطأ في قراءة ملف الأسئلة:`, e?.message);
        await m.react('💥').catch(() => {});
        return send(
            e.message === 'EMPTY'
                ? `${EMOJI} ⚠️ *ملف الأسئلة فاضي أو شكله غلط*`
                : `${EMOJI} ⚠️ *تعذر العثور على ملف الأسئلة*\n📌 تأكد من وجود ملف miku3.json في مجلد src/game/`
        );
    }

    const json = questions[Math.floor(Math.random() * questions.length)];

    const caption =
        `${EMOJI}━━━━━━━━━━━━━━━━${EMOJI}\n` +
        `*🔄 رَتِّبِ الْحُرُوفَ*\n` +
        `${EMOJI}━━━━━━━━━━━━━━━━${EMOJI}\n\n` +
        `📌 *الكلمة المبعثرة:*\n` +
        `┃ ‣ *${json.question}*\n\n` +
        `⏰ *الوقت:* ${GAME_TIME / 1000} ثانية\n` +
        `💰 *الجائزة:* ${REWARD} نقطة\n\n` +
        `📌 *أرسل الإجابة الصحيحة مباشرة*\n` +
        `📌 *للخروج اكتب:* استسلم\n` +
        `${EMOJI} *${BOT_NAME}*`;

    const msg = await send(caption);
    if (!msg) return;

    // نسجل اللعبة بعد نجاح الإرسال
    conn.tekateki[id] = {
        msg,
        json,
        reward: REWARD,
        wrong: new Set(),
        wrongBy: {},
        timer: setTimeout(async () => {
            if (!conn.tekateki?.[id]) return;
            delete conn.tekateki[id];

            await send(
                `${EMOJI} ⏰ *انتهى الوقت!*\n\n` +
                `✅ *الإجابة الصحيحة:* *${json.response}*\n\n` +
                `💡 اكتب *${prefix}${command || 'ترتيب'}* للعب مرة أخرى.`
            );
        }, GAME_TIME),
    };
};

// ─────────────── معالجة الإجابات ───────────────

handler.before = async (m, { conn, usedPrefix }) => {
    const id = m.chat;
    const game = conn.tekateki?.[id];
    if (!game) return;

    if (m.fromMe || m.isBaileys) return;

    const raw = String(m.text || '').trim();
    if (!raw) return;

    // تجاهل الأوامر (الرسائل اللي بتبدأ ببريفكس)
    if (/^[.!#/]/.test(raw) || (usedPrefix && raw.startsWith(usedPrefix))) return;

    const send = async (text) => {
        try {
            await conn.sendMessage(id, { text, contextInfo: buildContext() }, { quoted: m });
        } catch (e) {
            console.error(`${EMOJI} فشل إرسال رسالة:`, e?.message);
        }
    };

    const answer = normalize(raw);
    const correct = normalize(game.json.response);

    // ───── استسلام ─────
    if (['استسلم', 'استسلام'].includes(answer)) {
        endGame(conn, id);
        await send(
            `${EMOJI} 🏳️ *استسلمت!*\n\n` +
            `🎯 *الإجابة الصحيحة:* *${game.json.response}*\n\n` +
            `💡 اكتب *${usedPrefix || '.'}ترتيب* للعب مجدداً.`
        );
        return true;
    }

    // ───── إجابة صحيحة ─────
    if (answer === correct) {
        endGame(conn, id);

        const user = getUser(m.sender);
        user.exp = (user.exp || 0) + game.reward;

        await send(
            `${EMOJI}━━━━━━━━━━━━━━━━${EMOJI}\n` +
            `*🎉 إِجَابَةٌ صَحِيحَةٌ!*\n` +
            `${EMOJI}━━━━━━━━━━━━━━━━${EMOJI}\n\n` +
            `✅ *الكلمة الصحيحة:* *${game.json.response}*\n` +
            `💰 *ربحت:* *+${game.reward}* نقطة\n` +
            `💵 *رصيدك:* *${(user.exp || 0).toLocaleString('ar-EG')}* نقطة\n\n` +
            `🎮 *اكتب ${usedPrefix || '.'}ترتيب للعب مرة أخرى*\n` +
            `${EMOJI} *${BOT_NAME}*`
        );
        return true;
    }

    // ───── إجابة غلط ─────
    if (game.wrong.has(answer)) return;
    game.wrong.add(answer);

    game.wrongBy[m.sender] = (game.wrongBy[m.sender] || 0) + 1;

    if (game.wrongBy[m.sender] <= MAX_WRONG_REACTS) {
        await conn.sendMessage(id, { react: { text: '❌', key: m.key } }).catch(() => {});
    }

    return false;
};

handler.help = ['ترتيب'];
handler.tags = ['game'];
handler.command = ['ترتيب', 'tartib', 'rtb'];

export default handler;