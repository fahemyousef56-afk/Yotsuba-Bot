const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
};

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m });

const QUESTIONS = [
  { q: 'كم عدد أركان الإسلام؟', answers: ['5', 'خمسة'] },
  { q: 'ما اسم أول سورة في القرآن؟', answers: ['الفاتحة'] },
  { q: 'كم عدد الصلوات المفروضة في اليوم؟', answers: ['5', 'خمسة'] },
  { q: 'ما الشهر الذي يصومه المسلمون؟', answers: ['رمضان'] },
  { q: 'إلى أي مدينة هاجر النبي ﷺ؟', answers: ['المدينة', 'المدينة المنورة'] }
];

const handler = async (m, { conn }) => {
  global.religiousQuiz ||= {};

  if (global.religiousQuiz[m.chat]) {
    clearTimeout(global.religiousQuiz[m.chat].timer);
    delete global.religiousQuiz[m.chat];
  }

  const item = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
  global.religiousQuiz[m.chat] = {
    answers: item.answers,
    timer: setTimeout(() => delete global.religiousQuiz[m.chat], 30000)
  };
  await send(conn, m, `🕌 *سؤال إسلامي*\n\n${item.q}\n\n⏱️ لديك 30 ثانية للإجابة`);
};

handler.before = async (m, { conn }) => {
  const game = global.religiousQuiz?.[m.chat];
  if (!game || !m.text) return false;
  const answer = m.text.trim().toLowerCase();
  if (!game.answers.some(value => value.toLowerCase() === answer)) return false;
  clearTimeout(game.timer);
  delete global.religiousQuiz[m.chat];
  await send(conn, m, '✅ إجابة صحيحة، بارك الله فيك 🌙');
  return true;
};

handler.command = ['اسئلة_دينية', 'اسئلة_اسلامية', 'سؤال_ديني'];
handler.usage = ['اسئلة_دينية'];
handler.category = 'games';
export default handler;