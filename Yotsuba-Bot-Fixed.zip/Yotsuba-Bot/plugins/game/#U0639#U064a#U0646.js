// 🕸 ملف: عين.js - لعبة عيون الأنمي - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const GAME_TIME = 30000;
const MAX_ATTEMPTS = 2;
const REWARD_XP = 500;
const DATA_URL = 'https://raw.githubusercontent.com/DK3MK/worker-bot/main/eye.json';

const buildContext = () => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

// ─────────────── أدوات مساعدة ───────────────

const shuffle = (arr) => {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
};

const fetchData = async () => {
    const res = await fetch(DATA_URL, { signal: AbortSignal.timeout(15000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    if (!Array.isArray(data) || !data.length) throw new Error('فشل جلب البيانات');

    return data.filter((x) => x?.name && x?.img);
};

const endGame = (conn, id) => {
    const game = conn.eyeGame?.[id];
    if (!game) return;
    clearTimeout(game.timer);
    delete conn.eyeGame[id];
};

// ─────────────── الهاندلر ───────────────

const handler = async (m, { conn, command, usedPrefix }) => {
    const prefix = usedPrefix || '.';
    const cmd = String(command || '').toLowerCase();
    const id = m.chat;

    const send = async (text) => {
        try {
            await conn.sendMessage(id, { text, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(text);
        }
    };

    conn.eyeGame = conn.eyeGame || {};

    // ───── معالجة الأزرار (الإجابات) ─────
    if (cmd.startsWith('مجوب_')) {
        const game = conn.eyeGame[id];

        if (!game) {
            return send(`${EMOJI} *لا توجد لعبة نشطة! ابدأ بـ ${prefix}عين*`);
        }

        const index = parseInt(cmd.split('_')[1], 10);
        if (isNaN(index) || index < 1 || index > game.options.length) {
            return send(`${EMOJI} *اختيار غير صالح! اختر بين (1-${game.options.length})*`);
        }

        // محاولات كل لاعب لوحده
        game.attemptsBy = game.attemptsBy || {};
        const used = game.attemptsBy[m.sender] || 0;

        if (used >= MAX_ATTEMPTS) {
            return send(`${EMOJI} *خلصت محاولاتك، سيب غيرك يجرب* 😅`);
        }

        const selected = game.options[index - 1];

        if (selected === game.correctAnswer) {
            endGame(conn, id);

            let xpMsg = '';
            const user = global.db?.data?.users?.[m.sender] || global.db?.users?.[m.sender];
            if (user) {
                user.xp = (user.xp || 0) + REWARD_XP;
                xpMsg = `\n💰 *+${REWARD_XP}XP*`;
            }

            return send(`🎉 *صحيح!*${xpMsg}\n💡 *الإجابة: ${game.correctAnswer}*`);
        }

        game.attemptsBy[m.sender] = used + 1;
        const left = MAX_ATTEMPTS - game.attemptsBy[m.sender];

        return send(
            left > 0
                ? `*❌ غلط!* 😅\n🛠️ *محاولاتك المتبقية:* ${left}`
                : `*😢 خلصت محاولاتك!*`
        );
    }

    // ───── بدء اللعبة ─────
    if (conn.eyeGame[id]) {
        return send(`${EMOJI} *فيه لعبة شغالة!*`);
    }

    try {
        const data = await fetchData();
        const selected = data[Math.floor(Math.random() * data.length)];
        const { img, name } = selected;

        // 3 اختيارات غلط مختلفة + الصح
        const others = shuffle([...new Set(data.map((x) => x.name).filter((n) => n !== name))]).slice(0, 3);
        const options = shuffle([name, ...others]);

        // نسجل اللعبة الأول، وبعدين نبعت
        conn.eyeGame[id] = {
            correctAnswer: name,
            options,
            image: img,
            owner: m.sender,
            attemptsBy: {},
            timer: setTimeout(async () => {
                if (!conn.eyeGame[id]) return;
                delete conn.eyeGame[id];
                await send(`⌛ *انتهى الوقت!*\n💡 *الإجابة: ${name}*`).catch(() => {});
            }, GAME_TIME),
        };

        const bodyText =
            `👁 *لعبة عيون الأنمي*\n\n` +
            `⏱️ *الوقت: ${GAME_TIME / 1000} ثانية*\n` +
            `💰 *الجائزة: ${REWARD_XP}XP*\n` +
            `⚔️ *المحاولات: ${MAX_ATTEMPTS} لكل لاعب*\n` +
            `══════════════════\n\n` +
            `*اختر الإجابة الصحيحة 👇*`;

        try {
            if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

            await conn.sendButton(
                id,
                {
                    imageUrl: img,
                    bodyText,
                    footerText: `${EMOJI} ${BOT_NAME}`,
                    buttons: options.map((option, i) => ({
                        name: 'quick_reply',
                        params: {
                            display_text: `┊${i + 1}┊ ${option}`,
                            id: `${prefix}مجوب_${i + 1}`,
                        },
                    })),
                    mentions: [m.sender],
                    newsletter: {
                        name: CHANNEL_NAME,
                        jid: CHANNEL_JID,
                    },
                },
                m
            );
        } catch (e) {
            console.error('فشل sendButton، هبعت نص عادي:', e?.message);

            const list = options.map((o, i) => `${i + 1}. ${o}`).join('\n');

            await conn
                .sendMessage(
                    id,
                    {
                        image: { url: img },
                        caption: `${bodyText}\n\n${list}\n\n📝 *جاوب بكتابة:* ${prefix}مجوب_1 (أو 2 أو 3 أو 4)\n\n👤 *المطور:* ${DEVELOPER}`,
                        contextInfo: buildContext(),
                    },
                    { quoted: m }
                )
                .catch((err) => {
                    // لو حتى الصورة فشلت، نلغي اللعبة
                    endGame(conn, id);
                    throw err;
                });
        }
    } catch (e) {
        endGame(conn, id);
        console.error(`${EMOJI} خطأ:`, e);
        await send(`${EMOJI} *حدث خطأ، حاول مرة أخرى*`);
    }
};

handler.help = ['عين', 'عيون'];
handler.tags = ['ألعاب'];
handler.command = /^(عين|عيون|مجوب_\d+)$/i;

export default handler;