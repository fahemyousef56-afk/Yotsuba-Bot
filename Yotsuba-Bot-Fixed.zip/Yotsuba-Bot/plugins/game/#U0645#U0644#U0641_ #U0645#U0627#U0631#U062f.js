// 🌸 ملف: مارد.js - لعبة المارد الأزرق - 𝑩𝜣𝑻⃝𖤐

import axios from "axios";
import fetch from 'node-fetch';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/j9VskLBx/IMG-20261025-222953-147.jpg';

const api_obito = "https://mr-obito-api.vercel.app/api";

let handler = async function (m, { text, conn }) {
    if (!conn.aki) conn.aki = {};
    const sessionKey = `${m.chat}-${m.sender}`;
    const session = conn.aki[sessionKey];

    // ✅ القائمة الرئيسية (بدون text)
    if (!text) {
        try {
            await conn.sendButton(m.chat, {
                imageUrl: MAIN_IMAGE,
                bodyText: `${EMOJI}━━━[ *لعبة المارد الأزرق* ]━━━${EMOJI}

👑 *مرحباً بك يا ملك!*
🧞 هل أنت مستعد لتحدي المارد؟

${EMOJI} *${BOT_NAME}*`,
                footerText: `${EMOJI} ${BOT_NAME}`,
                buttons: [
                    {
                        name: 'quick_reply',
                        params: {
                            display_text: `${EMOJI} بدء اللعبة`,
                            id: `.مارد ابدا`
                        }
                    },
                    {
                        name: 'quick_reply',
                        params: {
                            display_text: `📘 المساعدة`,
                            id: `.مارد المساعدة`
                        }
                    }
                ],
                mentions: [m.sender],
                newsletter: {
                    name: CHANNEL_NAME,
                    jid: CHANNEL_JID
                },
                interactiveConfig: { buttons_limits: 2 }
            }, m);
        } catch (e) {
            console.log(`${EMOJI} فشل:`, e.message);
            await m.reply(`${EMOJI} *مرحباً!*\n.مارد ابدا - للبدء\n.مارد المساعدة - للمساعدة`);
        }
        return;
    }

    // ✅ المساعدة
    if (text === "المساعدة") {
        return m.reply(
            `${EMOJI}━━━[ *أوامر لعبة المارد* ]━━━${EMOJI}

📌 *.مارد ابدا* - بدء اللعبة
📌 *.مارد حذف* - حذف الجلسة
📌 *.مارد رجوع* - خطوة للخلف

📝 *الإجابات:* نعم، لا، ربما، ربما لا، لا أعرف

${EMOJI} *${BOT_NAME}*`
        );
    }

    // ✅ بدء اللعبة
    if (text === "ابدا") {
        try {
            const { data } = await axios.post(`${api_obito}/akinator_start`);
            if (!data.session || !data.signature) return m.reply(`${EMOJI} *فشل بدء الجلسة*`);

            conn.aki[sessionKey] = {
                session: data.session,
                signature: data.signature,
                step: 0,
                progression: 0,
            };

            return await sendQuestion(m.chat, data.question, data.akitude_url || null, m, conn, sessionKey);
        } catch (err) {
            console.error(err);
            return m.reply(`${EMOJI} *حدث خطأ أثناء بدء اللعبة*`);
        }
    }

    // ✅ حذف الجلسة
    if (text === "حذف") {
        if (!session) return m.reply(`${EMOJI} *لا توجد جلسة نشطة*`);
        delete conn.aki[sessionKey];
        return m.reply(`${EMOJI} *تم حذف الجلسة بنجاح*`);
    }

    // ✅ الرجوع
    if (text === "رجوع") {
        if (!session) return m.reply(`${EMOJI} *لا توجد جلسة نشطة*`);
        try {
            const { data } = await axios.post(`${api_obito}/akinator_back`, {
                session: session.session,
                signature: session.signature,
                step: session.step,
                progression: session.progression,
                cm: "false",
            });

            conn.aki[sessionKey].step = data.step;
            conn.aki[sessionKey].progression = data.progression;

            return await sendQuestion(m.chat, data.question, data.akitude_url || null, m, conn, sessionKey);
        } catch (err) {
            console.error(err);
            return m.reply(`${EMOJI} *لا يمكن الرجوع حالياً*`);
        }
    }

    // ✅ الإجابات
    const answers = { "نعم": 0, "لا": 1, "لا أعرف": 2, "ربما": 3, "ربما لا": 4 };
    if (answers.hasOwnProperty(text)) {
        if (!session) return m.reply(`${EMOJI} *لا توجد جلسة نشطة. ابدأ بـ .مارد ابدا*`);

        try {
            const { data } = await axios.post(`${api_obito}/akinator_answer`, {
                session: session.session,
                signature: session.signature,
                step: session.step,
                progression: session.progression,
                answer: answers[text],
                cm: "false",
                sid: "NaN",
                question_filter: "string",
            });

            // ✅ النتيجة النهائية
            if (data.name_proposition) {
                delete conn.aki[sessionKey];
                await conn.sendButton(m.chat, {
                    imageUrl: data.photo || MAIN_IMAGE,
                    bodyText: `${EMOJI}━━━[ *🧞 تخمين المارد* ]━━━${EMOJI}

👑 *${data.name_proposition}*
📝 ${data.description_proposition || 'شخصية غامضة!'}

${EMOJI} *${BOT_NAME}*`,
                    footerText: `${EMOJI} ${BOT_NAME}`,
                    buttons: [
                        {
                            name: 'quick_reply',
                            params: {
                                display_text: `${EMOJI} العب مرة أخرى`,
                                id: `.مارد ابدا`
                            }
                        },
                        {
                            name: 'quick_reply',
                            params: {
                                display_text: `${EMOJI} الرئيسية`,
                                id: `.مارد`
                            }
                        }
                    ],
                    mentions: [m.sender],
                    newsletter: {
                        name: CHANNEL_NAME,
                        jid: CHANNEL_JID
                    },
                    interactiveConfig: { buttons_limits: 2 }
                }, m);
                return;
            }

            conn.aki[sessionKey].step = data.step;
            conn.aki[sessionKey].progression = data.progression;

            return await sendQuestion(m.chat, data.question, data.akitude_url || null, m, conn, sessionKey);
        } catch (err) {
            console.error(err);
            return m.reply(`${EMOJI} *حدث خطأ أثناء الإجابة*`);
        }
    }
};

// ✅ دالة إرسال السؤال مع الأزرار
async function sendQuestion(jid, question, imgUrl, m, conn, sessionKey) {
    try {
        const session = conn.aki[sessionKey];
        const buttons = [
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'نعم ✅', 
                    id: `.مارد نعم` 
                } 
            },
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'لا ❌', 
                    id: `.مارد لا` 
                } 
            },
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'لا أعرف 🤔', 
                    id: `.مارد لا أعرف` 
                } 
            },
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'ربما 🤷‍♂️', 
                    id: `.مارد ربما` 
                } 
            },
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'ربما لا 👎', 
                    id: `.مارد ربما لا` 
                } 
            },
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'رجوع ↩️', 
                    id: `.مارد رجوع` 
                } 
            },
            { 
                name: 'quick_reply', 
                params: { 
                    display_text: 'إنهاء 🛑', 
                    id: `.مارد حذف` 
                } 
            }
        ];

        const bodyText = `${EMOJI}━━━[ *🧞 السؤال ${(session?.step || 0) + 1}* ]━━━${EMOJI}

${question}

${EMOJI} *اختر إجابتك 👇*`;

        await conn.sendButton(jid, {
            imageUrl: imgUrl || MAIN_IMAGE,
            bodyText: bodyText,
            footerText: `${EMOJI} ${BOT_NAME}`,
            buttons: buttons,
            mentions: [m.sender],
            newsletter: {
                name: CHANNEL_NAME,
                jid: CHANNEL_JID
            },
            interactiveConfig: { buttons_limits: 7 }
        }, m);

    } catch (e) {
        console.error(`${EMOJI} فشل إرسال السؤال:`, e);
        await conn.sendMessage(jid, { text: `${EMOJI} *السؤال:* ${question}` }, { quoted: m });
    }
}

handler.command = /^مارد$/i;
handler.category = 'game';

export default handler;