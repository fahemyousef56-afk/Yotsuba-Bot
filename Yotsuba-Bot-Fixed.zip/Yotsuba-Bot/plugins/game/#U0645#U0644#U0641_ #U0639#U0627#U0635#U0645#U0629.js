// 🌸 ملف: عاصمة.js - لعبة العواصم - 𝑩𝜣𝑻⃝𖤐

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/n8kt35J9/IMG-20261026-220710-367.jpg';

let timeout = 40000;
let poin = 500;

// قاعدة بيانات العواصم
const capitals = [
    { question: "ما هي عاصمة 🇪🇬 مصر؟", response: "القاهرة" },
    { question: "ما هي عاصمة 🇸🇦 السعودية؟", response: "الرياض" },
    { question: "ما هي عاصمة 🇦🇪 الإمارات؟", response: "أبو ظبي" },
    { question: "ما هي عاصمة 🇯🇴 الأردن؟", response: "عمان" },
    { question: "ما هي عاصمة 🇱🇧 لبنان؟", response: "بيروت" },
    { question: "ما هي عاصمة 🇶🇦 قطر؟", response: "الدوحة" },
    { question: "ما هي عاصمة 🇰🇼 الكويت؟", response: "مدينة الكويت" },
    { question: "ما هي عاصمة 🇧🇭 البحرين؟", response: "المنامة" },
    { question: "ما هي عاصمة 🇴🇲 عمان؟", response: "مسقط" },
    { question: "ما هي عاصمة 🇮🇶 العراق؟", response: "بغداد" },
    { question: "ما هي عاصمة 🇸🇾 سوريا؟", response: "دمشق" },
    { question: "ما هي عاصمة 🇾🇪 اليمن؟", response: "صنعاء" },
    { question: "ما هي عاصمة 🇩🇿 الجزائر؟", response: "الجزائر" },
    { question: "ما هي عاصمة 🇲🇦 المغرب؟", response: "الرباط" },
    { question: "ما هي عاصمة 🇹🇳 تونس؟", response: "تونس" },
    { question: "ما هي عاصمة 🇱🇾 ليبيا؟", response: "طرابلس" },
    { question: "ما هي عاصمة 🇸🇩 السودان？", response: "الخرطوم" },
    { question: "ما هي عاصمة 🇸🇴 الصومال？", response: "مقديشو" },
    { question: "ما هي عاصمة 🇲🇷 موريتانيا？", response: "نواكشوط" },
    { question: "ما هي عاصمة 🇺🇸 أمريكا؟", response: "واشنطن" },
    { question: "ما هي عاصمة 🇬🇧 بريطانيا؟", response: "لندن" },
    { question: "ما هي عاصمة 🇫🇷 فرنسا؟", response: "باريس" },
    { question: "ما هي عاصمة 🇩🇪 ألمانيا？", response: "برلين" },
    { question: "ما هي عاصمة 🇮🇹 إيطاليا؟", response: "روما" },
    { question: "ما هي عاصمة 🇪🇸 إسبانيا？", response: "مدريد" },
    { question: "ما هي عاصمة 🇨🇦 كندا؟", response: "أوتاوا" },
    { question: "ما هي عاصمة 🇦🇺 أستراليا؟", response: "كانبرا" },
    { question: "ما هي عاصمة 🇯🇵 اليابان؟", response: "طوكيو" },
    { question: "ما هي عاصمة 🇨🇳 الصين؟", response: "بكين" },
    { question: "ما هي عاصمة 🇷🇺 روسيا？", response: "موسكو" },
    { question: "ما هي عاصمة 🇮🇳 الهند؟", response: "نيودلهي" },
    { question: "ما هي عاصمة 🇧🇷 البرازيل？", response: "برازيليا" },
    { question: "ما هي عاصمة 🇦🇷 الأرجنتين？", response: "بوينس آيرس" },
    { question: "ما هي عاصمة 🇹🇷 تركيا؟", response: "أنقرة" },
    { question: "ما هي عاصمة 🇮🇷 إيران؟", response: "طهران" },
    { question: "ما هي عاصمة 🇰🇷 كوريا الجنوبية？", response: "سيول" },
    { question: "ما هي عاصمة 🇮🇩 إندونيسيا？", response: "جاكرتا" },
    { question: "ما هي عاصمة 🇿🇦 جنوب أفريقيا？", response: "بريتوريا" },
    { question: "ما هي عاصمة 🇳🇬 نيجيريا؟", response: "أبوجا" },
    { question: "ما هي عاصمة 🇲🇽 المكسيك؟", response: "مكسيكو سيتي" }
];

let handler = async (m, { conn, usedPrefix }) => {
    conn.capitalsGame = conn.capitalsGame || {};
    let id = m.chat;

    if (id in conn.capitalsGame) {
        await m.reply(`${EMOJI} *يوجد سؤال نشط!*`);
        return;
    }

    const randomIndex = Math.floor(Math.random() * capitals.length);
    const { question, response } = capitals[randomIndex];
    
    // إنشاء خيارات الأزرار
    let options = [response];
    let allResponses = capitals.map(c => c.response);
    while (options.length < 4) {
        let randomResponse = allResponses[Math.floor(Math.random() * allResponses.length)];
        if (!options.includes(randomResponse)) {
            options.push(randomResponse);
        }
    }
    const shuffledOptions = shuffleArray(options);

    const bodyText = `${EMOJI}━━━[ *🏛️ لعبة العواصم* ]━━━${EMOJI}

❓ *السؤال:* ${question}

⏰ *الوقت:* ${(timeout / 1000).toFixed(0)} ثانية
💰 *الجائزة:* ${poin} نقطة

${EMOJI} *اختر الإجابة الصحيحة 👇*`;

    // ✅ أزرار الخيارات
    const buttons = shuffledOptions.map((opt, i) => ({
        name: 'quick_reply',
        params: {
            display_text: `${i + 1}. ${opt}`,
            id: `.عاصمة_اجاب_${i + 1}`
        }
    }));

    // ✅ زر استسلم
    buttons.push({
        name: 'quick_reply',
        params: {
            display_text: `${EMOJI} استسلم`,
            id: `.عاصمة_استسلم`
        }
    });

    // ✅ إرسال الصورة + الأزرار
    await conn.sendButton(m.chat, {
        imageUrl: MAIN_IMAGE,
        bodyText: bodyText,
        footerText: `${EMOJI} ${BOT_NAME}`,
        buttons: buttons,
        mentions: [m.sender],
        newsletter: {
            name: CHANNEL_NAME,
            jid: CHANNEL_JID
        },
        interactiveConfig: { buttons_limits: 5 }
    }, m);

    // ✅ حفظ بيانات اللعبة
    let timer = setTimeout(async () => {
        if (conn.capitalsGame[id]) {
            await m.reply(`${EMOJI} *⌛ انتهى الوقت!*\n✅ *الإجابة:* ${response}`);
            delete conn.capitalsGame[id];
        }
    }, timeout);

    conn.capitalsGame[id] = {
        correctAnswer: response,
        options: shuffledOptions,
        correctIndex: shuffledOptions.indexOf(response) + 1,
        poin: poin,
        timer: timer,
        attempts: 2
    };
};

// ✅ معالجة الأزرار
handler.before = async (m, { conn }) => {
    conn.capitalsGame = conn.capitalsGame || {};
    let id = m.chat;

    if (!(id in conn.capitalsGame)) return;

    const gameData = conn.capitalsGame[id];
    const correctAnswer = gameData.correctAnswer.toLowerCase().trim();
    const rewardPoin = gameData.poin;

    // ✅ معالجة الأزرار
    if (m.body?.startsWith('.عاصمة_اجاب_')) {
        const selectedIndex = parseInt(m.body.replace('.عاصمة_اجاب_', ''));
        const selectedOption = gameData.options[selectedIndex - 1];
        const isCorrect = selectedOption.toLowerCase().trim() === correctAnswer;

        clearTimeout(gameData.timer);

        if (isCorrect) {
            if (global.db?.users[m.sender]) {
                global.db.users[m.sender].xp = (global.db.users[m.sender].xp || 0) + rewardPoin;
            }
            await m.reply(`🎉 *إجابة صحيحة!*\n💰 *+${rewardPoin} نقطة*\n✅ *الإجابة:* ${gameData.correctAnswer}`);
            delete conn.capitalsGame[id];
        } else {
            gameData.attempts -= 1;
            if (gameData.attempts > 0) {
                await m.reply(`*❌ غلط!*\n🛠️ *المحاولات المتبقية:* ${gameData.attempts}`);
            } else {
                await m.reply(`${EMOJI} *❌ غلط!* ✅ *الإجابة الصحيحة:* ${gameData.correctAnswer}`);
                delete conn.capitalsGame[id];
            }
        }
        return true;
    }

    // ✅ معالجة زر استسلم
    if (m.body === '.عاصمة_استسلم') {
        clearTimeout(gameData.timer);
        await m.reply(`${EMOJI} *استسلمت!*\n✅ *الإجابة:* ${gameData.correctAnswer}`);
        delete conn.capitalsGame[id];
        return true;
    }

    // ✅ معالجة الرد النصي (احتياطي)
    const userAnswer = m.text?.toLowerCase().trim();
    if (!userAnswer) return;

    if (userAnswer === 'استسلم' || userAnswer === 'استسلام') {
        clearTimeout(gameData.timer);
        await m.reply(`${EMOJI} *استسلمت!*\n✅ *الإجابة:* ${gameData.correctAnswer}`);
        delete conn.capitalsGame[id];
        return true;
    }

    const isCorrect = userAnswer === correctAnswer;
    if (isCorrect) {
        clearTimeout(gameData.timer);
        if (global.db?.users[m.sender]) {
            global.db.users[m.sender].xp = (global.db.users[m.sender].xp || 0) + rewardPoin;
        }
        await m.reply(`🎉 *إجابة صحيحة!*\n💰 *+${rewardPoin} نقطة*\n✅ *الإجابة:* ${gameData.correctAnswer}`);
        delete conn.capitalsGame[id];
        return true;
    } else {
        gameData.attempts -= 1;
        if (gameData.attempts > 0) {
            await m.reply(`*❌ غلط!*\n🛠️ *المحاولات المتبقية:* ${gameData.attempts}`);
        } else {
            await m.reply(`${EMOJI} *❌ غلط!* ✅ *الإجابة الصحيحة:* ${gameData.correctAnswer}`);
            delete conn.capitalsGame[id];
        }
        return true;
    }

    return false;
};

handler.help = ['عاصمة'];
handler.tags = ['game'];
handler.command = ['عاصمة', 'عواصم'];

function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

export default handler;