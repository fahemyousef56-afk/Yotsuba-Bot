// 🌸 ملف: شنق.js - لعبة املأ الفراغ - 𝑩𝜣𝑻⃝𖤐

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/jvyxZLgP/IMG-20261011-184649-319.jpg';

let timeout = 60000;
let poin = 200;

// ⭐⭐⭐ كلمات اللعبة ⭐⭐⭐
const hangmanWords = [
    { word: "تفاح", hint: "🍎 فاكهة حمراء", missingLetter: "ح" },
    { word: "موز", hint: "🍌 فاكهة صفراء", missingLetter: "ز" },
    { word: "برتقال", hint: "🍊 فاكهة برتقالية", missingLetter: "ق" },
    { word: "فراولة", hint: "🍓 فاكهة حمراء", missingLetter: "و" },
    { word: "عنب", hint: "🍇 فاكهة عنقودية", missingLetter: "ن" },
    { word: "جزر", hint: "🥕 خضار برتقالي", missingLetter: "ر" },
    { word: "طماطم", hint: "🍅 خضار أحمر", missingLetter: "ا" },
    { word: "خيار", hint: "🥒 خضار أخضر", missingLetter: "ي" },
    { word: "بصل", hint: "🧅 خضار له رائحة", missingLetter: "ص" },
    { word: "ثوم", hint: "🧄 خضار له رائحة قوية", missingLetter: "و" },
    { word: "اسد", hint: "🦁 ملك الغابة", missingLetter: "س" },
    { word: "نمر", hint: "🐯 حيوان مخطط", missingLetter: "م" },
    { word: "فيل", hint: "🐘 حيوان ضخم", missingLetter: "ي" },
    { word: "زرافة", hint: "🦒 أطول حيوان", missingLetter: "ف" },
    { word: "قرد", hint: "🐒 حيوان ذكي", missingLetter: "ر" },
    { word: "نسر", hint: "🦅 طائر جارح", missingLetter: "س" },
    { word: "ببغاء", hint: "🦜 طائر متكلم", missingLetter: "غ" },
    { word: "حمامة", hint: "🕊️ طائر السلام", missingLetter: "م" },
    { word: "عصفور", hint: "🐦 طائر صغير", missingLetter: "ف" },
    { word: "بط", hint: "🦆 طائر مائي", missingLetter: "ط" },
    { word: "قلم", hint: "✏️ أداة للكتابة", missingLetter: "ل" },
    { word: "كتاب", hint: "📚 يحتوي على صفحات", missingLetter: "ت" },
    { word: "مقص", hint: "✂️ أداة للقص", missingLetter: "ص" },
    { word: "مسطرة", hint: "📏 أداة للقياس", missingLetter: "ط" },
    { word: "ممحاة", hint: "🧼 أداة للمسح", missingLetter: "ح" },
    { word: "كرسي", hint: "🪑 للجلوس", missingLetter: "ر" },
    { word: "طاولة", hint: "🛋️ للأكل والعمل", missingLetter: "ا" },
    { word: "سرير", hint: "🛏️ للنوم", missingLetter: "ي" },
    { word: "خزانة", hint: "🚪 لحفظ الملابس", missingLetter: "ز" },
    { word: "مكتب", hint: "💼 للعمل", missingLetter: "ت" },
    { word: "شمس", hint: "☀️ تشرق في الصباح", missingLetter: "م" },
    { word: "قمر", hint: "🌙 يظهر في الليل", missingLetter: "م" },
    { word: "بحر", hint: "🌊 مياه مالحة", missingLetter: "ح" },
    { word: "نهر", hint: "🌊 مياه عذبة", missingLetter: "ه" },
    { word: "جبل", hint: "⛰️ مرتفع أرضي", missingLetter: "ب" },
    { word: "احمر", hint: "🔴 لون الدم", missingLetter: "م" },
    { word: "ازرق", hint: "🔵 لون البحر", missingLetter: "ر" },
    { word: "اخضر", hint: "🟢 لون النبات", missingLetter: "ض" },
    { word: "اصفر", hint: "🟡 لون الشمس", missingLetter: "ف" },
    { word: "اسود", hint: "⚫ لون الليل", missingLetter: "و" },
    { word: "حليب", hint: "🥛 شراب أبيض", missingLetter: "ل" },
    { word: "عصير", hint: "🧃 شراب فواكه", missingLetter: "ص" },
    { word: "قهوة", hint: "☕ شراب منبه", missingLetter: "ه" },
    { word: "شاي", hint: "🍵 شراب ساخن", missingLetter: "ي" },
    { word: "ماء", hint: "💧 شراب الحياة", missingLetter: "ا" },
    { word: "عسل", hint: "🍯 يصنعه النحل", missingLetter: "س" },
    { word: "سكر", hint: "🍬 مادة حلوة", missingLetter: "ك" },
    { word: "ملح", hint: "🧂 يستخدم في الطعام", missingLetter: "ل" },
    { word: "رز", hint: "🍚 طعام أساسي", missingLetter: "ز" },
    { word: "خبز", hint: "🍞 طعام يومي", missingLetter: "ب" }
];

let handler = async (m, { conn, usedPrefix }) => {
    conn.hangmanGames = conn.hangmanGames || {};
    let id = m.chat;

    if (id in conn.hangmanGames) {
        await m.reply(`${EMOJI} *يوجد لعبة نشطة!*`);
        return;
    }

    try {
        const randomWordData = hangmanWords[Math.floor(Math.random() * hangmanWords.length)];
        const { word, hint, missingLetter } = randomWordData;

        let displayWord = '';
        for (let i = 0; i < word.length; i++) {
            if (word[i] === missingLetter) {
                displayWord += '_ ';
            } else {
                displayWord += word[i] + ' ';
            }
        }
        displayWord = displayWord.trim();

        const game = conn.hangmanGames[id] = {
            word: word,
            hint: hint,
            missingLetter: missingLetter,
            displayWord: displayWord,
            startTime: Date.now(),
            attempts: 0,
            maxAttempts: 3,
            reward: poin,
            lastWrongGuess: ''
        };

        const bodyText = `${EMOJI}━━━[ *🎮 لعبة املأ الفراغ* ]━━━${EMOJI}

📝 *${game.displayWord}*

💡 ${hint}

⏰ *الوقت:* ${(timeout / 1000).toFixed(0)} ثانية
⚔️ *المحاولات:* 3
💰 *الجائزة:* ${game.reward} نقطة

${EMOJI} *أرسل الحرف الناقص في الرد*`;

        // ✅ زر واحد فقط - قناة البوت
        await conn.sendButton(m.chat, {
            imageUrl: MAIN_IMAGE,
            bodyText: bodyText,
            footerText: `${EMOJI} ${BOT_NAME}`,
            buttons: [
                {
                    name: 'cta_url',
                    params: {
                        display_text: `${EMOJI} قناة البوت`,
                        url: CHANNEL_LINK
                    }
                }
            ],
            mentions: [m.sender],
            newsletter: {
                name: CHANNEL_NAME,
                jid: CHANNEL_JID
            },
            interactiveConfig: { buttons_limits: 1 }
        }, m);

        game.timeout = setTimeout(async () => {
            if (conn.hangmanGames[id]) {
                await m.reply(`${EMOJI} *⌛ انتهى الوقت!*\n🎯 *الإجابة:* ${word}`);
                delete conn.hangmanGames[id];
            }
        }, timeout);

    } catch (error) {
        console.error(`${EMOJI} خطأ:`, error);
        await m.reply(`${EMOJI} *حدث خطأ!*`);
    }
};

// ✅ معالجة الإجابات
handler.before = async (m, { conn }) => {
    conn.hangmanGames = conn.hangmanGames || {};
    let id = m.chat;

    if (!(id in conn.hangmanGames)) return;

    const game = conn.hangmanGames[id];
    const guessedLetter = m.text?.toLowerCase().trim();

    if (!guessedLetter) return;

    // استسلم
    if (guessedLetter === 'استسلم' || guessedLetter === 'استسلام') {
        clearTimeout(game.timeout);
        await m.reply(`${EMOJI} *استسلمت!*\n🎯 *الإجابة:* ${game.word}`);
        delete conn.hangmanGames[id];
        return true;
    }

    // التحقق من الحرف
    if (guessedLetter.length !== 1 || !guessedLetter.match(/^[أ-يء-ي]$/)) {
        return false;
    }

    if (guessedLetter === game.lastWrongGuess) {
        return false;
    }

    if (guessedLetter === game.missingLetter) {
        clearTimeout(game.timeout);

        if (global.db?.users[m.sender]) {
            global.db.users[m.sender].xp = (global.db.users[m.sender].xp || 0) + game.reward;
        }

        const timeTaken = Math.floor((Date.now() - game.startTime) / 1000);

        await m.reply(`🎉 *إجابة صحيحة!*\n✅ *الكلمة:* ${game.word.toUpperCase()}\n⏱️ *الوقت:* ${timeTaken} ثانية\n💰 *+${game.reward} نقطة*`);
        delete conn.hangmanGames[id];
        return true;
    } else {
        game.attempts++;
        game.lastWrongGuess = guessedLetter;
        const attemptsLeft = game.maxAttempts - game.attempts;

        if (game.attempts >= game.maxAttempts) {
            clearTimeout(game.timeout);
            await m.reply(`${EMOJI} *انتهت المحاولات!*\n🎯 *الإجابة:* ${game.word}`);
            delete conn.hangmanGames[id];
            return true;
        }

        await m.reply(`${EMOJI} *❌ غلط!* متبقي *${attemptsLeft}* محاولة`);
        return true;
    }

    return false;
};

handler.help = ['شنق'];
handler.tags = ['game'];
handler.command = ['شنق'];

export default handler;