// 🕸 ملف: خمن.js - لعبة خمن الشخصية - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const MAIN_IMAGE = 'https://i.ibb.co/9kwhjfKH/IMG-20261013-113721-284.jpg';

const GAME_TIME = 60000;
const REWARD = 500;

const buildContext = () => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

// ⭐⭐⭐ الأسئلة ⭐⭐⭐
const guessQuestions = [
    { question: "شعر زهري عيون خضراء صغيرة وتقرأ الافكار", response: "انيا" },
    { question: "شعر احمر وعلى جسمه خطوط زرقاء قوي جدا ويصنع الدونات", response: "اكازا" },
    { question: "ملك القراصنة صاحب فاكهة الشيطان الأسطورية ومالك الكنز الأعظم", response: "روجر" },
    { question: "حاول الانتحار اكثر من مئة مرة ولم ينجح جسمه ضخم ويحمل بيده هراوة", response: "كايدو" },
    { question: "شعر اخضر و هو فتى صغير يحب الصيد وعنده رخصة", response: "غون" },
    { question: "شعره اشقر و وهو رمز للعدالة والبطولة اورث قوته لتلميذه وفقدها", response: "اول مايت" },
    { question: "شعره برتقالي كان انسان عادي واصبح كيان جديد يستخدم السيف", response: "ايتشيغو" },
    { question: "قوي للغاية لديه 6 عيون وشعره احمر", response: "كوكوشيبو" },
    { question: "تحب دراسة العمالقة واكتشافهم عضو في فيلق الاستطلاع واصبحت قائده", response: "هانجي" },
    { question: "شرير لديه فاكهتي شيطان ويتصف بالمكر", response: "تيتش" },
    { question: "احد مساعدي حكام الدمار و مدرب لبطلين في القصة", response: "ويس" },
    { question: "كان طفل صغير وانقتل ابوه وصار يسعى للانتقام", response: "ثورفين" },
    { question: "قوية وهادئة عيونها ارجوانية وشعرها بنفسجي وتحب الفراشات", response: "شينوبو" },
    { question: "لديه 3 زوجات ويحب البهرجة ولديه حاسة سمع قوية", response: "تينغن" },
    { question: "فتى مجرد من السحر لكن قوته البدنية كبيرة يقاتل باكثر من سيف", response: "استا" },
    { question: "فتى عديم القوة شعره اخضر اكتسب قوة جديده عن طريق تناول شعرة", response: "ميدوريا" },
    { question: "شعره وردي اكتسب القوة عن طريق تناول اصبع", response: "ايتادوري" },
    { question: "قط لون بشرته بنفسجي قوته غاشمة ويحب الاكل", response: "بيروس" },
    { question: "الة حرب مع انها فتاة صغيرة تسعى باحثة عن المشاعر الانسانية", response: "فايوليت" },
    { question: "فتى صغير لون شعره ابيض وهو ذكي جدا وتربى في ميتم", response: "نير" },
    { question: "عيون بنفسجيه و قويه شعره احمر نينجا من قرية المطر", response: "ناغاتو" },
    { question: "شعره اصفر يمتلك فاكهة شيطان من نوع لوغيا و يلقب ب إمبراطور اللهب", response: "سابو" },
    { question: "قوي و شخصيه عدوانية قدرتها تسمح له بالإنفجار", response: "باكوغو" },
    { question: "ولد بدون سحر و قوته تعتمد علي إثباته و شعره اسود", response: "ماش" },
    { question: "شخصيه شعرها اصفر و طويل ليس بشرياً و يستخدم سحر الضوء", response: "ليخت" },
    { question: "شخصيه قويه و مغروره و تمتلك فاكهة شيطان من نوع باراميسيا و تلقب ب امبراطورة القراصنة", response: "هانكوك" },
    { question: "طالب سابق لدى بيسكيت كروغر وقام بتدريب غون و كيلوا", response: "وينغ" },
    { question: "كان شرير وعدو البطل و الان اصبح طيب ومسالم ولديه ثلاثة عيون", response: "تينشيهان" },
    { question: "مقاتل من الدرجة الاولى يظهر نتيجة اتحاد بيكولا و غوهان", response: "بيكوهان" },
    { question: "واحد من النينجا الثلاثة الاسطوريين من كونوها و درب الهوكاجي الرابع", response: "جيرايا" },
    { question: "يستخدم تنفس الماء وهو احد الهاشيرا", response: "غيو" },
    { question: "امرأه كبيره في السن وهي مستخدمه ماهره للدمى وكانت تدرب الشينوبي على اسلوب الدمى", response: "تشيو" },
    { question: "حول نفسه الى دميه قويه تحوي انواع كثيره من الاسلحه ويستطيع ان ينقل قلبه من دميه الى اخرى", response: "ساسوري" },
    { question: "فتاه صغيره تحولت الى شيطانه وهي لا تاكل البشر", response: "نيزوكو" },
    { question: "احد افراد فريق مايت غاي وهو زميل لناروتو وينتمي لعشيره الهيوغا", response: "نيجي" },
    { question: "هبطت من الفضاء على الارض قبل 1000 عام واصبحت الحاميه للشجره المقدسه ولديها قوه خارقه", response: "كاغويا" },
    { question: "اصغر افراد عائله زولديك وهي خارقه عن السيطره بقدرتها منح الامنيات", response: "الوكا" },
    { question: "اميرة البياكوغان وزوجه الهوكاجي السابع", response: "هيناتا" },
    { question: "جبان جدا ولا تظهر قدرته الا عند النوم ويحب الفتيات", response: "زينتسو" },
    { question: "لون شعره اصفر واحمر وهو شخص طيب وقوي يستخدم تنفس النار", response: "رينغوكو" },
    { question: "شخصيه قصيره وبارده لكنه قوي ويجلد العمالقه", response: "ليفاي" },
    { question: "عشيره تتميز بقوتها وقدرتها القتاليه واعينهم القرمزيه وانعزالهم عن العالم الخارجي", response: "كورتا" },
    { question: "يلقب بالجوكر وهو منحرف والبعض يعتقد انه ام البطل", response: "هيسوكا" },
    { question: "شخصيه قويه جدا وهي برتبه ملك شياطين وعمره الفا عام", response: "انوس" },
    { question: "تعاني من الصمم منذ صغرها ولا تستطيع النطق بشكل صحيح واصبحت محط السخريه بين زملائها", response: "شوكو" },
    { question: "شخصيه قويه جدا تستخدم سحر الظلام وهو قائد لفرقه الثيران السوداء", response: "يامي" },
    { question: "يرتدي قناع لاخفاء وجهه وهو قائد لفرقه الفجر الذهبي ولديه قوه كبيره", response: "فانجانس" },
    { question: "شخصيه قويه جدا وغير متكبره بالرغم من منصبها الذي تشغله شعره اصفر ويرتدي رداء احمر", response: "يوليوس" },
    { question: "شخصيه بارده وقويه يرتدي نظارات شعره اصفر ويحترم الوقت والمواعيد", response: "نانامي" },
    { question: "شخصيه قويه للغايه ومثال عن الشر الحقيقي ويتصف بثقه كبيره وهو ذكي جدا وجوابك جزء من خطته", response: "ايزن" },
    { question: "متعطش للقتال لا يعرف اسم سيفه ويرتدي عصبه عين للتقليل من قوته حتى يستمتع في القتال", response: "زاراكي" },
    { question: "شخصيه هادئه وقويه يرتدي قبعه وكان قائد سابق في الغوتاي وهو مدرب البطل", response: "اوراهارا" },
    { question: "واحد من السايان قوي جدا ولكنه مهتم بالدراسه ومستقبله", response: "غوهان" },
    { question: "اصلع وعلى جبهته ستة نجوم وهو صديق البطل المقرب", response: "كيريلين" },
    { question: "فتاة ذات شعر ازرق تمتلك قوة التحكم في الزمن وتحب الحلويات", response: "توكا" },
    { question: "صياد أسطوري وأقوى نينجا في التاريخ معروف بعيونه المتقدة", response: "مادارا" },
    { question: "طبيب قراصنة يلبس قناع غزال ويحب المال", response: "كوريا" },
    { question: "فتاة ساحرة تمتلك كتاب غريموار وتتحدث مع النجوم", response: "يونو" },
    { question: "قائد فرقة الهوكاجي السابق معروف بقدرته على النسخ", response: "كاكاشي" },
    { question: "قرصان يلبس قبعة قش وطموحه أن يصبح ملك القراصنة", response: "لوفي" },
    { question: "ساموراي من وانو يمتلك ثلاث سيوف وطموح أن يصبح الأقوى", response: "زورو" },
    { question: "طباخ القراصنة حالم بالبحر الزمردي وشعره أشقر", response: "سانجي" },
    { question: "صياد كرات التنين وأقوى مقاتل في الكون", response: "غوكو" },
    { question: "أمير السايان الفخور والقتال في دمه", response: "فيجيتا" },
    { question: "فتاة ذات شعر وردي تمتلك قوة التحكم في الجاذبية", response: "ميكاسا" },
    { question: "بطل يرتدي بذلة النينجا الخضراء وأقوى جينتشوريكي", response: "ناروتو" },
    { question: "مطور الأسلحة العبقري وصديق لوفي المقرب", response: "فرانكي" },
    { question: "مؤرخة القراصنة تبحث عن التاريخ المفقود", response: "روبن" },
    { question: "ملاح القراصنة تكذب بأنوفها الطويلة", response: "أوسوب" },
    { question: "فتاة الرنة الطبيبة وتحلم بعلاج جميع الأمراض", response: "تشوبر" },
    { question: "ساحرة تعيش في الغابة وتحب الحيوانات", response: "بوا" },
    { question: "نينجا الجيناتيك وصاحب الشارينغان", response: "ساسكي" },
    { question: "قائد الجيش الثوري وأب لوفي", response: "دراغون" },
    { question: "أمير البحر وأقوى قرصان في العالم", response: "وايت بيرد" },
    { question: "فتاة من عشيرة الأوتسوتسوكي تمتلك قوة الآلهة", response: "كاغويا" },
    { question: "نينجا الطبية المشهورة بقدراتها العلاجية", response: "تسونادي" },
    { question: "فتاة التايتان العسكرية وأقوى جندية", response: "أني" },
    { question: "صياد الكنوز وصاحب الرؤية المستقبلية", response: "كاتاكوري" },
    { question: "فتاة التنين تمتلك قوة التحول وتحمي البشر", response: "لوسي" },
    { question: "سيد الظلال وأقوى مستخدم للجيو", response: "غارا" },
    { question: "فتاة السحر تمتلك قوة التحكم في العناصر", response: "ويندي" },
    { question: "ملك العالم السفلي وأقوى الشياطين", response: "ميلين" },
    { question: "فتاة الألعاب عبقرية التخطيط والاستراتيجية", response: "ساكورا" },
    { question: "سيد السيوف وأسرع نينجا في التاريخ", response: "ميناتو" },
    { question: "فتاة الأحلام تمتلك قوة الدخول في عقول الآخرين", response: "رين" },
];

// ─────────────── أدوات مساعدة ───────────────

const normalize = (str) =>
    String(str || '')
        .toLowerCase()
        .replace(/[\u064B-\u0652\u0640]/g, '')
        .replace(/[أإآٱ]/g, 'ا')
        .replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه')
        .replace(/\s+/g, ' ')
        .trim();

const shuffle = (arr) => {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
};

// 3 اختيارات غلط مختلفة + الصح
const getOptions = (correct) => {
    const others = [...new Set(guessQuestions.map((q) => q.response))].filter(
        (r) => normalize(r) !== normalize(correct)
    );
    return shuffle([correct, ...shuffle(others).slice(0, 3)]);
};

const getUser = (jid) => global.db?.data?.users?.[jid] || global.db?.users?.[jid];

const endGame = (conn, id) => {
    const game = conn.guessGame?.[id];
    if (!game) return;
    clearTimeout(game.timer);
    delete conn.guessGame[id];
};

// ─────────────── الأمر الرئيسي ───────────────

const handler = async (m, { conn, usedPrefix }) => {
    const prefix = usedPrefix || '.';
    const id = m.chat;

    conn.guessGame = conn.guessGame || {};

    const send = async (text) => {
        try {
            await conn.sendMessage(id, { text, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(text);
        }
    };

    if (conn.guessGame[id]) {
        return send(`${EMOJI} *يوجد سؤال نشط!*`);
    }

    const { question, response } = guessQuestions[Math.floor(Math.random() * guessQuestions.length)];
    const options = getOptions(response);

    // نسجل اللعبة الأول، وبعدين نبعت
    conn.guessGame[id] = {
        correct: response,
        options,
        reward: REWARD,
        wrongBy: new Set(),
        timer: setTimeout(async () => {
            if (!conn.guessGame?.[id]) return;
            delete conn.guessGame[id];
            await send(`${EMOJI} *⌛ انتهى الوقت!*\n✅ *الإجابة:* ${response}`).catch(() => {});
        }, GAME_TIME),
    };

    const bodyText =
        `${EMOJI}━━━[ *🎮 لعبة خمن الشخصية* ]━━━${EMOJI}\n\n` +
        `🧩 *الوصف:* ${question}\n\n` +
        `⏰ *الوقت:* ${GAME_TIME / 1000} ثانية\n` +
        `💰 *الجائزة:* ${REWARD} نقطة\n\n` +
        `${EMOJI} *اختر الإجابة الصحيحة 👇*`;

    try {
        if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

        await conn.sendButton(
            id,
            {
                imageUrl: MAIN_IMAGE,
                bodyText,
                footerText: `${EMOJI} ${BOT_NAME}`,
                buttons: options.map((opt, i) => ({
                    name: 'quick_reply',
                    params: {
                        display_text: `${i + 1}. ${opt}`,
                        id: `${prefix}خمن_${i + 1}`,
                    },
                })),
                mentions: [m.sender],
                newsletter: {
                    name: CHANNEL_NAME,
                    jid: CHANNEL_JID,
                },
            },
            m
        );
    } catch (e) {
        console.error('فشل sendButton، هبعت نص عادي:', e?.message);

        const list = options.map((o, i) => `${i + 1}. ${o}`).join('\n');

        try {
            await conn.sendMessage(
                id,
                {
                    text: `${bodyText}\n\n${list}\n\n📝 *اكتب اسم الشخصية للإجابة*`,
                    contextInfo: buildContext(),
                },
                { quoted: m }
            );
        } catch (err) {
            // لو حتى النص فشل، نلغي اللعبة
            endGame(conn, id);
            console.error(`${EMOJI} خطأ:`, err?.message);
        }
    }
};

// ─────────────── معالجة الإجابات (أزرار أو كتابة الاسم) ───────────────

handler.before = async (m, { conn }) => {
    if (m.fromMe || m.isBaileys) return;

    const id = m.chat;
    const game = conn.guessGame?.[id];
    if (!game) return;

    const raw = String(m.text || m.body || '').trim();
    if (!raw) return;

    let chosen = null;
    const btn = raw.match(/خمن_(\d)$/);

    if (btn) {
        chosen = game.options[parseInt(btn[1], 10) - 1];
    } else {
        chosen = game.options.find((o) => normalize(o) === normalize(raw));
    }

    if (!chosen) return;

    const send = async (text) => {
        try {
            await conn.sendMessage(id, { text, contextInfo: buildContext() }, { quoted: m });
        } catch (e) {
            console.error(`${EMOJI} فشل إرسال رسالة:`, e?.message);
        }
    };

    // محاولة واحدة لكل لاعب
    if (game.wrongBy.has(m.sender)) {
        await send(`${EMOJI} *جاوبت غلط قبل كده، سيب غيرك يجرب* 😅`);
        return true;
    }

    if (normalize(chosen) === normalize(game.correct)) {
        endGame(conn, id);

        let xpMsg = '';
        const user = getUser(m.sender);
        if (user) {
            user.xp = (user.xp || 0) + game.reward;
            xpMsg = `\n💰 *+${game.reward} نقطة*`;
        }

        await send(`🎉 *إجابة صحيحة!*\n✅ *الإجابة:* ${game.correct}${xpMsg}`);
        return true;
    }

    game.wrongBy.add(m.sender);
    await send(`${EMOJI} *❌ غلط!* حاول غيرك يجاوب`);
    return true;
};

handler.help = ['خمن'];
handler.tags = ['game'];
handler.command = ['خمن', 'guess'];

export default handler;