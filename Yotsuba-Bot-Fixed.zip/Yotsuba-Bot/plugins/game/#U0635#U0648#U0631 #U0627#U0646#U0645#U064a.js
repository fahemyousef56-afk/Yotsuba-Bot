// 🕸 ملف: انمي.js - لعبة خمن الشخصية الجماعية - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const MAX_ROUNDS = 10;
const ROUND_TIME = 30000;
const NEXT_DELAY = 2500;
const STALE_TIME = 120000;

const buildContext = (mentions = []) => ({
  mentionedJid: mentions,
  isForwarded: true,
  forwardingScore: 999,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
});

const CHARACTERS = [
  { name: 'ايرين', search: 'Eren Yeager' },
  { name: 'نيزوكو', search: 'Nezuko Kamado' },
  { name: 'سوكونا', search: 'Sukuna' },
  { name: 'موزان', search: 'Muzan Kibutsuji' },
  { name: 'كيلوا', search: 'Killua Zoldyck' },
  { name: 'غون', search: 'Gon Freecss' },
  { name: 'ايتاتشي', search: 'Itachi Uchiha' },
  { name: 'ساسكي', search: 'Sasuke Uchiha' },
  { name: 'دابي', search: 'Dabi' },
  { name: 'اوبيتو', search: 'Obito Uchiha' },
  { name: 'نوبارا', search: 'Nobara Kugisaki' },
  { name: 'ليفاي', search: 'Levi Ackerman' },
  { name: 'يوتا', search: 'Yuta Okkotsu' },
  { name: 'فريزا', search: 'Frieza' },
  { name: 'ياماتو', search: 'Yamato One Piece' },
  { name: 'نامي', search: 'Nami One Piece' },
  { name: 'انيا', search: 'Anya Forger' },
  { name: 'جينبي', search: 'Jinbe One Piece' },
  { name: 'بوروتو', search: 'Boruto Uzumaki' },
  { name: 'شانكس', search: 'Shanks One Piece' },
  { name: 'لاو', search: 'Trafalgar Law' },
  { name: 'لوفي', search: 'Monkey D Luffy' },
  { name: 'زورو', search: 'Roronoa Zoro' },
  { name: 'اكازا', search: 'Akaza' },
  { name: 'ميكاسا', search: 'Mikasa Ackerman' },
  { name: 'دوما', search: 'Doma Demon Slayer' },
  { name: 'كانيكي', search: 'Kaneki Ken' },
  { name: 'غوجو', search: 'Satoru Gojo' },
  { name: 'ساي', search: 'Sai Naruto' },
  { name: 'نيجي', search: 'Neji Hyuga' },
  { name: 'ساكورا', search: 'Sakura Haruno' },
  { name: 'اوريتشمارو', search: 'Orochimaru' },
  { name: 'ماهيتو', search: 'Mahito Jujutsu Kaisen' },
  { name: 'جيرايا', search: 'Jiraiya' },
  { name: 'روبين', search: 'Nico Robin' },
  { name: 'سانجي', search: 'Sanji One Piece' },
  { name: 'ميهوك', search: 'Dracule Mihawk' },
  { name: 'كايدو', search: 'Kaido One Piece' },
  { name: 'كورابيكا', search: 'Kurapika' },
  { name: 'شيغاراكي', search: 'Tomura Shigaraki' },
  { name: 'تينغن', search: 'Tengen Uzui' },
  { name: 'تانجيرو', search: 'Tanjiro Kamado' },
  { name: 'ميدوريا', search: 'Izuku Midoriya' },
  { name: 'كونان', search: 'Konan Naruto' },
  { name: 'شوتو', search: 'Shoto Todoroki' },
  { name: 'غارا', search: 'Gaara' },
  { name: 'باكوغو', search: 'Katsuki Bakugo' },
  { name: 'ماكيما', search: 'Makima Chainsaw Man' },
  { name: 'توجا', search: 'Toga Himiko' },
  { name: 'كوراما', search: 'Kurama Naruto' },
];

// ─────────────── أدوات مساعدة ───────────────

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const tag = (jid) => `@${String(jid).split('@')[0]}`;

const shuffle = (arr) => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

const getUser = (jid) => global.db?.data?.users?.[jid] || global.db?.users?.[jid];

const getPrize = (rank) => {
  if (rank === 0) return { xp: 500, cookies: 10, emoji: '👑' };
  if (rank === 1) return { xp: 300, cookies: 5, emoji: '🥈' };
  if (rank === 2) return { xp: 200, cookies: 3, emoji: '🥉' };
  return { xp: 100, cookies: 2, emoji: '⭐' };
};

const send = async (conn, chatId, text, quoted, mentions = []) => {
  try {
    await conn.sendMessage(
      chatId,
      { text, contextInfo: buildContext(mentions) },
      quoted ? { quoted } : {}
    );
  } catch (e) {
    console.error(`${EMOJI} فشل إرسال رسالة:`, e?.message);
  }
};

// ─────────────── AniList ───────────────

async function fetchCharacterImage(searchName) {
  const query = `query ($search: String) {
    Character(search: $search) {
      name { full }
      image { large }
    }
  }`;

  const res = await fetch('https://graphql.anilist.co', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query, variables: { search: searchName } }),
    signal: AbortSignal.timeout(15000),
  });

  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`AniList API error (status ${res.status})`);

  const json = await res.json();
  return json?.data?.Character?.image?.large || null;
}

async function pickCharacterWithImage(used) {
  let pool = CHARACTERS.filter((c) => !used.has(c.name));
  if (!pool.length) {
    used.clear();
    pool = [...CHARACTERS];
  }

  const tried = new Set();

  for (let i = 0; i < 6 && tried.size < pool.length; i++) {
    const remaining = pool.filter((c) => !tried.has(c.name));
    const char = remaining[Math.floor(Math.random() * remaining.length)];
    tried.add(char.name);

    try {
      const img = await fetchCharacterImage(char.search);
      if (img) return { char, img };
    } catch (e) {
      console.error(`${EMOJI} AniList (${char.search}):`, e?.message);
    }
  }

  throw new Error('مقدرتش ألاقي صورة لأي شخصية، جرب بعد شوية');
}

// ─────────────── إرسال الجولة ───────────────

async function sendRound(conn, chatId, quoted, cur, prefix) {
  try {
    if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

    await conn.sendButton(
      chatId,
      {
        imageUrl: cur.img,
        bodyText: cur.caption,
        footerText: `${EMOJI} ${BOT_NAME}`,
        buttons: cur.opts.map((opt, i) => ({
          name: 'quick_reply',
          params: {
            display_text: `${i + 1}. ${opt}`,
            id: `${prefix}anime_ans_${i + 1}`,
          },
        })),
        mentions: [],
        newsletter: {
          name: CHANNEL_NAME,
          jid: CHANNEL_JID,
        },
      },
      quoted
    );
  } catch (e) {
    console.error('فشل sendButton، هبعت صورة عادية:', e?.message);

    const list = cur.opts.map((o, i) => `${i + 1}. ${o}`).join('\n');

    await conn.sendMessage(
      chatId,
      {
        image: { url: cur.img },
        caption: `${cur.caption}\n\n${list}\n\n📝 *اكتب اسم الشخصية للإجابة*`,
        contextInfo: buildContext(),
      },
      { quoted }
    );
  }
}

// ─────────────── منطق اللعبة ───────────────

async function startRound(conn, chatId) {
  const g = global.gameAnime?.[chatId];
  if (!g || g.starting || g.current) return;

  g.starting = true;
  g.last = Date.now();

  try {
    g.round++;

    const { char, img } = await pickCharacterWithImage(g.used);
    g.used.add(char.name);

    const wrong = shuffle(CHARACTERS.filter((c) => c.name !== char.name))
      .slice(0, 3)
      .map((c) => c.name);
    const opts = shuffle([char.name, ...wrong]);

    const round = g.round;
    const caption =
      `🎌 *خمن الشخصية (${round}/${MAX_ROUNDS})*\n\n` +
      `⏱️ *الوقت: ${ROUND_TIME / 1000} ثانية*\n` +
      `${EMOJI} اختر الإجابة الصحيحة 👇`;

    // نسجل الجولة الأول وبعدين نبعت
    g.current = {
      answer: char.name,
      opts,
      img,
      caption,
      answered: new Set(),
      timer: setTimeout(() => onTimeout(conn, chatId, round), ROUND_TIME),
    };

    await sendRound(conn, chatId, g.m, g.current, g.prefix);
  } catch (e) {
    console.error(`${EMOJI} خطأ في بدء الجولة:`, e);
    clearTimeout(g.current?.timer);
    delete global.gameAnime[chatId];
    await send(
      conn,
      chatId,
      `${EMOJI} ❌ *حدث خطأ، اتلغت اللعبة*\n📌 ${String(e?.message || '').slice(0, 100)}`,
      g.m
    );
  } finally {
    g.starting = false;
  }
}

async function onTimeout(conn, chatId, round) {
  const g = global.gameAnime?.[chatId];
  if (!g?.current || g.round !== round) return;

  const answer = g.current.answer;
  g.current = null;
  g.last = Date.now();

  await send(conn, chatId, `${EMOJI} *⏰ الوقت انتهى!*\n💡 الإجابة: *${answer}*`, g.m);
  await advance(conn, chatId);
}

async function advance(conn, chatId) {
  const g = global.gameAnime?.[chatId];
  if (!g) return;

  if (g.round >= MAX_ROUNDS) {
    await finishGame(conn, chatId);
    return;
  }

  await sleep(NEXT_DELAY);
  await startRound(conn, chatId);
}

async function finishGame(conn, chatId) {
  const g = global.gameAnime?.[chatId];
  if (!g) return;

  clearTimeout(g.current?.timer);
  delete global.gameAnime[chatId];

  const sorted = Object.entries(g.scores).sort((a, b) => b[1] - a[1]);

  if (!sorted.length) {
    return send(conn, chatId, `${EMOJI} *انتهت اللعبة، مفيش مشاركين صح في الجولات*`, g.m);
  }

  const lines = sorted.map(([jid, score], i) => {
    const prize = getPrize(i);
    const user = getUser(jid);
    if (user) {
      user.xp = (user.xp || 0) + prize.xp;
      user.cookies = (user.cookies || 0) + prize.cookies;
    }
    return `${prize.emoji} ${tag(jid)} - ${score} نقطة (+${prize.xp}xp)`;
  });

  await send(
    conn,
    chatId,
    `🏆 *انتهت لعبة الأنمي!*\n\n${lines.join('\n')}\n\n${EMOJI} اكتب *${g.prefix}انمي* للعب مرة أخرى`,
    g.m,
    sorted.map(([jid]) => jid)
  );
}

// ─────────────── الأمر الرئيسي ───────────────

const handler = async (m, { conn, usedPrefix }) => {
  const chatId = m.chat;
  const prefix = usedPrefix || '.';

  if (!global.gameAnime) global.gameAnime = {};

  let g = global.gameAnime[chatId];

  // لعبة معلقة من فترة طويلة: نصفّرها
  if (g && Date.now() - (g.last || 0) > STALE_TIME && !g.starting) {
    clearTimeout(g.current?.timer);
    delete global.gameAnime[chatId];
    g = null;
  }

  if (g) {
    // فيه لعبة شغالة: نعيد عرض الجولة الحالية
    if (g.current) {
      try {
        await sendRound(conn, chatId, m, g.current, g.prefix);
      } catch (e) {
        console.error(`${EMOJI} فشل إعادة عرض الجولة:`, e?.message);
      }
      return;
    }
    return send(conn, chatId, `${EMOJI} *اللعبة شغالة، استنى الجولة الجاية...*`, m);
  }

  global.gameAnime[chatId] = {
    round: 0,
    scores: {},
    current: null,
    used: new Set(),
    starting: false,
    last: Date.now(),
    prefix,
    m,
  };

  await startRound(conn, chatId);
};

// ─────────────── معالجة الإجابات (أزرار أو كتابة اسم الشخصية) ───────────────

handler.before = async (m, { conn }) => {
  if (m.fromMe || m.isBaileys) return;

  const g = global.gameAnime?.[m.chat];
  if (!g?.current) return;

  const raw = String(m.text || m.body || '').trim();
  if (!raw) return;

  const cur = g.current;

  let chosen = null;
  const btn = raw.match(/anime_ans_(\d)$/i);

  if (btn) chosen = cur.opts[parseInt(btn[1], 10) - 1];
  else if (cur.opts.includes(raw)) chosen = raw;

  if (!chosen) return;

  // محاولة واحدة لكل لاعب في الجولة
  if (cur.answered.has(m.sender)) {
    await send(conn, m.chat, `${EMOJI} *جاوبت في الجولة دي قبل كده، سيب غيرك يجرب* 😅`, m);
    return true;
  }

  cur.answered.add(m.sender);

  if (chosen !== cur.answer) {
    await send(conn, m.chat, `${EMOJI} *❌ غلط يا ${m.pushName || 'بطل'}*`, m);
    return true;
  }

  // إجابة صحيحة: ننهي الجولة
  clearTimeout(cur.timer);
  g.current = null;
  g.last = Date.now();
  g.scores[m.sender] = (g.scores[m.sender] || 0) + 1;

  await send(
    conn,
    m.chat,
    `🎉 *صح يا ${m.pushName || 'بطل'}!* الإجابة: *${cur.answer}*\n` +
      `🎯 عندك ${g.scores[m.sender]} نقطة\n` +
      (g.round < MAX_ROUNDS ? `${EMOJI} انتظر الجولة القادمة...` : ''),
    m,
    [m.sender]
  );

  advance(conn, m.chat).catch((e) => console.error(`${EMOJI} خطأ:`, e?.message));
  return true;
};

handler.command = ['انمي', 'anime'];
handler.usage = ['انمي'];
handler.category = 'game';

export default handler;