const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const buildContext = (mentions = []) => ({
    mentionedJid: mentions,
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const CHOICES = { حجر: '🪨', ورقة: '📄', مقص: '✂️' };
const BEATS = { حجر: 'مقص', ورقة: 'حجر', مقص: 'ورقة' };
const GAME_TIME = 60000;

const tag = (jid) => `@${jid.split('@')[0]}`;

const findGame = (chat, jid) =>
    Object.entries(global.rpsGames || {}).find(
        ([, g]) => g.chat === chat && (g.p1 === jid || g.p2 === jid)
    );

const handler = async (m, { conn, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const target = m.mentionedJid?.[0] || m.quoted?.sender;

    if (!target) {
        return m.reply(`*⚠️ منشن حد عشان تتحداه*\n> مثال: \`${prefix}${command || 'تحدي_حجر_ورقة'} @الشخص\``);
    }
    if (target === m.sender) return m.reply('*😅 منقدرش تلعب مع نفسك!*');
    if (target === conn.user?.jid || target === conn.user?.id) {
        return m.reply('*🤖 مش هقدر ألعب معاك، تحدى حد تاني*');
    }

    if (!global.rpsGames) global.rpsGames = {};

    if (findGame(m.chat, m.sender)) {
        return m.reply('*⚠️ انت في لعبة شغالة بالفعل، خلصها الأول*');
    }
    if (findGame(m.chat, target)) {
        return m.reply('*⚠️ الشخص ده في لعبة شغالة بالفعل*');
    }

    const gameId = `${m.chat}_${Date.now()}`;

    global.rpsGames[gameId] = {
        chat: m.chat,
        p1: m.sender,
        p2: target,
        choices: {},
        timeout: setTimeout(async () => {
            if (!global.rpsGames?.[gameId]) return;
            delete global.rpsGames[gameId];

            await conn
                .sendMessage(
                    m.chat,
                    {
                        text: `*⌛ انتهى الوقت، اتلغى التحدي بين ${tag(m.sender)} و ${tag(target)}*`,
                        contextInfo: buildContext([m.sender, target]),
                    },
                    { quoted: m }
                )
                .catch(() => {});
        }, GAME_TIME),
    };

    return conn.sendMessage(
        m.chat,
        {
            text:
                `╭─┈─┈─⟞🎮⟝─┈─┈─╮\n┃ *تحدي حجر ورقة مقص*\n╰─┈─┈─⟞✂️⟝─┈─┈─╯\n\n` +
                `${tag(m.sender)} تحدى ${tag(target)}!\n\n` +
                `> كل واحد يبعت هنا: \`اختيار حجر\` أو \`اختيار ورقة\` أو \`اختيار مقص\`\n` +
                `> الوقت: 60 ثانية ⏱️`,
            contextInfo: buildContext([m.sender, target]),
        },
        { quoted: m }
    );
};

handler.before = async (m, { conn }) => {
    if (m.fromMe || m.isBaileys) return;
    if (!global.rpsGames || !m.text) return;

    const match = m.text.trim().match(/^اختيار\s+(حجر|ورقة|مقص)$/);
    if (!match) return;

    const choice = match[1];

    const found = findGame(m.chat, m.sender);
    if (!found) return;

    const [gameId, game] = found;

    if (game.choices[m.sender]) {
        return m.reply('*⚠️ انت اخترت بالفعل، مستنيين الخصم*');
    }

    game.choices[m.sender] = choice;

    if (!game.choices[game.p1] || !game.choices[game.p2]) {
        return m.reply('*✅ اتسجل اختيارك، مستنيين الخصم*');
    }

    clearTimeout(game.timeout);
    delete global.rpsGames[gameId];

    const c1 = game.choices[game.p1];
    const c2 = game.choices[game.p2];

    let resultText;
    if (c1 === c2) {
        resultText = '*🤝 تعادل! نفس الاختيار*';
    } else if (BEATS[c1] === c2) {
        resultText = `*🏆 الفايز: ${tag(game.p1)}*`;
    } else {
        resultText = `*🏆 الفايز: ${tag(game.p2)}*`;
    }

    await conn.sendMessage(
        m.chat,
        {
            text:
                `╭─┈─┈─⟞✂️⟝─┈─┈─╮\n┃ *النتيجة*\n╰─┈─┈─⟞🎮⟝─┈─┈─╯\n\n` +
                `${tag(game.p1)}: ${CHOICES[c1]} ${c1}\n` +
                `${tag(game.p2)}: ${CHOICES[c2]} ${c2}\n\n` +
                resultText,
            contextInfo: buildContext([game.p1, game.p2]),
        },
        { quoted: m }
    );
};

handler.usage = ['تحدي_حجر_ورقة'];
handler.category = 'game';
handler.command = ['تحدي_حجر_ورقة'];
handler.cooldown = 2000;

export default handler;