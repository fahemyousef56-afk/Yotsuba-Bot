const AUDIO_URL = 'https://files.catbox.moe/9601bp.mp3'

const CHANNEL_JID = '120363433665479594@newsletter'
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍'

// رسالة متحوّلة من القناة
const channelContext = () => ({
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
})

let handler = m => m

handler.before = async function (m, { conn }) {
  const text = (m.text || '').trim()
  if (!/^\.?(bot|يوتسو)$/i.test(text)) return

  try {
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: AUDIO_URL },
        mimetype: 'audio/mpeg',
        ptt: false,
        contextInfo: channelContext(),
      },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
  }
}

export default handler