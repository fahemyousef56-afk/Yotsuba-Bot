// 🕸 ملف: تقيم.js - تقييم البوت - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/1wVScSq/IMG-20261013-114035-845.jpg';

// ✅ أرقام التواصل
const DEVELOPER_CONTACT = '221774033156@s.whatsapp.net';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const FEEDBACK = {
    1: { title: '⭐ *تقييم نجمة واحدة*', msg: 'شكراً لتقييمك! سنعمل على تحسين البوت.' },
    2: { title: '⭐⭐ *تقييم نجمتين*', msg: 'نقدر رأيك! سنسعى لتقديم الأفضل.' },
    3: { title: '⭐⭐⭐ *تقييم ثلاث نجوم*', msg: 'شكراً لك! سنواصل التطوير لخدمتك.' },
    4: { title: '⭐⭐⭐⭐ *تقييم أربع نجوم*', msg: 'نشكرك جداً! دعمك يحفزنا للمزيد.' },
    5: { title: '⭐⭐⭐⭐⭐ *تقييم خمس نجوم*', msg: 'شكراً جزيلاً! هذا التقييم يعني لنا الكثير.' }
};

// ✅ دالة الرد على التقييم
const sendFeedbackResponse = async (stars, m, conn) => {
    const f = FEEDBACK[stars];

    // إرسال التقييم للمطور
    try {
        await conn.sendMessage(DEVELOPER_CONTACT, {
            text: `${EMOJI}━━━[ *تقييم جديد* ]━━━${EMOJI}

⭐ *التقييم:* ${stars} نجوم
👤 *من:* @${m.sender.split('@')[0]}

${EMOJI} *${BOT_NAME}*`,
            mentions: [m.sender],
            contextInfo: channelInfo
        });
    } catch (e) {
        console.error(`${EMOJI} فشل إرسال التقييم للمطور:`, e);
    }

    // الرد للمستخدم
    await send(conn, m, `${f.title}

📌 *${f.msg}*

👨‍💻 *المطور:* ${DEVELOPER}
📢 *القناة:* ${CHANNEL_LINK}

${EMOJI} *${BOT_NAME}*`);
};

const handler = async (m, { conn, text, command, usedPrefix }) => {
    const prefix = usedPrefix || '.';

    // ✅ المستخدم اختار تقييم (من الأزرار أو كتابة .قيم 5)
    if (command === 'قيم') {
        const stars = parseInt((text || '').trim());
        if (stars >= 1 && stars <= 5) {
            return sendFeedbackResponse(stars, m, conn);
        }
        return send(conn, m, `${EMOJI} ❌ *تقييم غير صالح*\n📌 اختر من 1 إلى 5\nمثال: ${prefix}قيم 5`);
    }

    // ✅ عرض واجهة التقييم
    const bodyText = `${EMOJI}━━━[ *⭐ تقييم البوت* ]━━━${EMOJI}

👑 *مرحباً ${m.pushName || 'مستخدم'}*

📌 *قيم البوت لمساعدتنا على التحسين*
👨‍💻 *المطور:* ${DEVELOPER}

${EMOJI} *اختر عدد النجوم 👇*`;

    const buttons = [
        { name: 'quick_reply', params: { display_text: '⭐', id: `${prefix}قيم 1` } },
        { name: 'quick_reply', params: { display_text: '⭐⭐', id: `${prefix}قيم 2` } },
        { name: 'quick_reply', params: { display_text: '⭐⭐⭐', id: `${prefix}قيم 3` } },
        { name: 'quick_reply', params: { display_text: '⭐⭐⭐⭐', id: `${prefix}قيم 4` } },
        { name: 'quick_reply', params: { display_text: '⭐⭐⭐⭐⭐', id: `${prefix}قيم 5` } },
        {
            name: 'cta_url',
            params: {
                display_text: `${EMOJI} قناة البوت`,
                url: CHANNEL_LINK
            }
        }
    ];

    try {
        await conn.sendButton(m.chat, {
            imageUrl: MAIN_IMAGE,
            bodyText,
            footerText: `${EMOJI} ${BOT_NAME} | ${DEVELOPER}`,
            buttons,
            mentions: [m.sender],
            newsletter: {
                name: CHANNEL_NAME,
                jid: CHANNEL_JID
            },
            interactiveConfig: { buttons_limits: 20 }
        }, m);
    } catch (e) {
        console.error(`${EMOJI} فشل إرسال الأزرار:`, e);
        await send(conn, m, `${bodyText}\n\n📌 اكتب: ${prefix}قيم 1 إلى ${prefix}قيم 5\n📢 ${CHANNEL_LINK}`);
    }
};

handler.usage = ['تقيم'];
handler.command = ['تقيم', 'تقييم', 'rate', 'قيم'];
handler.category = 'info';

export default handler;