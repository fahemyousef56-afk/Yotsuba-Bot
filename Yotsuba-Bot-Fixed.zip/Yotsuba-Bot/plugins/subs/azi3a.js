const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const getForwardableMessage = (quoted) => {
  if (typeof quoted?.fakeObj === 'function') {
    return quoted.fakeObj();
  }
  return quoted;
};

const broadcastWithSocket = async (sock, quoted) => {
  let success = 0;
  let fail = 0;
  let groupsCount = 0;

  const groups = await sock.groupFetchAllParticipating();
  const groupList = Object.values(groups || {});
  groupsCount = groupList.length;

  for (const group of groupList) {
    try {
      const metadata = await sock.groupMetadata(group.id);
      const mentions = (metadata?.participants || []).map(participant => participant.id);

      await sock.sendMessage(group.id, {
        forward: getForwardableMessage(quoted),
        mentions
      });

      success++;
      await sleep(2000);
    } catch {
      fail++;
    }
  }

  return { success, fail, groupsCount };
};

const run = async (m, { conn, bot }) => {
  if (!m.quoted) {
    return m.reply("📝 قم بالرد على الرسالة التي تريد إذاعتها");
  }

  // عند تشغيل الأمر من بوت فرعي، يذيع هذا البوت في مجموعاته هو.
  if (bot?.isSubBot) {
    try {
      const result = await broadcastWithSocket(conn, m.quoted);
      return m.reply(`✅ تمت إذاعة البوت الفرعي

✓ النجاح: ${result.success}
✗ الفشل: ${result.fail}
👥 الجروبات: ${result.groupsCount}`);
    } catch (error) {
      return m.reply(`❌ تعذرت الإذاعة: ${error?.message || 'خطأ غير معروف'}`);
    }
  }

  // عند تشغيل الأمر من البوت الأساسي، يمر على كل البوتات الفرعية المتصلة.
  const sub = global.subBots;
  if (!sub) return m.reply("❌ نـظـام الـبـوتـات الـفـرعـيـة غير متاح");

  const activeBots = sub.list().filter(botInfo =>
    botInfo.connected && botInfo.phone
  );

  if (activeBots.length === 0) {
    return m.reply("📭 لا يوجد بوتات فرعية متصلة للإذاعة");
  }

  let success = 0;
  let fail = 0;
  let groupCount = 0;

  for (const botInfo of activeBots) {
    try {
      const botConnection = sub.get(botInfo.id);
      const sock = botConnection?.sock;
      if (!sock) continue;

      const result = await broadcastWithSocket(sock, m.quoted);
      success += result.success;
      fail += result.fail;
      groupCount += result.groupsCount;
    } catch {
      fail++;
    }
  }

  await m.reply(`✅⤿ تـم الـإذاعـة عبر البوتات الفرعية
⊱⋅ ──────────── ⋅⊰
✓🌹 النجاح: ${success}
✓🫒 الفشل: ${fail}
🤖 البوتات: ${activeBots.length}
👥 الجروبات: ${groupCount}
⊱⋅ ──────────── ⋅⊰
> *_𝒀𝒐𝒕𝒔𝒖𝒃𝒂_*`);
};

run.command = ["اذاعه", "إذاعة", "اذاعة", "اذاعه فرعي", "اذاعة فرعي"];
run.usage = ["اذاعه"];
run.category = "sub";
run.noSub = false;
run.owner = true;
export default run;