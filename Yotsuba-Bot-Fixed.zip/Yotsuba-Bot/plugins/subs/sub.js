/*
|--------------------------------------------------------------------------
| ⚙️ الإعدادات
|--------------------------------------------------------------------------
*/
const MAX_SUB_BOTS = 150;
const TIMEOUT_MS = 2 * 60 * 1000; // دقيقتين لانتظار كود الربط

const SUB_BOT_IMAGE = 'https://i.ibb.co/wrMj7wNN/IMG-20261025-222748-114.jpg';
const PAIR_IMAGE = 'https://i.ibb.co/WN8rVK4s/IMG-20261013-164235-604.jpg';

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_URL = 'https://whatsapp.com/channel/0029Vb8xTot1t90ks8pCah1O';
const FOOTER = BOT_NAME;

/*
|--------------------------------------------------------------------------
| 🎨 أدوات مساعدة للشكل والإرسال
|--------------------------------------------------------------------------
*/
const channelContext = (extra = {}) => ({
    ...extra,
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

const card = (title, lines = []) =>
    [
        `╭━━━〔 ${title} 〕━━━╮`,
        '',
        ...lines.map((line) => `┃ ${line}`),
        '',
        '╰━━━━━━━━━━━━━━━━━━╯',
        `> ${FOOTER}`,
    ].join('\n');

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(
        m.chat,
        { text, contextInfo: channelContext(extra.contextInfo), ...extra.content },
        { quoted: m }
    );

/*
|--------------------------------------------------------------------------
| 🤖 الأمر الرئيسي
|--------------------------------------------------------------------------
*/
const run = async (m, { conn }) => {
    if (['تنصيب_فرعي', 'تنصيب_للبوت'].includes(m.command)) {
        if (!m.isOwner && !m.owner) {
            return send(conn, m, card('⛔ ممنوع', ['الأمر ده للمطور فقط']));
        }
    }

    if (global.db?.noSub) {
        return send(conn, m, card('🔒 مقفول', ['المطور قافل التنصيب حالياً']));
    }

    const sub = global.subBots;

    if (!sub) {
        return send(conn, m, card('❌ غير متاح', ['نظام البوتات الفرعية غير متاح']));
    }

    try {
        const currentCount = typeof sub.list === 'function' ? sub.list().length : 0;

        if (currentCount >= MAX_SUB_BOTS) {
            return send(
                conn,
                m,
                card('⚠️ الحد الأقصى', [
                    'تم الوصول لأقصى عدد مسموح',
                    `📊 الحد: ${MAX_SUB_BOTS} بوت فرعي`,
                ])
            );
        }

        const num = String(m.sender || '')
            .split('@')[0]
            .replace(/[+\s-]/g, '');

        if (!/^\d+$/.test(num)) {
            return send(conn, m, card('⚠️ رقم غير صالح', ['تأكد من رقم الهاتف وحاول تاني']));
        }

        await send(
            conn,
            m,
            card('⏳ جاري التنصيب', [
                `📱 الرقم: *${num}*`,
                'استنى لحظات لحد ما يجيلك الكود...',
            ])
        );

        const state = {
            uid: null,
            pairDone: false,
            resolved: false,
            pending: null,
            timer: null,
        };

        const cleanup = () => {
            if (state.timer) {
                clearTimeout(state.timer);
                state.timer = null;
            }

            sub.off('pair', handlers.pair);
            sub.off('ready', handlers.ready);
            sub.off('error', handlers.error);
        };

        const handlers = {
            pair: async (id, code) => {
                if (state.pairDone) return;

                if (!state.uid) {
                    state.pending = { id, code };
                    return;
                }

                if (id !== state.uid) return;

                state.pairDone = true;
                await Func.pair(conn, code, num, m);
            },

            ready: async (id) => {
                if (id !== state.uid || state.resolved) return;

                state.resolved = true;
                configureChannelLink(sub, id);

                await Func.ready(conn, num, m);
                cleanup();
            },

            error: async (id, error) => {
                if (id !== state.uid || state.resolved) return;

                state.resolved = true;

                await Func.error(conn, num, error, m);
                cleanup();
            },
        };

        sub.on('pair', handlers.pair);
        sub.on('ready', handlers.ready);
        sub.on('error', handlers.error);

        state.uid = await sub.add(num);

        if (state.pending?.id === state.uid && !state.pairDone) {
            state.pairDone = true;
            await Func.pair(conn, state.pending.code, num, m);
        }

        state.timer = setTimeout(async () => {
            if (state.resolved) return;

            state.resolved = true;

            await Func.timeout(conn, m, state.pairDone);
            cleanup();
        }, TIMEOUT_MS);
    } catch (error) {
        await send(
            conn,
            m,
            card('❌ فشل التنصيب', [`⚠️ ${error?.message || 'خطأ غير معروف'}`])
        );
    }
};

/*
|--------------------------------------------------------------------------
| 📢 ضبط رابط القناة واسم البوت في إعدادات البوت الفرعي
|--------------------------------------------------------------------------
*/
function configureChannelLink(sub, uid) {
    try {
        const childBot = typeof sub.get === 'function' ? sub.get(uid) : null;

        if (!childBot) return;

        childBot.noChannelLinks = false;

        if (childBot.config) {
            childBot.config.noChannelLinks = false;
        }

        if (childBot.config?.info) {
            const info = childBot.config.info;

            info.botName = BOT_NAME;
            info.channel = CHANNEL_URL;
            info.channelLink = CHANNEL_URL;
            info.channelUrl = CHANNEL_URL;
            info.newsletter = CHANNEL_URL;
            info.newsletterLink = CHANNEL_URL;
            info.newsletterJid = CHANNEL_JID;
            info.newsletterName = CHANNEL_NAME;
            info.links = {
                ...(info.links || {}),
                channel: CHANNEL_URL,
                newsletter: CHANNEL_URL,
            };
        }
    } catch {
        // تجاهل الخطأ لو إعدادات القناة مش موجودة
    }
}

run.command = ['تنصيب', 'تنصيب_فرعي', 'تنصيب_للبوت'];
run.usage = ['تنصيب', 'تنصيب_فرعي'];
run.category = 'sub';

// أمر "تنصيب" متاح من البوت الأساسي والبوتات الفرعية
run.noSub = false;

export default run;

/*
|--------------------------------------------------------------------------
| 📦 وظائف التنصيب
|--------------------------------------------------------------------------
*/
const Func = {
    pair: async (conn, code, num, m) => {
        await conn.sendButton(
            m.chat,
            {
                imageUrl: PAIR_IMAGE,

                bodyText: card('🔐 نـظـام الـبـوتـات الـفـرعـيـة', [
                    `🤖 البوت: ${BOT_NAME}`,
                    `📱 الرقم: *${num}*`,
                    `🔑 الكود: *${code}*`,
                    '',
                    '📌 *طريقة الربط:*',
                    '1️⃣ افتح واتساب',
                    '2️⃣ الأجهزة المرتبطة',
                    '3️⃣ ربط جهاز برقم الهاتف',
                    '4️⃣ حط الكود اللي فوق',
                ]),

                footerText: FOOTER,

                buttons: [
                    {
                        name: 'cta_copy',
                        params: {
                            display_text: '📋 نسخ الكود',
                            copy_code: code,
                        },
                    },
                    {
                        name: 'cta_url',
                        params: {
                            display_text: '📢 قناة البوت',
                            url: CHANNEL_URL,
                            merchant_url: CHANNEL_URL,
                        },
                    },
                ],

                mentions: [m.sender],
                contextInfo: channelContext(),

                interactiveConfig: {
                    buttons_limits: 5,
                    list_title: 'تنصيب بوت فرعي',
                    button_title: 'اختار',
                    canonical_url: CHANNEL_URL,
                },
            },
            m
        );
    },

    ready: async (conn, num, m) => {
        const caption = card('✅ تـم الاتـصـال بـنـجـاح', [
            `🤖 البوت: ${BOT_NAME}`,
            `📱 الرقم: *${num}*`,
            '🚀 البوت الفرعي جاهز للاستخدام الآن',
            '🎉 نورتنا يا غالي',
        ]);

        try {
            await conn.sendMessage(
                m.chat,
                {
                    image: { url: SUB_BOT_IMAGE },
                    caption,
                    contextInfo: channelContext(),
                },
                { quoted: m }
            );
        } catch (error) {
            await send(
                conn,
                m,
                `${caption}\n\n⚠️ تعذر إرسال الصورة:\n${error?.message || 'خطأ غير معروف'}`
            );
        }
    },

    error: async (conn, num, error, m) => {
        await send(
            conn,
            m,
            card('❌ فشل الاقتران', [
                `📱 الرقم: *${num}*`,
                `⚠️ الخطأ: ${error?.message || 'غير معروف'}`,
            ])
        );
    },

    timeout: async (conn, m, pairDone) => {
        await send(
            conn,
            m,
            card('⏰ انتهى الوقت', [
                pairDone
                    ? 'تم إرسال الكود، لكن مفيش تأكيد اتصال خلال الوقت المحدد'
                    : 'مجاش كود اقتران خلال 120 ثانية',
                '🔄 جرب تاني بأمر *تنصيب*',
            ])
        );
    },
};