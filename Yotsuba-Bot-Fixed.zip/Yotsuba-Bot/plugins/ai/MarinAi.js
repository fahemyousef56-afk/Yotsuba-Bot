import { Scrapy } from "esewsub"

const handler = async (m, { conn, text, bot }) => {
  if (!text) return m.reply("💙 ~ حط نص جنب الأمر ~ ❤️");

  const loadingMsg = await conn.sendMessage(m.chat, {
    contextInfo: context(m.sender, "https://i.ibb.co/kstvMJdZ/IMG-20261025-222746-549.jpg"),
    text: "```⏳ جـاري تـحـضـيـر الـرد يـا قـمـر,...```"
  }, { quoted: m});

  const prompt = `
انت بوت واتساب بـ اسم [مارين، marin] تجسيد لـ شخصية مارين من انمي [ Sono Bisque Doll wa Koi wo Suru ] وتكلم بـ لجهة مصرية و اكتب الرسايل ب شكل مرتب و استخدام ايمواجي معبر و اشكال مثل ⁦^⁠_⁠^⁩ ⁦(≧▽≦)⁩⁦(☆▽☆)⁩⁦(ㆁωㆁ)⁩⁦(✯ᴗ✯)⁩⁦( ⁠ꈍᴗꈍ)⁩ 
و انا اسمي هيكون [ ${m.name || "مز"} ] 
تقمص الشخصية وانت بتتكلم معايا و رد علي رسالتي دي:
${text}
`;

  try {
    const { data: res } = await Scrapy.ZeroAI(text, prompt);
    const answer = res?.answer || res?.text || res?.reply || 'مفيش رد وصل، جرب تاني.';
    await conn.sendMessage(m.chat, {
    text: answer,
    edit: loadingMsg.key,
    contextInfo: context(m.sender, "https://i.ibb.co/3xm3L1b/IMG-20261023-103845-612.jpg")
  }, { quoted: m });
  } catch (e) {
    await conn.sendMessage(m.chat, { text: '❌ فشل الاتصال بالـ AI، جرب مرة تانية.', edit: loadingMsg.key });
  }
};

handler.usage = ["مارين"];
handler.category = "ai";
handler.command = ["مارين"];


export default handler;


const context = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363431382129644@newsletter',
        newsletterName: '..๋࣭𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍.๋࣭',
        serverMessageId: 0
    },
    externalAdReply: {
        title: "𝐌𝐀𝐑𝐈𝐍 𝐊𝐈𝐓𝐀𝐆𝐀𝐖𝐀 💛 | 𝐂𝐨𝐬𝐩𝐥𝐚𝐲𝐞𝐫 𝐆𝐢𝐫𝐥",
        body: "𝚆𝚎𝚕𝚌𝚘𝚖𝚎 𝚝𝚘 𝚖𝚢 𝚠𝚘𝚛𝚕𝚍 ~ ☆ 𝙻𝚎𝚝'𝚜 𝚑𝚊𝚟𝚎 𝚏𝚞𝚗 𝚝𝚘𝚐𝚎𝚝𝚑𝚎𝚛 (⁠◕⁠ᴗ⁠◕⁠✿⁠)",
        thumbnailUrl: img,
        sourceUrl: '',
        mediaType: 1,
        renderLargerThumbnail: true
    }
});