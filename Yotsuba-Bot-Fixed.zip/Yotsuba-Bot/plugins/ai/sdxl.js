/*
 * 🌸 ⏤͟͞𝒀𝑼𝑲𝑰 - 𝑩𝜺𝑻⃝🌸
 * 📢 واتساب : https://whatsapp.com/channel/0029Vb9A4F5DZ4LSIBJVd80X
 * 📨 تيليجرام : https://t.me/+-ZIIcYxN18w4ZGM8
 */


import axios from 'axios';

async function توليد_sdxl(برومبت) {
    const res = await axios({
        method: 'post',
        url: 'https://apiimagen.magiceraser.fyi/imagen_v1',
        params: {
            size: '1080x1920',
            negative_prompt: 'ugly, blurry, bad quality',
            style: null,
            custom_style: null,
            prompt: برومبت,
            version: 'sdxl'
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Dalvik/2.1.0',
            'Accept-Encoding': 'gzip'
        },
        responseType: 'arraybuffer',
        timeout: 120000
    });
    return Buffer.from(res.data);
}

const handler = async (m, { conn, text, command }) => {
    if (!text) {
        return m.reply(
            `*🎨 توليد صور SDXL*\n${'━'.repeat(30)}\n\n` +
            `*الاستخدام:*\n.${command} [وصف الصورة]\n\n` +
            `*مثال:*\n.${command} a futuristic city at night, cyberpunk style\n\n` +
            `*ملاحظة:* اكتب الوصف بالإنجليزي للحصول على أفضل نتيجة\n\n` +
            `> *𝒀𝒐𝒕𝒔𝒖𝒃𝒂 - 𝑩𝜺𝑻⃝🕸*`
        );
    }

    m.react('⏳');
    await m.reply('*⏳ جاري توليد الصورة بنموذج SDXL...*');
    try {
        const buffer = await توليد_sdxl(text);
        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: `🎨 *صورة SDXL*\n📝 ${text.slice(0, 100)}\n\n> *𝒀𝒐𝒕𝒔𝒖𝒃𝒂 - 𝑩𝜺𝑻⃝🕸*`
        }, { quoted: m });
        m.react('✅');
    } catch (e) {
        m.react('❌');
        m.reply(`*❌ فشل التوليد:* ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ['sdxl'];
handler.command = ['sdxl', 'stable', 'توليد_sdxl'];
handler.category = 'ai';

export default handler;
