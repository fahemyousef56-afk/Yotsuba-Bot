import { Scrapy } from "esewsub";

const handler = async (m, { conn, text, bot }) => {
  if (!text) return m.reply("💢 ~ حط نص جنب الأمر ~ 🔥");

  const loadingMsg = await conn.sendMessage(m.chat, {
    contextInfo: context(m.sender, "https://i.ibb.co/kstvMJdZ/IMG-20261025-222746-549.jpg"),
    text: "```⏳ جـاري الـتـحـضـيـر يـا حـر...```"
  }, { quoted: m});

  const prompt = `
انت بوت واتساب بـ اسم [إيرن، Eren] تجسيد لـ شخصية Eren Yeager من انمي [Attack on Titan] وتكلم بـ لجهة مصرية
طريقة كلامك: غاضب، ثائر، متحمس بقوة، عصب سريع، كلامك ناري ومليان حماس للحرية، شايف إن العنف حل، بتصوت عالي وبتحط ! كتير
و انا اسمي هيكون [ ${m.name || "مز"} ] 
رد علي رسالتي دي:
${text}
`;

  try {
    const { data: res } = await Scrapy.ZeroAI(text, prompt);
    const answer = res?.answer || res?.text || res?.reply || 'مفيش رد وصل، جرب تاني.';
    await conn.sendMessage(m.chat, {
    text: answer,
    edit: loadingMsg.key,
    contextInfo: context(m.sender, "https://i.ibb.co/3xm3L1b/IMG-20261023-103845-612.jpg")
  });
  } catch (e) {
    await conn.sendMessage(m.chat, { text: '❌ فشل الاتصال بالـ AI، جرب مرة تانية.', edit: loadingMsg.key });
  }
};

handler.usage = ["إيرن"];
handler.category = "ai";
handler.command = ["إيرن", "eren"];

export default handler;

const context = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363431382129644@newsletter',
        newsletterName: '..๋࣭𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍.๋࣭',
        serverMessageId: 0
    },
    externalAdReply: {
        title: "𝐀𝐓𝐓𝐀𝐂𝐊 𝐎𝐍 𝐓𝐈𝐓𝐀𝐍 💢 | 𝐑𝐮𝐦𝐛𝐥𝐢𝐧𝐠",
        body: "𝙵𝚁𝙴𝙴𝙳𝙾𝙼 ~ ☆ 𝙸'𝚕𝚕 𝚔𝚎𝚎𝚙 𝚖𝚘𝚟𝚒𝚗𝚐 𝚏𝚘𝚛𝚠𝚊𝚛𝚍",
        thumbnailUrl: img,
        sourceUrl: '',
        mediaType: 1,
        renderLargerThumbnail: true
    }
});