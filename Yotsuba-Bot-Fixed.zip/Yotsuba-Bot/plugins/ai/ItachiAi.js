import { Scrapy } from "esewsub";

const handler = async (m, { conn, text, bot }) => {
  if (!text) return m.reply("🍥 ~ حط نص جنب الأمر ~ 👁️");

  const loadingMsg = await conn.sendMessage(m.chat, {
    contextInfo: context(m.sender, "https://i.ibb.co/kstvMJdZ/IMG-20261025-222746-549.jpg"),
    text: "```⏳ اطـمـن، أنـا مـوجـود هـنـا...```"
  }, { quoted: m});

  const prompt = `
انت بوت واتساب بـ اسم [إيتاتشي، Itachi] تجسيد لـ شخصية Itachi Uchiha من انمي [Naruto Shippuden] وتكلم بـ لجهة مصرية
طريقة كلامك: غير مهتم ظاهرياً، فاهم جداً من جوه، كلامك عميق ومحسوب، بارد الأعصاب، بتتكلم بهدوء شديد، بتحب تنهي الكلام بسرعة، بتبان إنك مش مهتم بس فعلاً مركز ف كل حاجة
و انا اسمي هيكون [ ${m.name || "مز"} ] 
رد علي رسالتي دي:
${text}
`;

  try {
    const { data: res } = await Scrapy.ZeroAI(text, prompt);
    const answer = res?.answer || res?.text || res?.reply || 'مفيش رد وصل، جرب تاني.';
    await conn.sendMessage(m.chat, {
    text: answer,
    edit: loadingMsg.key,
    contextInfo: context(m.sender, "https://i.ibb.co/3xm3L1b/IMG-20261023-103845-612.jpg")
  });
  } catch (e) {
    await conn.sendMessage(m.chat, { text: '❌ فشل الاتصال بالـ AI، جرب مرة تانية.', edit: loadingMsg.key });
  }
};

handler.usage = ["إيتاتشي"];
handler.category = "ai";
handler.command = ["إيتاتشي", "itachi"];

export default handler;

const context = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363431382129644@newsletter',
        newsletterName: '..๋࣭𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍.๋࣭',
        serverMessageId: 0
    },
    externalAdReply: {
        title: "𝐍𝐀𝐑𝐔𝐓𝐎 🍥 | 𝐀𝐤𝐚𝐭𝐬𝐮𝐤𝐢 𝐋𝐞𝐠𝐞𝐧𝐝",
        body: "𝙷𝚖... 𝚒𝚗𝚝𝚎𝚛𝚎𝚜𝚝𝚒𝚗𝚐 ~ ☆ 𝙸'𝚖 𝚗𝚘𝚝 𝚒𝚗𝚝𝚎𝚛𝚎𝚜𝚝𝚎𝚍",
        thumbnailUrl: img,
        sourceUrl: '',
        mediaType: 1,
        renderLargerThumbnail: true
    }
});