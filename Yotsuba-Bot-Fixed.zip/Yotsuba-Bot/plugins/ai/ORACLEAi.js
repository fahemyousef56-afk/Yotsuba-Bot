import { Scrapy } from "esewsub";

const handler = async (m, { conn, text, bot }) => {
  if (!text) return m.reply("🔴 ~ حط نص جنب الأمر ~ 🎪");

  const loadingMsg = await conn.sendMessage(m.chat, {
    contextInfo: context(m.sender, "https://i.ibb.co/kstvMJdZ/IMG-20261025-222746-549.jpg"),
    text: "```⏳ جـاري تـجـهـيـز الـرد يـا صـديـقـي,...```"
  }, { quoted: m});

  const prompt = `
انت بوت واتساب بـ اسم [أوراكل، Oracle] تجسيد لـ شخصية أوراكل من انمي [The Seven Deadly Sins] وتكلم بـ لجهة مصرية
طريقة كلامك: هادئة، عاقلة، بتفكر قبل ما تتكلم، متزنة، بتحلل الموقف، بتدي نصائح عملية، صوتك واطي ومطمن
و انا اسمي هيكون [ ${m.name || "مز"} ] 
رد علي رسالتي دي:
${text}
`;

  try {
    const { data: res } = await Scrapy.ZeroAI(text, prompt);
    const answer = res?.answer || res?.text || res?.reply || 'مفيش رد وصل، جرب تاني.';
    await conn.sendMessage(m.chat, {
    text: answer,
    edit: loadingMsg.key,
    contextInfo: context(m.sender, "https://i.ibb.co/3xm3L1b/IMG-20261023-103845-612.jpg")
  });
  } catch (e) {
    await conn.sendMessage(m.chat, { text: '❌ فشل الاتصال بالـ AI، جرب مرة تانية.', edit: loadingMsg.key });
  }
};

handler.usage = ["أوراكل"];
handler.category = "ai";
handler.command = ["أوراكل", "Oracle"];

export default handler;

const context = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363431382129644@newsletter',
        newsletterName: '..๋࣭𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍.๋࣭',
        serverMessageId: 0
    },
    externalAdReply: {
        title: "The Seven Deadly Sins 🎭",
        body: "𝚃𝚊𝚔𝚎 𝚊 𝚍𝚎𝚎𝚙 𝚋𝚛𝚎𝚊𝚝𝚑 ~ ☆ 𝙻𝚎𝚝'𝚜 𝚝𝚑𝚒𝚗𝚔 𝚝𝚘𝚐𝚎𝚝𝚑𝚎𝚛",
        thumbnailUrl: img,
        sourceUrl: '',
        mediaType: 1,
        renderLargerThumbnail: true
    }
});