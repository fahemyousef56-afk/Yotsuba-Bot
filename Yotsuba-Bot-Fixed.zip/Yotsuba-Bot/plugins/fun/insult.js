const playfulLines = [
  'يا @USER، دماغك محتاجة تعمل تحديث بسيط 😄',
  'يا @USER، حتى الحظ عامل لك كتم اليوم 😂',
  'يا @USER، أنت بطل… بس في اختيار الإجابة الغلط 😅',
  'يا @USER، حضورك قوي لدرجة إن الهدوء هرب من الجروب 🤭'
];

const handler = async (m, { conn }) => {
  const target = m.mentionedJid?.[0] || m.quoted?.sender;
  if (!target) return m.reply('😄 اعمل منشن أو رد على رسالة الشخص.');
  const line = playfulLines[Math.floor(Math.random() * playfulLines.length)]
    .replace('@USER', `@${target.split('@')[0]}`);
  await conn.sendMessage(m.chat, { text: `🎭 ${line}`, mentions: [target] }, { quoted: m });
};

handler.command = ['اشتم', 'تريقة'];
handler.usage = ['اشتم @منشن'];
handler.category = 'fun';
export default handler;