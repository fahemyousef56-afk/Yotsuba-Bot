const test = async (m, { conn, bot }) => {
  m.react("👋🏽")
  
  conn.msgUrl(m.chat, "*_وحيات امك لا_*", { 
    title: "𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑩𝜺𝑻⃝👻",
    body: "𝘛𝘩𝘦 𝘣𝘰𝘵 𝘩𝘢𝘴 𝘣𝘦𝘦𝘯 𝘴𝘵𝘰𝘱𝘱𝘦𝘥 𝘴𝘶𝘤𝘤𝘦𝘴𝘴𝘧𝘶𝘭𝘭𝘺",
    img: "https://i.ibb.co/3xm3L1b/IMG-20261023-103845-612.jpg",
    big: false 
  });
  
  setTimeout(() => {
    bot.stop();
  }, 1000); 
};

test.category = "owner";
test.command = ["ايقاف", "stop"];
test.owner = true;
export default test;