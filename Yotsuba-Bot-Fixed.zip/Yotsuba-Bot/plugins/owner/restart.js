const test = async (m, { conn, bot }) => {
  m.react("🐓")
  
  conn.msgUrl(m.chat, "*_وحيات امك يسطا لا ده انا في الاول ولاخر صاحبك_*.", { 
    title: "𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑩𝜺𝑻⃝👻",
    body: "𝘛𝘩𝘦 𝘣𝘰𝘵 𝘩𝘢𝘴 𝘣𝘦𝘦𝘯 𝘴𝘵𝘰𝘱𝘱𝘦𝘥 𝘴𝘶𝘤𝘤𝘦𝘴𝘴𝘧𝘶𝘭𝘭𝘺",
    img: "https://i.ibb.co/kstvMJdZ/IMG-20261025-222746-549.jpg",
    big: false 
  });
  
  setTimeout(() => {
    bot.restart();
  }, 1000); 
};

test.usage = ["رستارت"]
test.category = "owner";
test.command = ["رستارت", "restart"];
test.owner = true;
export default test;