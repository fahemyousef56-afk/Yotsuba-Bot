import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/*
|--------------------------------------------------------------------------
| غيّر المسارات حسب مكان ملفات البوت عندك
|--------------------------------------------------------------------------
*/
const PROJECT_DIR = path.join(__dirname, '../..');
const PLUGINS_DIR = path.join(PROJECT_DIR, 'plugins');
const BACKUP_DIR = path.join(__dirname, '../backups');

/*
|--------------------------------------------------------------------------
| الأسماء القديمة التي سيتم استبدالها في الملفات
|--------------------------------------------------------------------------
*/
const OLD_BOT_NAMES = [
    'SONG BOT',
    'SONG_BOT',
    'Naruto Bot',
    'NARUTO BOT',
    'Yotsuba',
    'مبضون',
];

/*
|--------------------------------------------------------------------------
| مجلدات ممنوع تعديلها نهائياً
|--------------------------------------------------------------------------
*/
const BLOCKED_DIRS = [
    'node_modules',
    '.git',
    'auth_info',
    'sessions',
    'session',
    'database',
    'backups',
];

/*
|--------------------------------------------------------------------------
| امتدادات الملفات النصية التي يسمح بتعديلها
|--------------------------------------------------------------------------
*/
const TEXT_EXTENSIONS = new Set([
    '.js',
    '.mjs',
    '.cjs',
    '.ts',
    '.json',
    '.yaml',
    '.yml',
    '.txt',
    '.md',
    '.html',
    '.css',
]);
const MEDIA_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4', '.webm']);

const isSafeFileName = (fileName) => {
    if (!fileName) return false;

    const normalized = path.normalize(fileName);

    if (
        normalized.startsWith('..') ||
        path.isAbsolute(normalized) ||
        normalized.includes('../') ||
        normalized.includes('..\\')
    ) {
        return false;
    }

    return true;
};

const getQuotedFile = (m) => {
    return m.quoted || m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
};

const getFileName = (quoted) => {
    return (
        quoted?.fileName ||
        quoted?.documentMessage?.fileName ||
        quoted?.message?.documentMessage?.fileName ||
        null
    );
};

const downloadQuotedFile = async (m, quoted) => {
    if (typeof m.quoted?.download === 'function') {
        return await m.quoted.download();
    }

    if (typeof quoted?.download === 'function') {
        return await quoted.download();
    }

    throw new Error('المكتبة الحالية لا توفر طريقة تحميل الملف من الرسالة');
};

const getTextFiles = (dir) => {
    if (!fs.existsSync(dir)) return [];

    const files = [];

    const walk = (currentDir) => {
        for (const item of fs.readdirSync(currentDir, { withFileTypes: true })) {
            const fullPath = path.join(currentDir, item.name);

            if (item.isDirectory()) {
                if (BLOCKED_DIRS.includes(item.name)) continue;
                walk(fullPath);
                continue;
            }

            const ext = path.extname(item.name).toLowerCase();

            if (TEXT_EXTENSIONS.has(ext)) {
                files.push(fullPath);
            }
        }
    };

    walk(dir);
    return files;
};

const replaceBotNameEverywhere = (newName) => {
    const roots = [
        PLUGINS_DIR,
        path.join(__dirname, '../src'),
        path.join(__dirname, '../config'),
    ];

    const changedFiles = [];

    for (const root of roots) {
        if (!fs.existsSync(root)) continue;

        for (const filePath of getTextFiles(root)) {
            let content;

            try {
                content = fs.readFileSync(filePath, 'utf8');
            } catch {
                continue;
            }

            let updated = content;

            for (const oldName of OLD_BOT_NAMES) {
                updated = updated.split(oldName).join(newName);
            }

            if (updated === content) continue;

            const relative = path.relative(process.cwd(), filePath);
            const backupPath = path.join(BACKUP_DIR, relative);

            fs.mkdirSync(path.dirname(backupPath), { recursive: true });
            fs.copyFileSync(filePath, backupPath);
            fs.writeFileSync(filePath, updated, 'utf8');

            changedFiles.push(relative);
        }
    }

    return changedFiles;
};

const handler = async (m, { conn, bot }) => {
    if (!m.isOwner && !m.owner) {
        return m.reply('❌ الأمر ده للمطور فقط');
    }

    const args = m.text
        ?.replace(/^استبدال\s*/i, '')
        .trim()
        .split(/\s+/) || [];

    const targetFileName = args.shift();

    let newBotName = args.join(' ').trim();
    const replacementUrl = /^https?:\/\/\S+$/i.test(newBotName) ? newBotName : null;
    const quoted = getQuotedFile(m);

    if (newBotName.startsWith('"') && newBotName.endsWith('"')) {
        newBotName = newBotName.slice(1, -1);
    }

    if (!targetFileName) {
        return m.reply('❌ اكتب اسم الملف بعد كلمة استبدال');
    }

    if (!newBotName) {
        return m.reply(
            '❌ اكتب اسم البوت الجديد\n\n' +
            'مثال:\n' +
            'استبدال menu.js Naruto Bot'
        );
    }

    if (!isSafeFileName(targetFileName)) {
        return m.reply('❌ اسم الملف غير مسموح');
    }

    const ext = path.extname(targetFileName).toLowerCase();

    if (!TEXT_EXTENSIONS.has(ext) && !MEDIA_EXTENSIONS.has(ext)) {
        return m.reply(
            '❌ امتداد الملف غير مسموح. المسموح: ملفات الكود والصور والفيديو.'
        );
    }

    const baseDir = MEDIA_EXTENSIONS.has(ext) ? PROJECT_DIR : PLUGINS_DIR;
    const targetPath = path.join(baseDir, targetFileName);

    if (!targetPath.startsWith(baseDir)) {
        return m.reply('❌ المسار خارج مجلد الإضافات غير مسموح');
    }

    try {
        await m.react('⏳');

        let fileBuffer;
        if (replacementUrl) {
            const response = await fetch(replacementUrl);
            if (!response.ok) throw new Error(`فشل تحميل الرابط (${response.status})`);
            fileBuffer = Buffer.from(await response.arrayBuffer());
        } else {
            const fileNameFromMessage = getFileName(quoted);
            if (!fileNameFromMessage) return m.reply('❌ اعمل رد على الملف أو اكتب رابط الصورة/الفيديو');
            fileBuffer = await downloadQuotedFile(m, quoted);
        }

        if (!fileBuffer || !Buffer.isBuffer(fileBuffer)) {
            return m.reply('❌ فشل تحميل الملف المرفق');
        }

        fs.mkdirSync(PLUGINS_DIR, { recursive: true });
        fs.mkdirSync(BACKUP_DIR, { recursive: true });

        /*
        |--------------------------------------------------------------------------
        | نسخة احتياطية من الملف القديم
        |--------------------------------------------------------------------------
        */
        let oldFileBackedUp = false;

        if (fs.existsSync(targetPath)) {
            const backupPath = path.join(
                BACKUP_DIR,
                `${targetFileName}.${Date.now()}.bak`
            );

            fs.mkdirSync(path.dirname(backupPath), { recursive: true });
            fs.copyFileSync(targetPath, backupPath);
            oldFileBackedUp = true;
        }

        /*
        |--------------------------------------------------------------------------
        | استبدال الملف القديم بالملف المرسل
        |--------------------------------------------------------------------------
        */
        fs.writeFileSync(targetPath, fileBuffer);

        /*
        |--------------------------------------------------------------------------
        | تغيير اسم البوت داخل ملفات الكود
        |--------------------------------------------------------------------------
        */
        const changedFiles = replacementUrl ? [] : replaceBotNameEverywhere(newBotName);

        await m.react('✅');

        await conn.sendMessage(
            m.chat,
            {
                text:
                    `╔══════════════════════╗\n` +
                    `║  ✅ *تم الاستبدال بنجاح*\n` +
                    `╠══════════════════════╣\n` +
                    `║  📄 الملف: ${targetFileName}\n` +
                    `║  🤖 التغيير: ${replacementUrl ? 'تحديث الوسائط من الرابط' : newBotName}\n` +
                    `║  🗂️ نسخة احتياطية: ${oldFileBackedUp ? 'نعم' : 'لا'}\n` +
                    `║  📝 ملفات تم تعديلها: ${changedFiles.length}\n` +
                    `╚══════════════════════╝\n\n` +
                    `🔄 أعد تشغيل البوت لتظهر التغييرات`,
            },
            { quoted: m }
        );
    } catch (error) {
        await m.react('❌');

        await m.reply(
            `❌ فشل استبدال الملف\n\n` +
            `⚠️ السبب: ${error?.message || 'خطأ غير معروف'}`
        );
    }
};

handler.command = ['استبدال', 'بدل'];
handler.usage = ['استبدال اسم_الملف اسم_البوت_الجديد'];
handler.category = 'owner';
handler.owner = true;
handler.noSub = true;

export default handler;