// 🌸 ملف: ضيف_مطور.js - إضافة مطور جديد - 𝑩𝜣𝑻⃝𖤐

const EMOJI = '🌸';
const BOT_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑩𝜺𝑻⃝👻';

const handler = async (m, { conn, bot }) => {
    // ✅ الحصول على المستخدم المطلوب
    const targetLid = m.mentionedJid?.[0] || m.quoted?.sender;
    
    if (!targetLid) {
        return m.reply(
            `${EMOJI} *أمر إضافة مطور جديد*\n\n` +
            `📌 *الاستخدام:*\n` +
            `.ضيف_مطور @المستخدم\n\n` +
            `أو رد على رسالة المستخدم ثم اكتب .ضيف_مطور`
        );
    }

    // ✅ استخراج الرقم من الـ JID
    const targetNumber = targetLid.split('@')[0].split(':')[0];
    let userJid = targetNumber + '@s.whatsapp.net';
    let userName = 'مطور جديد';

    // ✅ محاولة الحصول على اسم المستخدم
    try {
        // إذا كانت الرسالة من مجموعة
        if (m.chat.endsWith('@g.us')) {
            const meta = await conn.groupMetadata(m.chat);
            const user = meta.participants.find(p => 
                p.id === targetLid || 
                p.phoneNumber === targetNumber
            );
            if (user) {
                userName = user.name || user.displayName || 'مطور جديد';
                userJid = user.phoneNumber + '@s.whatsapp.net';
            }
        }
    } catch (e) {
        console.log(`${EMOJI} فشل جلب بيانات المجموعة:`, e.message);
    }

    // ✅ إذا كان المستخدم منشن، حاول جلب اسمه من pushName
    if (m.mentionedJid?.[0]) {
        userName = m.pushName || 'مطور جديد';
    }

    // ✅ إذا كان رد على رسالة، حاول جلب اسم المرسل
    if (m.quoted?.sender) {
        try {
            const quotedSender = m.quoted.sender;
            const quotedNumber = quotedSender.split('@')[0].split(':')[0];
            if (quotedNumber === targetNumber) {
                userName = m.quoted.pushName || 'مطور جديد';
                userJid = quotedSender;
            }
        } catch (e) {}
    }

    // ✅ التحقق من أنه ليس مطوراً بالفعل
    const isAlreadyOwner = bot.config.owners.some(o => 
        o.jid === userJid || 
        o.jid?.split('@')[0] === targetNumber ||
        o.lid === targetLid
    );

    if (isAlreadyOwner) {
        return m.reply(`${EMOJI} *الشخص ده مطور بالفعل*`);
    }

    // ✅ إضافة المطور الجديد
    const newOwner = {
        name: userName,
        jid: userJid,
        lid: targetLid,
        secondary: true,
        addedAt: Date.now()
    };

    // ✅ إضافة إلى config
    bot.config.owners.push(newOwner);

    // ✅ حفظ في قاعدة البيانات
    try {
        if (!global.db) global.db = {};
        if (!global.db.data) global.db.data = {};
        if (!global.db.data.extraOwners) global.db.data.extraOwners = [];
        
        // إزالة أي إدخال مكرر
        global.db.data.extraOwners = global.db.data.extraOwners.filter(
            o => o.jid !== userJid && o.lid !== targetLid
        );
        global.db.data.extraOwners.push(newOwner);
        
        console.log(`${EMOJI} ✅ تم إضافة مطور جديد: ${userJid} (${userName})`);
    } catch (e) {
        console.error(`${EMOJI} فشل حفظ المطور:`, e.message);
    }

    // ✅ إرسال رسالة التأكيد في الجروب/الخاص
    const mention = targetLid;
    await conn.sendMessage(m.chat, {
        text:
            `${EMOJI}━━━[ *✅ تم إضافة مطور جديد* ]━━━${EMOJI}\n\n` +
            `👤 *الاسم:* ${userName}\n` +
            `📱 *الرقم:* ${targetNumber}\n\n` +
            `*📋 الصلاحيات:*\n` +
            `├ 🔄 *.رستارت* - إعادة تشغيل البوت\n` +
            `├ 🧹 *.تنظيف* - حذف الملفات المؤقتة\n` +
            `├ 📢 *.اذاعه* - إرسال رسالة للجميع\n` +
            `└ 🗑️ *.تنظيف_شامل* - تنظيف شامل\n\n` +
            `${EMOJI} *تم الحفظ - سيبقى بعد الريستارت*`,
        mentions: [mention]
    }, { quoted: m });

    // ✅ إرسال رسالة خاصة للمطور الجديد
    try {
        await conn.sendMessage(userJid, {
            text:
                `${EMOJI}━━━[ *🎉 تهانينا!* ]━━━${EMOJI}\n\n` +
                `🎊 *تم تعيينك كمطور في*\n${BOT_NAME}\n\n` +
                `*📋 الأوامر المتاحة:*\n` +
                `├ .رستارت - إعادة تشغيل البوت\n` +
                `├ .تنظيف - حذف الملفات المؤقتة\n` +
                `├ .اذاعه - إرسال رسالة للجميع\n` +
                `└ .تنظيف_شامل - تنظيف شامل\n\n` +
                `${EMOJI} *استخدم الأوامر بمسؤولية*`
        });
    } catch (e) {
        console.log(`${EMOJI} فشل إرسال رسالة خاصة للمطور الجديد:`, e.message);
    }
};

handler.usage = ['ضيف_مطور @مستخدم'];
handler.category = 'owner';
handler.command = ['ضيف_مطور', 'اضافه_مطور', 'add_owner', 'اضف_مطور'];
handler.owner = true;

export default handler;