const handler = async (m, { conn, text }) => {
  m.reply("*اسف/ه انا لازم اخرج عشان جو خرج يلا سلامات*")
  conn.groupLeave(m.chat)
};

handler.usage = ["اخرج"];
handler.category = "group";
handler.command = ["اخرج"];
handler.owner = true 
export default handler;