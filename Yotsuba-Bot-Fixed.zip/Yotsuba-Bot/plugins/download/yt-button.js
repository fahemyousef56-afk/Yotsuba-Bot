// 🕸 ملف: يوتيوب.js - بحث وتحميل من يوتيوب - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';
const MAX_SIZE = 100 * 1024 * 1024; // 100 ميجا

// رسالة متحوّلة من القناة (من غير كارت الرابط)
const buildContext = () => ({
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
});

// ─────────────── أدوات مساعدة ───────────────

const isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);

const fetchJson = async (url, timeout = 20000) => {
    const res = await fetch(url, {
        signal: AbortSignal.timeout(timeout),
        headers: { 'User-Agent': UA, Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const body = await res.text();
    try {
        return JSON.parse(body);
    } catch {
        throw new Error('الرد مش JSON صالح');
    }
};

const safeName = (name, fallback = 'YouTube') =>
    String(name || fallback).replace(/[\\/:*?"<>|\n\r]/g, '').trim().slice(0, 60) || fallback;

// تحميل الملف كـ buffer مع الفحوصات
const downloadBuffer = async (url, timeout) => {
    const res = await fetch(url, {
        signal: AbortSignal.timeout(timeout),
        headers: { 'User-Agent': UA },
    });
    if (!res.ok) throw new Error(`السيرفر رجع خطأ ${res.status}`);

    const length = Number(res.headers.get('content-length') || 0);
    if (length > MAX_SIZE) throw new Error('الملف كبير جداً');

    const buffer = Buffer.from(await res.arrayBuffer());
    if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');
    if (buffer.length > MAX_SIZE) throw new Error('الملف كبير جداً');

    return buffer;
};

// ─────────────── مصادر البحث ───────────────

// بيحوّل شكل أي مصدر لشكل موحد: { title, image, timestamp, url }
const normalizeResult = (item) => {
    if (!item) return null;

    const url =
        item.url ||
        item.link ||
        (item.videoId ? `https://youtu.be/${item.videoId}` : null) ||
        (item.id && /^[\w-]{11}$/.test(item.id) ? `https://youtu.be/${item.id}` : null);

    if (!isHttp(url)) return null;

    return {
        title: item.title || item.name || 'بدون عنوان',
        image: item.image || item.thumbnail || item.thumb || item.thumbnails?.[0]?.url || null,
        timestamp: item.timestamp || item.duration?.timestamp || item.duration || item.time || '',
        url,
    };
};

// المصدر الأساسي: مكتبة yt-search (من غير API خارجي)
const searchWithLibrary = async (query) => {
    const mod = await import('yt-search');
    const yts = mod.default || mod;
    const res = await yts(query);
    return normalizeResult(res?.videos?.[0]);
};

// المصادر الاحتياطية: APIs
const SEARCH_APIS = (q) => [
    `https://emam-api.web.id/home/sections/Search/api/YouTube/search?q=${encodeURIComponent(q)}`,
    `https://api.siputzx.my.id/api/s/youtube?query=${encodeURIComponent(q)}`,
    `https://api.doude.pw/api/ytsearch?q=${encodeURIComponent(q)}`,
];

const searchWithApis = async (query) => {
    for (const api of SEARCH_APIS(query)) {
        try {
            const json = await fetchJson(api, 15000);
            const list = json?.data || json?.result || json?.results || [];
            if (!Array.isArray(list) || !list.length) continue;

            const first = list.map(normalizeResult).find(Boolean);
            if (first) return first;
        } catch (e) {
            console.log(`${EMOJI} بحث فشل: ${new URL(api).hostname} - ${e?.message}`);
        }
    }
    return null;
};

const searchYouTube = async (query) => {
    try {
        const result = await searchWithLibrary(query);
        if (result) return result;
    } catch (e) {
        console.log(`${EMOJI} yt-search فشلت (متنزلة؟): ${e?.message}`);
    }
    return searchWithApis(query);
};

// ─────────────── أدوات استخراج الروابط ───────────────

const extractAudio = (data) => {
    const candidates = [
        data?.data?.dl,
        data?.data?.download,
        data?.data?.url,
        data?.download,
        data?.url,
        data?.result?.audio,
        data?.result?.download_url,
        data?.result?.url,
        data?.audio,
        data?.link,
    ];
    return candidates.find(isHttp) || null;
};

const extractVideo = (data) => {
    const candidates = [
        data?.data?.video,
        data?.data?.dl,
        data?.data?.download,
        data?.data?.url,
        data?.video,
        data?.result?.video,
        data?.result?.url_video,
        data?.result?.download_url,
        data?.result?.url,
        data?.download,
        data?.url,
        data?.link,
    ];
    let video = candidates.find(isHttp);

    if (!video && Array.isArray(data?.data?.links)) {
        const links = data.data.links;
        const q720 = links.find((l) => l.quality === '720p' || l.qualityLabel === '720p');
        video = q720?.url || q720?.downloadUrl || links[links.length - 1]?.url;
    }

    return isHttp(video) ? video : null;
};

const extractTitle = (data, fallback) =>
    data?.title || data?.data?.title || data?.result?.title || fallback;

// ─────────────── مصادر التحميل ───────────────

const AUDIO_APIS = (u) => [
    `https://xenoytdl-2.vercel.app/api/youtube?url=${encodeURIComponent(u)}`,
    `https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(u)}`,
    `https://api.doude.pw/api/ytmp3?url=${encodeURIComponent(u)}`,
];

const VIDEO_APIS = (u) => [
    `https://xenoytdl-2.vercel.app/api/youtube?url=${encodeURIComponent(u)}`,
    `https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(u)}`,
    `https://api.doude.pw/api/ytmp4?url=${encodeURIComponent(u)}`,
];

const resolveMedia = async (apis, extractor, fallbackTitle) => {
    for (const api of apis) {
        try {
            const data = await fetchJson(api, 25000);
            const url = extractor(data);
            if (url) return { url, title: extractTitle(data, fallbackTitle) };
        } catch (e) {
            console.log(`${EMOJI} API فشلت: ${new URL(api).hostname} - ${e?.message}`);
        }
    }
    throw new Error('لا يوجد رابط تحميل، جرب بعدين');
};

// ─────────────── تحميل الصوت والفيديو ───────────────

const downloadAudio = async (m, conn, link, send) => {
    await m.react('⏳');
    await send(`${EMOJI} ⏳ جاري تحميل الصوت...`);

    try {
        const { url, title } = await resolveMedia(AUDIO_APIS(link), extractAudio, 'صوت');
        const name = safeName(title, 'صوت');

        let buffer;
        try {
            buffer = await downloadBuffer(url, 90000);
        } catch (e) {
            console.error('فشل تحميل الصوت، هيتبعت الرابط:', e?.message);
            await send(
                `${EMOJI} *تعذر إرسال الملف مباشرة*\n\n` +
                `📌 *العنوان:* ${title}\n` +
                `🔗 *رابط التحميل المباشر:*\n${url}\n\n` +
                `${EMOJI} *${BOT_NAME}*`
            );
            await m.react('✅');
            return;
        }

        await conn.sendMessage(
            m.chat,
            {
                audio: buffer,
                mimetype: 'audio/mpeg',
                ptt: false,
                fileName: `${name}.mp3`,
                contextInfo: buildContext(),
            },
            { quoted: m }
        );

        await m.react('✅');
    } catch (err) {
        console.error(`${EMOJI} خطأ في تحميل الصوت:`, err);
        await m.react('❌');
        await send(`${EMOJI} ❌ فشل تحميل الصوت: ${String(err?.message || '').slice(0, 100)}`);
    }
};

const downloadVideo = async (m, conn, link, send) => {
    await m.react('⏳');
    await send(`${EMOJI} ⏳ جاري تحميل الفيديو...`);

    try {
        const { url, title } = await resolveMedia(VIDEO_APIS(link), extractVideo, 'فيديو');
        const name = safeName(title, 'فيديو');

        let buffer;
        try {
            buffer = await downloadBuffer(url, 120000);
        } catch (e) {
            console.error('فشل تحميل الفيديو، هيتبعت الرابط:', e?.message);
            await send(
                `${EMOJI} *تعذر إرسال الملف مباشرة*\n\n` +
                `📌 *العنوان:* ${title}\n` +
                `🔗 *رابط التحميل المباشر:*\n${url}\n\n` +
                `${EMOJI} *${BOT_NAME}*`
            );
            await m.react('✅');
            return;
        }

        await conn.sendMessage(
            m.chat,
            {
                video: buffer,
                mimetype: 'video/mp4',
                fileName: `${name}.mp4`,
                caption:
                    `${EMOJI} *${title}*\n\n` +
                    `👤 *المطور:* ${DEVELOPER}\n` +
                    `${EMOJI} *${BOT_NAME}*`,
                contextInfo: buildContext(),
            },
            { quoted: m }
        );

        await m.react('✅');
    } catch (err) {
        console.error(`${EMOJI} خطأ في تحميل الفيديو:`, err);
        await m.react('❌');
        await send(`${EMOJI} ❌ فشل تحميل الفيديو: ${String(err?.message || '').slice(0, 100)}`);
    }
};

// ─────────────── الهاندلر ───────────────

const AUDIO_COMMANDS = ['يوت_اغنيه'];
const VIDEO_COMMANDS = ['يوتيوب'];

const handler = async (m, { conn, text, command, usedPrefix }) => {
    const prefix = usedPrefix || '.';
    const cmd = String(command || '').toLowerCase();
    const input = (text || m.quoted?.text || m.quoted?.caption || '').trim();

    const send = async (message) => {
        try {
            await conn.sendMessage(m.chat, { text: message, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(message);
        }
    };

    // ───── أوامر التحميل (جاية من الأزرار أو كتابة مباشرة) ─────
    if (AUDIO_COMMANDS.includes(cmd) || VIDEO_COMMANDS.includes(cmd)) {
        const link = input.match(/https?:\/\/[^\s]+/i)?.[0];

        if (!link) {
            return send(
                `${EMOJI} ❌ حط رابط يوتيوب بعد الأمر\n\n` +
                `مثال:\n${prefix}${cmd} https://youtu.be/xxxxxxxxxxx`
            );
        }

        return AUDIO_COMMANDS.includes(cmd)
            ? downloadAudio(m, conn, link, send)
            : downloadVideo(m, conn, link, send);
    }

    // ───── أمر البحث ─────
    if (!input) {
        return send(
            `${EMOJI}━━━[ *🎵 تحميل من يوتيوب* ]━━━${EMOJI}\n\n` +
            `📌 *${prefix}شغل اسم الأغنية*\n` +
            `📝 مثال: ${prefix}شغل حبيبتي\n\n` +
            `👤 *المطور:* ${DEVELOPER}\n` +
            `${EMOJI} ${BOT_NAME}`
        );
    }

    try {
        await m.react('🔍');

        const result = await searchYouTube(input);

        if (!result) {
            await m.react('❌');
            return send(`${EMOJI} ❌ مش لاقي نتائج، جرب كلمة تانية`);
        }

        const { title, image, timestamp: time, url } = result;

        const bodyText = `${EMOJI}━━━[ *🎵 نتيجة البحث* ]━━━${EMOJI}

📌 ${title || 'بدون عنوان'}
⏱️ ${time || ''}

👤 *المطور:* ${DEVELOPER}
${EMOJI} *اختر التحميل 👇*`;

        const imageUrl = isHttp(image) ? image : null;

        try {
            if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

            const payload = {
                bodyText,
                footerText: `${EMOJI} ${BOT_NAME}`,
                buttons: [
                    {
                        name: 'quick_reply',
                        params: {
                            display_text: `${EMOJI} تحميل صوت 🎵`,
                            id: `${prefix}يوت_اغنيه ${url}`,
                        },
                    },
                    {
                        name: 'quick_reply',
                        params: {
                            display_text: `${EMOJI} تحميل فيديو 🎬`,
                            id: `${prefix}يوتيوب ${url}`,
                        },
                    },
                ],
                mentions: [m.sender],
                contextInfo: buildContext(),
                interactiveConfig: { buttons_limits: 10 },
            };

            if (imageUrl) payload.imageUrl = imageUrl;

            await conn.sendButton(m.chat, payload, m);
        } catch (e) {
            console.error('فشل sendButton، هبعت نص عادي:', e?.message);

            // بديل: أوامر نصية (مع صورة لو موجودة)
            const fallbackText =
                `${bodyText}\n\n` +
                `🎵 للصوت:\n${prefix}يوت_اغنيه ${url}\n\n` +
                `🎬 للفيديو:\n${prefix}يوتيوب ${url}`;

            const content = imageUrl
                ? { image: { url: imageUrl }, caption: fallbackText, contextInfo: buildContext() }
                : { text: fallbackText, contextInfo: buildContext() };

            await conn.sendMessage(m.chat, content, { quoted: m }).catch(() => send(fallbackText));
        }

        await m.react('✅');
    } catch (e) {
        console.error(`${EMOJI} خطأ:`, e);
        await m.react('❌');
        await send(`${EMOJI} ❌ فشل البحث: ${String(e?.message || e).slice(0, 60)}`);
    }
};

handler.usage = ['شغل'];
handler.command = ['شغل', 'play', 'اغنية', 'فيديو', 'اغنيه', 'يوت_اغنيه', 'يوتيوب'];
handler.category = 'downloads';

export default handler;