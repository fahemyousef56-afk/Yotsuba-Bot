import { getInstagram, sendMedia } from '../../system/dl_providers.js';

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const buildContext = (title = '📸 Instagram Downloader') => ({
  isForwarded: true,
  forwardingScore: 999,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
  externalAdReply: {
    title,
    body: CHANNEL_NAME,
    sourceUrl: CHANNEL_LINK,
    mediaType: 1,
    renderLargerThumbnail: false,
  },
});

const insta = async (m, { text, Api, conn, usedPrefix, command }) => {
  const prefix = usedPrefix || '.';
  const link = (text || m.quoted?.text || '').match(/https?:\/\/[^\s]+/i)?.[0];

  if (!link) {
    return conn.sendMessage(
      m.chat,
      {
        text: `❌ حط رابط انستجرام جنب الأمر\n\nمثال:\n${prefix}${command || 'انستا'} https://www.instagram.com/reel/xxxxxx`,
        contextInfo: buildContext(),
      },
      { quoted: m }
    );
  }

  try {
    await m.react('⏳');

    // بيجرب Api البوت ثم btch-downloader ثم APIs بديلة (انظر system/dl_providers.js)
    let media = await getInstagram(link, Api);

    // لو فيه فيديو، نتجاهل الصور الجانبية (صور المعاينة) ونبعت الفيديوهات بس
    const videos = media.filter((i) => i.type === 'video');
    const items = (videos.length ? videos : media).slice(0, 5);

    for (const item of items) {
      await sendMedia(
        conn,
        m,
        item,
        item.type === 'video'
          ? '```📥 Instagram video downloaded successfully```'
          : '```📥 Instagram image downloaded successfully```',
        buildContext()
      );
    }

    await m.react('✅');
  } catch (error) {
    console.error(error?.message || error);
    await m.react('❌');
    await m.reply(`❌ ${String(error?.message || error).slice(0, 150)}`);
  }
};

insta.usage = ['انستا'];
insta.category = 'downloads';
insta.command = ['انستا', 'instagram', 'ig'];
insta.admin = false;

export default insta;
