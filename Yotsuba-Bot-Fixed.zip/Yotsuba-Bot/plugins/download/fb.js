import { getFacebook, sendMedia } from '../../system/dl_providers.js';

const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const buildContext = (title = 'Facebook Downloader') => ({
  isForwarded: true,
  forwardingScore: 999,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
  externalAdReply: {
    title,
    body: CHANNEL_NAME,
    sourceUrl: CHANNEL_LINK,
    mediaType: 1,
    renderLargerThumbnail: false,
  },
});

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const prefix = usedPrefix || '/';
  const link = (text || m.quoted?.text || '').match(/https?:\/\/[^\s]+/i)?.[0];

  if (!link) {
    return conn.sendMessage(
      m.chat,
      {
        text: `*❲ ❤️ ❳ ~ ضع رابط الفيديو بعد الأمر ~ ❲ 💙 ❳ *\n\nمثال:\n${prefix}${command} https://www.facebook.com/reel/xxxxxx`,
        contextInfo: buildContext(),
      },
      { quoted: m }
    );
  }

  await m.react('🌾');

  try {
    // بيجرب fdownloader ثم btch-downloader ثم APIs بديلة (انظر system/dl_providers.js)
    const media = await getFacebook(link);
    const video = media.find((i) => i.type === 'video') || media[0];

    const caption =
      `> *🎬 Facebook Video*\n` +
      `> *تم بواسطة ~ ${m.pushName || 'مستخدم'}*`;

    await sendMedia(conn, m, video, caption, buildContext('Facebook Downloader'));

    await m.react('✅');
  } catch (e) {
    console.error(e?.message || e);
    await m.react('❌');
    await m.reply(`❌ *فشل التحميل:*\n${String(e?.message || e).slice(0, 150)}`);
  }
};

handler.usage = ['فيس'];
handler.category = 'downloads';
handler.command = /^(فيس|فيسبوك|fb|fbdl|facebook)$/i;

export default handler;
