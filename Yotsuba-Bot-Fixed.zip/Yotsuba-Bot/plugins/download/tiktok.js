// 🕸 ملف: تيك.js - تحميل فيديوهات تيك توك - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import axios from 'axios';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/dwRnNBxj/IMG-20261013-114123-968.jpg';

const BASE_URL = 'https://www.tikwm.com';
const UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';

const buildContext = (title = BOT_NAME) => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        thumbnailUrl: MAIN_IMAGE,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

// ────────────────[دوال مساعدة]────────────────
const fixUrl = (url) => {
    if (!url || typeof url !== 'string') return null;
    if (/^https?:\/\//i.test(url)) return url;
    if (url.startsWith('//')) return 'https:' + url;
    return BASE_URL + (url.startsWith('/') ? url : '/' + url);
};

// بدون علم g عشان test() ما يتلخبطش
const TIKTOK_REGEX = /https?:\/\/(?:[a-z0-9-]+\.)?tiktok\.com\/[^\s]+/i;

function createCaption(title, author, duration) {
    return `${EMOJI}━━━[ *🎵 تيك توك* ]━━━${EMOJI}

📌 *العنوان:* ${title || 'غير متوفر'}
👤 *المؤلف:* ${author?.nickname || author?.unique_id || 'غير متوفر'}
⏱️ *المدة:* ${duration || 'غير متوفر'} ثانية

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;
}

function createSearchCaption(data) {
    return `${EMOJI}━━━[ *🎵 نتيجة البحث* ]━━━${EMOJI}

📌 *العنوان:* ${data.title || 'غير متوفر'}
👤 *المؤلف:* ${data.author?.nickname || data.author?.unique_id || 'غير معروف'}
⏱️ *المدة:* ${data.duration || 'غير متوفر'} ثانية

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;
}

// ────────────────[تحميل مع إعادة المحاولة]────────────────
async function downloadWithRetry(url, retries = 2) {
    let lastError;

    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: 60000,
                maxContentLength: 100 * 1024 * 1024,
                headers: { 'User-Agent': UA, Referer: BASE_URL + '/' },
            });

            const buffer = Buffer.from(response.data);
            if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');
            return buffer;
        } catch (error) {
            lastError = error;
            console.log(`⚠️ محاولة ${i + 1} فشلت:`, error.message);
            if (i < retries - 1) await new Promise((r) => setTimeout(r, 2000));
        }
    }
    throw lastError;
}

// ────────────────[إرسال فيديو: عدة مصادر ← buffer ← رابط]────────────────
async function sendVideo(conn, m, urls, caption) {
    const list = [...new Set(urls.filter(Boolean))];
    const content = { caption, mimetype: 'video/mp4', contextInfo: buildContext() };

    for (const url of list) {
        try {
            const buffer = await downloadWithRetry(url);
            await conn.sendMessage(m.chat, { video: buffer, ...content }, { quoted: m });
            return;
        } catch (e) {
            console.error('❌ فشل مصدر، هجرب اللي بعده:', e?.message);
        }
    }

    // محاولة الإرسال بالرابط المباشر
    for (const url of list) {
        try {
            await conn.sendMessage(m.chat, { video: { url }, ...content }, { quoted: m });
            return;
        } catch (e) {
            console.error('❌ فشل الإرسال بالرابط:', e?.message);
        }
    }

    // آخر حل: الرابط نصاً
    await conn.sendMessage(
        m.chat,
        {
            text: `${EMOJI} *فشل تحميل الفيديو*\n\n📌 *رابط الفيديو:*\n${list[0] || 'غير متوفر'}\n\n${EMOJI} *${BOT_NAME}*`,
            contextInfo: buildContext(),
        },
        { quoted: m }
    );
}

// ────────────────[الأمر الرئيسي]────────────────
const handler = async (m, { conn, text, command, usedPrefix }) => {
    const chatId = m.chat;
    const prefix = usedPrefix || '.';
    const input = (text || m.quoted?.text || '').trim();

    const send = async (message) => {
        try {
            await conn.sendMessage(chatId, { text: message, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(message);
        }
    };

    // ─── بدون نص: رسالة الشرح ───
    if (!input) {
        const bodyText = `${EMOJI}━━━[ *📱 تحميل من تيك توك* ]━━━${EMOJI}

📌 *طريقة الاستخدام:*
▸ ${prefix}${command} رابط تيك توك
▸ ${prefix}${command} كلمة بحث

📝 *مثال:*
▸ ${prefix}${command} https://tiktok.com/...
▸ ${prefix}${command} رقص

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;

        try {
            if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

            await conn.sendButton(chatId, {
                imageUrl: MAIN_IMAGE,
                bodyText,
                footerText: `${EMOJI} ${BOT_NAME}`,
                buttons: [
                    {
                        name: 'cta_url',
                        params: {
                            display_text: `${EMOJI} قناة البوت`,
                            url: CHANNEL_LINK,
                        },
                    },
                ],
                mentions: [m.sender],
                newsletter: {
                    name: CHANNEL_NAME,
                    jid: CHANNEL_JID,
                },
                interactiveConfig: { buttons_limits: 20 },
            }, m);
        } catch (e) {
            await send(bodyText);
        }
        return;
    }

    try {
        await conn.sendMessage(chatId, { react: { text: '🕒', key: m.key } });

        const link = input.match(TIKTOK_REGEX)?.[0];

        if (link) {
            // ─── تحميل من رابط ───
            const res = await axios.get(`${BASE_URL}/api/?url=${encodeURIComponent(link)}&hd=1`, {
                timeout: 30000,
                headers: { 'User-Agent': UA },
            });
            const data = res.data?.data;

            if (!data?.play && !(Array.isArray(data?.images) && data.images.length)) {
                await conn.sendMessage(chatId, { react: { text: '❌', key: m.key } });
                return send(`${EMOJI} ❌ *رابط غير صالح أو بدون محتوى*`);
            }

            const { title, duration, author, images } = data;
            const caption = createCaption(title, author, duration);

            if (Array.isArray(images) && images.length) {
                // ─── إرسال صور متعددة (لحد 10) ───
                let sent = 0;
                for (let i = 0; i < Math.min(images.length, 10); i++) {
                    try {
                        const imageBuffer = await downloadWithRetry(fixUrl(images[i]));
                        await conn.sendMessage(
                            chatId,
                            {
                                image: imageBuffer,
                                caption: i === 0 ? caption : '',
                                contextInfo: buildContext(),
                            },
                            { quoted: m }
                        );
                        sent++;
                    } catch (imageError) {
                        console.error(`❌ فشل تحميل الصورة ${i + 1}:`, imageError.message);
                    }
                }
                if (!sent) throw new Error('فشل تحميل الصور');
            } else {
                // ─── إرسال فيديو: جودة عالية ← عادية ← علامة مائية ───
                await sendVideo(
                    conn,
                    m,
                    [fixUrl(data.hdplay), fixUrl(data.play), fixUrl(data.wmplay)],
                    caption
                );
            }
        } else {
            // ─── بحث عن فيديوهات ───
            const params = new URLSearchParams({
                keywords: input,
                count: '5',
                cursor: '0',
                HD: '1',
            });

            const res = await axios.post(`${BASE_URL}/api/feed/search`, params.toString(), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    Cookie: 'current_language=en',
                    'User-Agent': UA,
                },
                timeout: 30000,
            });

            const results =
                (res.data?.data?.videos || []).filter((v) => v.play || v.hdplay || v.wmplay);

            if (!results.length) {
                await conn.sendMessage(chatId, { react: { text: '❌', key: m.key } });
                return send(`${EMOJI} ❌ *لا توجد نتائج للبحث*`);
            }

            // ─── فيديو واحد فقط (لتوفير الرام) ───
            const video = results[0];
            await sendVideo(
                conn,
                m,
                [fixUrl(video.hdplay), fixUrl(video.play), fixUrl(video.wmplay)],
                createSearchCaption(video)
            );
        }

        await conn.sendMessage(chatId, { react: { text: '✅', key: m.key } });
    } catch (error) {
        console.error('❌ خطأ في أمر تيك توك:', error);

        await conn.sendMessage(chatId, { react: { text: '❌', key: m.key } });
        await send(`${EMOJI} ❌ *حدث خطأ*\n\n${String(error?.message || 'يرجى المحاولة مرة أخرى').slice(0, 150)}`);
    }
};

handler.usage = ['تيك'];
handler.command = ['تيك', 'tiktok', 'tt', 'تيك توك'];
handler.category = 'downloads';

export default handler;