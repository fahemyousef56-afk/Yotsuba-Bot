/*
|--------------------------------------------------------------------------
| أمر ايديت - البحث عن فيديوهات تيك توك
|--------------------------------------------------------------------------
|
| الاستخدام:
| ايديت انمي
| ايديت اكشن
| ايديت فيديوهات مضحكة
|
*/

const API_TIMEOUT = 30000;
const BASE_URL = 'https://www.tikwm.com';
const CHANNEL_URL = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_JID = '120363433665479594@newsletter';

const fetchWithTimeout = async (url, options = {}) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT);

    try {
        return await fetch(url, {
            ...options,
            signal: controller.signal,
            headers: {
                Accept: 'application/json, */*',
                'User-Agent':
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
                ...(options.headers || {}),
            },
        });
    } finally {
        clearTimeout(timer);
    }
};

// تحويل الروابط النسبية لروابط كاملة
const fixUrl = (url) => {
    if (!url) return null;
    if (url.startsWith('http')) return url;
    if (url.startsWith('//')) return 'https:' + url;
    return BASE_URL + (url.startsWith('/') ? url : '/' + url);
};

const searchTikTok = async (query) => {
    const url =
        `${BASE_URL}/api/feed/search` +
        `?keywords=${encodeURIComponent(query)}` +
        `&count=10&cursor=0&hd=1`;

    const response = await fetchWithTimeout(url);
    if (!response.ok) return [];

    const data = await response.json();
    if (!data?.data) return [];

    const result = data.data;
    const videos = result.videos || result.data || [];

    return videos
        .map((item) => ({
            id: item.video_id || item.id,
            title: item.title || item.desc || query,
            play: fixUrl(item.play || item.hdplay || item.wmplay || item.play_url || item.video_url),
            author: item.author?.nickname || item.author?.unique_id || '',
        }))
        .filter((item) => item.play);
};

const getVideoBuffer = async (url) => {
    const response = await fetchWithTimeout(url, {
        headers: { Referer: BASE_URL + '/' },
    });

    if (!response.ok) {
        throw new Error('تعذر تحميل الفيديو');
    }

    const buffer = Buffer.from(await response.arrayBuffer());

    if (!buffer.length || buffer.length < 1000) {
        throw new Error('الفيديو فاضي أو تالف');
    }

    return buffer;
};

// تجربة أكثر من فيديو لحد ما واحد ينجح
const getFirstWorkingVideo = async (results) => {
    for (const item of results.slice(0, 5)) {
        try {
            const buffer = await getVideoBuffer(item.play);
            return { buffer, item };
        } catch (e) {
            continue;
        }
    }
    throw new Error('مقدرتش أحمّل أي فيديو من النتائج، جرب مرة تانية');
};

const handler = async (m, { conn, bot, text: argText }) => {
    // استخراج الكلمة المطلوبة
    const rawText = (argText ?? m.text ?? '').trim();

    const query = rawText
        .replace(/^[.!#/]?\s*(ايديت|edit)\s*/i, '')
        .trim();

    if (!query) {
        return m.reply(
            '✍️ اكتب اسم الفيديو بعد الأمر\n\n' +
            'مثال:\n' +
            'ايديت انمي\n' +
            'ايديت اكشن\n' +
            'ايديت فيديوهات مضحكة'
        );
    }

    try {
        await m.react('🔍');

        await m.reply(`🔍 جاري البحث عن فيديو:\n*${query}*`);

        const results = await searchTikTok(query);

        if (!results.length) {
            await m.react('❌');
            return m.reply(
                `❌ لم أجد فيديو باسم:\n*${query}*\n\n` +
                'جرب كتابة اسم مختلف أو أكثر تحديداً'
            );
        }

        const { buffer, item: selected } = await getFirstWorkingVideo(results);

        const botName = bot?.config?.info?.nameBot || 'SONG BOT';

        const caption =
            `╔══════════════════════╗\n` +
            `║  🎬 *تم العثور على الفيديو*\n` +
            `╠══════════════════════╣\n` +
            `║  📝 الاسم: ${selected.title || query}\n` +
            `║  👤 الحساب: ${selected.author || 'غير معروف'}\n` +
            `║  🤖 البوت: ${botName}\n` +
            `╚══════════════════════╝`;

        await conn.sendMessage(
            m.chat,
            {
                video: buffer,
                caption,
                mimetype: 'video/mp4',
                fileName: 'edit.mp4',
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 999,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: CHANNEL_JID,
                        newsletterName: CHANNEL_NAME,
                        serverMessageId: -1,
                    },
                    externalAdReply: {
                        title: `🎬 ${query}`,
                        body: CHANNEL_NAME,
                        sourceUrl: CHANNEL_URL,
                        mediaType: 1,
                        renderLargerThumbnail: false,
                    },
                },
            },
            { quoted: m }
        );

        await m.react('✅');
    } catch (error) {
        await m.react('❌');

        await m.reply(
            `❌ حصل خطأ أثناء جلب الفيديو\n\n` +
            `⚠️ ${error?.message || 'خطأ غير معروف'}`
        );
    }
};

handler.command = ['ايديت', 'edit'];
handler.usage = ['ايديت [اسم الفيديو]'];
handler.category = 'downloads';
handler.noSub = false;

export default handler;