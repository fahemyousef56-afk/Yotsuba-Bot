// 🕸 ملف: يوتيوب_تحميل.js - تحميل من يوتيوب - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import crypto from 'crypto';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';
const MAX_SIZE = 100 * 1024 * 1024; // 100 ميجا

const buildContext = (title = BOT_NAME) => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

// ─────────────── أدوات مساعدة ───────────────

const fetchJson = async (url, options = {}, timeout = 20000) => {
    const res = await fetch(url, {
        ...options,
        signal: AbortSignal.timeout(timeout),
        headers: { 'User-Agent': UA, Accept: 'application/json', ...(options.headers || {}) },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const body = await res.text();
    try {
        return JSON.parse(body);
    } catch {
        throw new Error('الرد مش JSON صالح');
    }
};

// استخراج ID الفيديو من أي شكل رابط يوتيوب
const getVideoId = (link) => {
    try {
        const u = new URL(link);
        const host = u.hostname.replace(/^www\./, '').replace(/^m\./, '').replace(/^music\./, '');

        if (host === 'youtu.be') return u.pathname.slice(1).slice(0, 11) || null;

        if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
            if (u.searchParams.get('v')) return u.searchParams.get('v').slice(0, 11);
            const m = u.pathname.match(/^\/(?:shorts|embed|live|v)\/([a-zA-Z0-9_-]{11})/);
            return m?.[1] || null;
        }
    } catch {}
    return null;
};

const safeName = (name, fallback = 'YouTube') =>
    String(name || fallback).replace(/[\\/:*?"<>|\n\r]/g, '').trim().slice(0, 60) || fallback;

// ===== SaveTube - MP3 / MP4 =====
class SaveTube {
    constructor() {
        this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
        this.headers = {
            'content-type': 'application/json',
            origin: 'https://yt.savetube.me',
            'user-agent': 'Mozilla/5.0 (Android 15; Mobile)',
        };
    }

    decrypt(enc) {
        const buf = Buffer.from(enc, 'base64');
        const key = Buffer.from(this.ky, 'hex');
        const iv = buf.subarray(0, 16);
        const data = buf.subarray(16);
        const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
        return JSON.parse(Buffer.concat([decipher.update(data), decipher.final()]).toString());
    }

    async getCdn() {
        try {
            const d = await fetchJson('https://media.savetube.vip/api/random-cdn', {}, 10000);
            return d.cdn || 'cdn1.savetube.vip';
        } catch {
            return 'cdn1.savetube.vip';
        }
    }

    async download(id, downloadType = 'audio', quality = '128') {
        const cdn = await this.getCdn();

        const info = await fetchJson(
            `https://${cdn}/v2/info`,
            {
                method: 'POST',
                headers: this.headers,
                body: JSON.stringify({ url: `https://www.youtube.com/watch?v=${id}` }),
            },
            20000
        );
        if (!info?.data) throw new Error('SaveTube: لا توجد بيانات');

        const dec = this.decrypt(info.data);

        const dl = await fetchJson(
            `https://${cdn}/download`,
            {
                method: 'POST',
                headers: this.headers,
                body: JSON.stringify({ id, downloadType, quality, key: dec.key }),
            },
            25000
        );
        if (!dl?.data?.downloadUrl) throw new Error('لا يوجد رابط تحميل');

        return { title: dec.title, url: dl.data.downloadUrl };
    }
}

// ===== cobalt (بديل) =====
const COBALT_APIS = ['https://cobalt.api.timelessnesses.me', 'https://api.cobalt.tools'];

async function viaCobalt(link, audio = false) {
    for (const api of COBALT_APIS) {
        try {
            const data = await fetchJson(
                `${api}/`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                    body: JSON.stringify(
                        audio
                            ? { url: link, downloadMode: 'audio', audioFormat: 'mp3', filenameStyle: 'basic' }
                            : { url: link, videoQuality: '720', filenameStyle: 'basic' }
                    ),
                },
                20000
            );
            const url = data?.url || data?.tunnel;
            if (url) return { url, title: data?.filename || 'YouTube' };
        } catch (e) {
            console.error(`cobalt (${api}) error:`, e?.message);
        }
    }
    return null;
}

// ===== تحميل صوت =====
async function getAudio(id, link) {
    const st = new SaveTube();

    try {
        return await st.download(id, 'audio', '128');
    } catch (e) {
        console.error('SaveTube audio error:', e?.message);
    }

    const res = await viaCobalt(link, true);
    if (res) return res;

    throw new Error('فشل تحميل الصوت، جرب بعدين');
}

// ===== تحميل فيديو =====
async function getVideo(id, link) {
    // API 1: SaveTube
    const st = new SaveTube();
    for (const quality of ['720', '480', '360']) {
        try {
            const res = await st.download(id, 'video', quality);
            if (res?.url) return res;
        } catch (e) {
            console.error(`SaveTube ${quality} error:`, e?.message);
        }
    }

    // API 2: y2mate
    try {
        const d1 = await fetchJson(
            'https://www.y2mate.com/mates/analyzeV2/ajax',
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    k_query: `https://www.youtube.com/watch?v=${id}`,
                    k_page: 'home',
                    hl: 'en',
                    q_auto: '0',
                }).toString(),
            },
            20000
        );
        const links = d1?.links?.mp4;
        const best = links?.['720p'] || links?.['480p'] || links?.['360p'];

        if (best?.k) {
            const d2 = await fetchJson(
                'https://www.y2mate.com/mates/convertV2/index',
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ vid: id, k: best.k }).toString(),
                },
                25000
            );
            if (d2?.dlink) return { url: d2.dlink, title: d1.title || 'YouTube Video' };
        }
    } catch (e) {
        console.error('y2mate error:', e?.message);
    }

    // API 3: cobalt
    const res = await viaCobalt(link, false);
    if (res) return res;

    throw new Error('فشل التحميل، جرب بعدين');
}

// تحميل الملف كـ buffer مع الفحوصات
async function downloadBuffer(url, timeout) {
    const res = await fetch(url, {
        signal: AbortSignal.timeout(timeout),
        headers: { 'User-Agent': UA },
    });
    if (!res.ok) throw new Error(`السيرفر رجع خطأ ${res.status}`);

    const length = Number(res.headers.get('content-length') || 0);
    if (length > MAX_SIZE) throw new Error('الملف كبير جداً');

    const buffer = Buffer.from(await res.arrayBuffer());
    if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');
    if (buffer.length > MAX_SIZE) throw new Error('الملف كبير جداً');

    return buffer;
}

// ─────────────── معالج الأوامر ───────────────

const handler = async (m, { conn, command, text, usedPrefix }) => {
    const prefix = usedPrefix || '.';

    const send = async (message) => {
        try {
            await conn.sendMessage(m.chat, { text: message, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(message);
        }
    };

    const input = (text || m.quoted?.text || m.quoted?.caption || '').trim();
    const link = input.match(/https?:\/\/[^\s]+/i)?.[0];

    if (!link) {
        return send(
            `${EMOJI}━━━[ *🎵 تحميل من يوتيوب* ]━━━${EMOJI}\n\n` +
            `📌 *الاستخدام:*\n` +
            `▸ ${prefix}يوت_اغنيه رابط يوتيوب - تحميل صوت\n` +
            `▸ ${prefix}يوتيوب رابط يوتيوب - تحميل فيديو\n\n` +
            `👤 *المطور:* ${DEVELOPER}\n` +
            `${EMOJI} *${BOT_NAME}*`
        );
    }

    const id = getVideoId(link);
    if (!id) {
        return send(`${EMOJI} *❌ الرابط ليس رابط يوتيوب صحيح!*`);
    }

    const cmd = String(command || '').toLowerCase();
    const isAudio = ['يوت_اغنيه', 'ytmp3'].includes(cmd);

    try {
        await m.react('⏳');
        await send(`${EMOJI} *⏳ جاري التحميل...*`);

        const res = isAudio ? await getAudio(id, link) : await getVideo(id, link);
        const title = res.title || (isAudio ? 'صوت' : 'فيديو');
        const name = safeName(title);

        let buffer;
        try {
            buffer = await downloadBuffer(res.url, isAudio ? 90000 : 120000);
        } catch (downloadError) {
            console.error('فشل تحميل الملف، هيتبعت الرابط:', downloadError?.message);

            await send(
                `${EMOJI} *تعذر إرسال الملف مباشرة*\n\n` +
                `📌 *العنوان:* ${title}\n` +
                `🔗 *رابط التحميل المباشر:*\n${res.url}\n\n` +
                `${EMOJI} *${BOT_NAME}*`
            );
            await m.react('✅');
            return;
        }

        if (isAudio) {
            await conn.sendMessage(
                m.chat,
                {
                    audio: buffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${name}.mp3`,
                    ptt: false,
                    contextInfo: buildContext(`🎵 ${name}`),
                },
                { quoted: m }
            );
        } else {
            await conn.sendMessage(
                m.chat,
                {
                    video: buffer,
                    mimetype: 'video/mp4',
                    fileName: `${name}.mp4`,
                    caption:
                        `${EMOJI}━━━[ *🎬 فيديو* ]━━━${EMOJI}\n\n` +
                        `📌 *العنوان:* ${title}\n\n` +
                        `👤 *المطور:* ${DEVELOPER}\n` +
                        `${EMOJI} *${BOT_NAME}*`,
                    contextInfo: buildContext(`🎬 ${name}`),
                },
                { quoted: m }
            );
        }

        await m.react('✅');
    } catch (e) {
        console.error(`${EMOJI} خطأ:`, e);
        await m.react('❌');
        await send(`${EMOJI} *❌ فشل التحميل:* ${String(e?.message || e).slice(0, 100)}`);
    }
};

handler.usage = ['يوت_اغنيه', 'يوتيوب'];
handler.category = 'downloads';
handler.command = ['يوت_اغنيه', 'يوتيوب', 'ytmp3', 'ytmp4'];

export default handler;