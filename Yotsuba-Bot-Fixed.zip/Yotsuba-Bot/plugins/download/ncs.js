/*
 * 🕸 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸
 * 📢 واتساب : https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z
 */

import axios from 'axios';
import * as cheerio from 'cheerio';

const BASE_URL = 'https://ncs.io';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const UA =
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';

const buildContext = (title = '🎵 NCS Music') => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

const fixUrl = (url) => {
    if (!url) return null;
    if (/^https?:\/\//i.test(url)) return url;
    if (url.startsWith('//')) return 'https:' + url;
    return BASE_URL + (url.startsWith('/') ? url : '/' + url);
};

const getPage = async (url) => {
    const res = await axios.get(url, {
        headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' },
        timeout: 30000,
    });
    return String(res.data || '');
};

// ─────────────── البحث ───────────────
async function searchNCS(query) {
    const html = await getPage(`${BASE_URL}/music?q=${encodeURIComponent(query)}`);
    const $ = cheerio.load(html);
    let results = [];

    // الطريقة الأولى: الـ selectors المعروفة
    $('.release-list .release, .release, .song, .track').each((_, el) => {
        const title = $(el).find('.release-title, .title, h3, h4').first().text().trim();
        const artist = $(el).find('.release-artist, .artist').first().text().trim();
        const href = $(el).find('a[href*="/"]').first().attr('href');
        const cover = $(el).find('img').first().attr('src') || '';

        if (title && href) {
            results.push({ title, artist, url: fixUrl(href), cover: fixUrl(cover) });
        }
    });

    // الطريقة البديلة: أي رابط أغنية
    if (!results.length) {
        $('a[href]').each((_, el) => {
            const href = $(el).attr('href') || '';
            const title = ($(el).attr('title') || $(el).text()).replace(/\s+/g, ' ').trim();
            if (/^\/[A-Za-z0-9\-_]{3,}$/.test(href) && title.length > 2 && title.length < 80) {
                results.push({ title, artist: '', url: fixUrl(href), cover: '' });
            }
        });
    }

    // شيل المكرر
    const seen = new Set();
    results = results.filter((r) => {
        if (!r.url || seen.has(r.url)) return false;
        seen.add(r.url);
        return true;
    });

    return results.slice(0, 5);
}

// ─────────────── استخراج رابط MP3 ───────────────
async function getMp3Link(songUrl) {
    const html = await getPage(songUrl);
    const $ = cheerio.load(html);

    const candidates = [
        $('a[href*=".mp3"]').first().attr('href'),
        $('[data-url*=".mp3"]').first().attr('data-url'),
        $('[data-preview*=".mp3"]').first().attr('data-preview'),
        $('audio source').first().attr('src'),
        $('audio').first().attr('src'),
        $('meta[property="og:audio"]').attr('content'),
        html.match(/https?:\/\/[^"'\s]+\.mp3[^"'\s]*/i)?.[0],
    ];

    const mp3 = candidates.find((c) => c);
    if (!mp3) throw new Error('ما لقيت رابط MP3');

    const title = $('meta[property="og:title"]').attr('content') || $('title').text().trim() || 'NCS';
    return { mp3: fixUrl(mp3), title };
}

// ─────────────── الهاندلر ───────────────
const handler = async (m, { conn, text, command, usedPrefix }) => {
    const prefix = usedPrefix || '.';
    const input = (text || '').trim();

    const send = async (message, title) => {
        try {
            await conn.sendMessage(
                m.chat,
                { text: message, contextInfo: buildContext(title) },
                { quoted: m }
            );
        } catch {
            await m.reply(message);
        }
    };

    if (!input) {
        return send(
            `*🎵 موسيقى NCS بدون حقوق*\n${'━'.repeat(30)}\n\n` +
            `*البحث:*\n${prefix}${command} Alan Walker\n\n` +
            `*التحميل المباشر:*\n${prefix}${command} dl [رابط_الأغنية]\n\n` +
            `> *${BOT_NAME}*`
        );
    }

    try {
        await m.react('⏳');

        const dlMatch = input.match(/^(dl|download|تحميل)\s+(.+)$/i);

        if (dlMatch) {
            // ───── تحميل مباشر ─────
            const songUrl = dlMatch[2].match(/https?:\/\/[^\s]+/i)?.[0];
            if (!songUrl) throw new Error('حط رابط الأغنية بعد dl');

            const { mp3, title } = await getMp3Link(songUrl);

            const audio = await axios.get(mp3, {
                responseType: 'arraybuffer',
                timeout: 120000,
                headers: { 'User-Agent': UA, Referer: BASE_URL + '/' },
                maxContentLength: 100 * 1024 * 1024,
            });

            const buffer = Buffer.from(audio.data);
            if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');

            const safeName = title.replace(/[\\/:*?"<>|]/g, '').slice(0, 60) || 'NCS';

            await conn.sendMessage(
                m.chat,
                {
                    audio: buffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${safeName}.mp3`,
                    ptt: false,
                    contextInfo: buildContext(`🎵 ${safeName}`),
                },
                { quoted: m }
            );
        } else {
            // ───── بحث ─────
            const results = await searchNCS(input);
            if (!results.length) throw new Error('ما لقيت نتائج');

            let reply = `*🎵 نتائج NCS: ${input}*\n${'━'.repeat(30)}\n\n`;
            results.forEach((r, i) => {
                reply += `*${i + 1}.* ${r.title}\n`;
                if (r.artist) reply += `👤 ${r.artist}\n`;
                reply += `🔗 ${r.url}\n\n`;
            });
            reply += `*للتحميل:* ${prefix}${command} dl [الرابط]\n\n> *${BOT_NAME}*`;

            await send(reply);
        }

        await m.react('✅');
    } catch (e) {
        console.error(e?.message || e);
        await m.react('❌');
        await m.reply(`*❌ فشل:* ${String(e?.message || e).slice(0, 100)}`);
    }
};

handler.usage = ['ncs'];
handler.command = ['ncs', 'ncsdl'];
handler.category = 'download';

export default handler;
