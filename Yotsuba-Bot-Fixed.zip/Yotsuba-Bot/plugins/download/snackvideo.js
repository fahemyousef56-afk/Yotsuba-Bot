/*
 * 🕸 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸
 * 📢 واتساب : https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z
 */

import axios from 'axios';

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const UA =
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';

const buildContext = (title = '🎬 Snack Video') => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

const isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);

// فحص الدومين (يدعم الروابط القصيرة)
const isSnackLink = (link) => {
    try {
        const host = new URL(link).hostname.replace(/^www\./, '').toLowerCase();
        return ['snackvideo.com', 'snack.video', 'sck.io', 'kwai.com'].some(
            (d) => host === d || host.endsWith('.' + d)
        );
    } catch {
        return false;
    }
};

// تنضيف الرابط من الرموز المشفرة
const cleanUrl = (u) =>
    String(u || '')
        .replace(/\\u002F/gi, '/')
        .replace(/\\u0026/gi, '&')
        .replace(/\\\//g, '/')
        .replace(/&amp;/g, '&')
        .trim();

// ─────────────── المصدر الأول: صفحة سناك فيديو نفسها ───────────────
async function fromSnackPage(link) {
    const res = await axios.get(link, {
        headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' },
        timeout: 30000,
        maxRedirects: 5,
    });
    const html = String(res.data || '');

    const patterns = [
        /<meta[^>]+property=["']og:video(?::secure_url|:url)?["'][^>]+content=["']([^"']+)["']/i,
        /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:video(?::secure_url|:url)?["']/i,
        /"contentUrl"\s*:\s*"([^"]+)"/i,
        /"srcNoMark"\s*:\s*"([^"]+)"/i,
        /"playUrl"\s*:\s*"([^"]+)"/i,
        /"videoUrl"\s*:\s*"([^"]+)"/i,
        /"photoUrl"\s*:\s*"([^"]+\.mp4[^"]*)"/i,
        /(https?:\\?\/\\?\/[^"'\s<>]+?\.mp4[^"'\s<>]*)/i,
    ];

    for (const re of patterns) {
        const found = cleanUrl(html.match(re)?.[1]);
        if (isHttp(found)) return found;
    }
    return null;
}

// ─────────────── المصدر الثاني (بديل): snapsave ───────────────
async function fromSnapsave(link) {
    const res = await axios.post(
        'https://snapsave.app/action.php',
        `url=${encodeURIComponent(link)}`,
        {
            headers: {
                'content-type': 'application/x-www-form-urlencoded',
                'User-Agent': UA,
                Referer: 'https://snapsave.app/',
            },
            timeout: 30000,
        }
    );

    const html = String(res.data || '');
    const found = cleanUrl(html.match(/href=["'](https?:\/\/[^"']+\.mp4[^"']*)["']/i)?.[1]);
    return isHttp(found) ? found : null;
}

async function getVideoUrl(link) {
    try {
        const url = await fromSnackPage(link);
        if (url) return url;
    } catch (e) {
        console.error('Snack page error:', e?.message);
    }

    try {
        const url = await fromSnapsave(link);
        if (url) return url;
    } catch (e) {
        console.error('Snapsave error:', e?.message);
    }

    throw new Error('ما قدرت أجيب رابط الفيديو، تأكد إن الفيديو عام ومش محذوف');
}

// إرسال: رابط مباشر ← buffer ← رابط نصي
async function sendVideo(conn, m, videoUrl, caption) {
    const content = { caption, mimetype: 'video/mp4', contextInfo: buildContext() };

    try {
        await conn.sendMessage(m.chat, { video: { url: videoUrl }, ...content }, { quoted: m });
        return;
    } catch (e) {
        console.error('فشل الإرسال بالرابط، هجرب buffer:', e?.message);
    }

    try {
        const res = await axios.get(videoUrl, {
            responseType: 'arraybuffer',
            timeout: 120000,
            headers: { 'User-Agent': UA },
            maxContentLength: 100 * 1024 * 1024,
        });
        const buffer = Buffer.from(res.data);
        if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');

        await conn.sendMessage(m.chat, { video: buffer, ...content }, { quoted: m });
        return;
    } catch (e) {
        console.error('فشل الإرسال بالـ buffer:', e?.message);
    }

    await conn.sendMessage(
        m.chat,
        { text: `${caption}\n\n🔗 *رابط التحميل المباشر:*\n${videoUrl}`, contextInfo: buildContext() },
        { quoted: m }
    );
}

// ─────────────── الهاندلر ───────────────
const handler = async (m, { conn, text, command, usedPrefix }) => {
    const prefix = usedPrefix || '.';
    const link = (text || m.quoted?.text || m.quoted?.caption || '').match(/https?:\/\/[^\s]+/i)?.[0];

    const send = async (message) => {
        try {
            await conn.sendMessage(m.chat, { text: message, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(message);
        }
    };

    if (!link) {
        return send(
            `*❌ حط رابط سناك فيديو بعد الأمر*\n\n` +
            `مثال:\n${prefix}${command || 'سناك'} https://www.snackvideo.com/...`
        );
    }

    if (!isSnackLink(link)) {
        return send('*❌ الرابط مش من سناك فيديو*');
    }

    try {
        await m.react('⏳');

        const videoUrl = await getVideoUrl(link);

        const caption =
            `✅ *تم التحميل من سناك فيديو*\n\n` +
            `> *${BOT_NAME}*`;

        await sendVideo(conn, m, videoUrl, caption);
        await m.react('✅');
    } catch (e) {
        console.error(e?.message || e);
        await m.react('❌');
        await m.reply(`*❌ فشل التحميل:* ${String(e?.message || e).slice(0, 100)}`);
    }
};

handler.usage = ['سناك'];
handler.command = ['سناك', 'snackvideo', 'snack'];
handler.category = 'download';

export default handler;
