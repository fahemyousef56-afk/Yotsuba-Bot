// 🍁 ملف: downloader.js - تحميل شامل - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import axios from 'axios';
import { getInstagram, getFacebook, getThreads, getTwitter, getYoutube } from '../../system/dl_providers.js';

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/dwRnNBxj/IMG-20261013-114123-968.jpg';

const UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';

const buildContext = () => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title: BOT_NAME,
        body: CHANNEL_NAME,
        thumbnailUrl: MAIN_IMAGE,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

// ─────────────── أدوات مساعدة ───────────────

const getHost = (link) => {
    try {
        return new URL(link).hostname.replace(/^www\./, '').replace(/^m\./, '').toLowerCase();
    } catch {
        return '';
    }
};

const hostIs = (host, ...domains) =>
    domains.some((d) => host === d || host.endsWith('.' + d));

const detectPlatform = (link) => {
    const host = getHost(link);
    if (hostIs(host, 'instagram.com')) return 'instagram';
    if (hostIs(host, 'youtube.com', 'youtu.be')) return 'youtube';
    if (hostIs(host, 'facebook.com', 'fb.watch', 'fb.com')) return 'facebook';
    if (hostIs(host, 'threads.net', 'threads.com')) return 'threads';
    if (hostIs(host, 'twitter.com', 'x.com')) return 'twitter';
    return null;
};

const PLATFORM_TITLES = {
    instagram: '📸 إنستغرام',
    youtube: '🎬 يوتيوب',
    facebook: '📘 فيسبوك',
    threads: '🧵 ثريدز',
    twitter: '🐦 تويتر / X',
};

const URL_KEYS = [
    'url', 'video', 'video_url', 'videoUrl', 'download_url', 'downloadUrl',
    'dl', 'hd', 'high', 'sd', 'download', 'media', 'image', 'play', 'src', 'link',
];

const isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);

// بيجمع كل روابط الميديا من أي شكل رد
function collectMedia(data, out = [], depth = 0) {
    if (!data || depth > 6) return out;

    if (isHttp(data)) {
        out.push(data);
        return out;
    }

    if (Array.isArray(data)) {
        for (const item of data) collectMedia(item, out, depth + 1);
        return out;
    }

    if (typeof data === 'object') {
        // لو فيه رابط مباشر في المفاتيح المعروفة ناخد أول واحد بس من الكائن
        for (const key of URL_KEYS) {
            if (isHttp(data[key])) {
                out.push(data[key]);
                return out;
            }
        }
        for (const key of [...URL_KEYS, 'data', 'result', 'results', 'items', 'medias', 'links']) {
            if (data[key] && typeof data[key] === 'object') {
                collectMedia(data[key], out, depth + 1);
            }
        }
    }
    return out;
}

const guessType = (link) => {
    const clean = link.split('?')[0].toLowerCase();
    if (/\.(jpg|jpeg|png|webp|gif)$/.test(clean)) return 'image';
    return 'video';
};

const unique = (arr) => [...new Set(arr)];

// ─────────────── مصادر التحميل ───────────────

const GETTERS = {
    instagram: getInstagram,
    facebook: getFacebook,
    threads: getThreads,
    twitter: getTwitter,
    youtube: getYoutube,
};

// كل منصة بتجرب أكتر من مصدر (انظر system/dl_providers.js)
async function fetchMedia(platform, link, Api) {
    const media = await GETTERS[platform](link, Api);
    const videos = media.filter((i) => i.type === 'video');
    return unique((videos.length ? videos : media).map((i) => i.url));
}

// إرسال ملف: رابط مباشر ← buffer ← رابط نصي
async function sendMedia(conn, chatId, m, mediaUrl, caption) {
    const type = guessType(mediaUrl);
    const base = { caption, contextInfo: buildContext() };
    if (type === 'video') base.mimetype = 'video/mp4';

    try {
        await conn.sendMessage(chatId, { [type]: { url: mediaUrl }, ...base }, { quoted: m });
        return;
    } catch (e) {
        console.error('فشل الإرسال بالرابط، هجرب buffer:', e?.message);
    }

    try {
        const res = await axios.get(mediaUrl, {
            responseType: 'arraybuffer',
            timeout: 90000,
            headers: { 'User-Agent': UA },
            maxContentLength: 100 * 1024 * 1024,
        });
        const buffer = Buffer.from(res.data);
        if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');

        await conn.sendMessage(chatId, { [type]: buffer, ...base }, { quoted: m });
        return;
    } catch (e) {
        console.error('فشل الإرسال بالـ buffer:', e?.message);
    }

    await conn.sendMessage(
        chatId,
        {
            text: `${caption}\n\n🔗 *رابط التحميل المباشر:*\n${mediaUrl}`,
            contextInfo: buildContext(),
        },
        { quoted: m }
    );
}

// ─────────────── الهاندلر ───────────────

const handler = async (m, { conn, text, command, usedPrefix, Api }) => {
    const chatId = m.chat;
    const prefix = usedPrefix || '.';

    // استخراج الرابط من النص أو من الرسالة المردود عليها
    const sourceText =
        text ||
        m.quoted?.text ||
        m.quoted?.caption ||
        m.quoted?.msg?.caption ||
        '';
    const link = sourceText.match(/https?:\/\/[^\s]+/i)?.[0];

    // ───── بدون رابط: رسالة الشرح ─────
    if (!link) {
        const bodyText = `${EMOJI}━━━[ *📥 تحميل شامل* ]━━━${EMOJI}

📌 *طريقة الاستخدام:*
▸ ${prefix}${command} رابط

📝 *الروابط المدعومة:*
▸ إنستغرام 📸
▸ فيسبوك 📘
▸ يوتيوب 🎬
▸ ثريدز 🧵
▸ تويتر / X 🐦

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;

        try {
            if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

            await conn.sendButton(chatId, {
                imageUrl: MAIN_IMAGE,
                bodyText,
                footerText: `${EMOJI} ${BOT_NAME}`,
                buttons: [
                    {
                        name: 'cta_url',
                        params: {
                            display_text: `${EMOJI} قناة البوت`,
                            url: CHANNEL_LINK,
                        },
                    },
                ],
                mentions: [m.sender],
                newsletter: {
                    name: CHANNEL_NAME,
                    jid: CHANNEL_JID,
                },
                interactiveConfig: { buttons_limits: 20 },
            }, m);
        } catch (e) {
            await conn.sendMessage(chatId, {
                image: { url: MAIN_IMAGE },
                caption: bodyText,
                contextInfo: buildContext(),
            }, { quoted: m }).catch(() =>
                conn.sendMessage(chatId, { text: bodyText, contextInfo: buildContext() }, { quoted: m })
            );
        }
        return;
    }

    // ───── تحديد المنصة ─────
    const platform = detectPlatform(link);

    if (!platform) {
        return conn.sendMessage(chatId, {
            text:
                `${EMOJI} ❌ *رابط غير مدعوم*\n\n` +
                `📌 *الروابط المدعومة:*\n▸ إنستغرام\n▸ فيسبوك\n▸ يوتيوب\n▸ ثريدز\n▸ تويتر/X`,
            contextInfo: buildContext(),
        }, { quoted: m });
    }

    try {
        await conn.sendMessage(chatId, { react: { text: '⏳', key: m.key } });

        const mediaList = await fetchMedia(platform, link, Api);
        if (!mediaList.length) {
            throw new Error('لا يمكن العثور على رابط التحميل، جرب رابط تاني أو حاول بعد شوية');
        }

        const caption = `${EMOJI}━━━[ *📥 تحميل* ]━━━${EMOJI}

${PLATFORM_TITLES[platform]}

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;

        // الألبومات: نبعت لحد 5 ملفات
        for (const mediaUrl of mediaList.slice(0, 5)) {
            await sendMedia(conn, chatId, m, mediaUrl, caption);
        }

        await conn.sendMessage(chatId, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error('❌ خطأ في التحميل:', err);

        await conn.sendMessage(chatId, { react: { text: '❌', key: m.key } });

        await conn.sendMessage(chatId, {
            text: `${EMOJI} ❌ *فشل التحميل*\n\n📌 *السبب:* ${String(err?.message || 'يرجى المحاولة مرة أخرى').slice(0, 150)}`,
            contextInfo: buildContext(),
        }, { quoted: m });
    }
};

handler.usage = ['تحميل'];
handler.command = ['تحميل', 'download', 'dl', 'تنزيل'];
handler.category = 'download';

export default handler;