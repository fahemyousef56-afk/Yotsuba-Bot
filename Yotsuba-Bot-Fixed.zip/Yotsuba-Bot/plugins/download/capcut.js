// 🍁 ملف: capcut.js - تحميل فيديو من كاب كت - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

import pkg from 'btch-downloader';
const { capcut } = pkg;

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const MAIN_IMAGE = 'https://i.ibb.co/WN8rVK4s/IMG-20261013-164235-604.jpg';

const URL_KEYS = ['video_url', 'videoUrl', 'video', 'url', 'download_url', 'downloadUrl', 'play', 'src'];

// بيدوّر على رابط الفيديو في أي شكل بترجعه المكتبة
function extractVideoUrl(data) {
    if (!data) return null;

    if (typeof data === 'string') {
        return /^https?:\/\//i.test(data) ? data : null;
    }

    if (Array.isArray(data)) {
        for (const item of data) {
            const found = extractVideoUrl(item);
            if (found) return found;
        }
        return null;
    }

    if (typeof data === 'object') {
        for (const key of URL_KEYS) {
            const found = extractVideoUrl(data[key]);
            if (found) return found;
        }
        for (const key of ['data', 'result', 'results']) {
            const found = extractVideoUrl(data[key]);
            if (found) return found;
        }
    }

    return null;
}

function extractTitle(data) {
    const d = Array.isArray(data?.data) ? data.data[0] : (data?.data || data?.result || data);
    return d?.title || d?.name || d?.description || 'فيديو كاب كت';
}

// السياق المشترك: القناة + البوت
const buildContext = (title = BOT_NAME) => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        thumbnailUrl: MAIN_IMAGE,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

const handler = async (m, { conn, text, command, usedPrefix }) => {
    const chatId = m.chat;
    const prefix = usedPrefix || '.';

    // ───── بدون رابط: رسالة الشرح ─────
    if (!text) {
        const bodyText = `${EMOJI}━━━[ *📥 تحميل كاب كت* ]━━━${EMOJI}

📌 *طريقة الاستخدام:*
▸ ${prefix}${command} رابط الفيديو

📝 *مثال:*
▸ ${prefix}${command} https://www.capcut.com/...

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;

        try {
            if (typeof conn.sendButton !== 'function') throw new Error('no sendButton');

            await conn.sendButton(chatId, {
                imageUrl: MAIN_IMAGE,
                bodyText,
                footerText: `${EMOJI} ${BOT_NAME}`,
                buttons: [
                    {
                        name: 'cta_url',
                        params: {
                            display_text: `${EMOJI} قناة البوت`,
                            url: CHANNEL_LINK,
                        },
                    },
                ],
                mentions: [m.sender],
                newsletter: {
                    name: CHANNEL_NAME,
                    jid: CHANNEL_JID,
                },
                interactiveConfig: { buttons_limits: 20 },
            }, m);
        } catch (e) {
            // بديل: صورة + كابشن + بيانات القناة
            try {
                await conn.sendMessage(chatId, {
                    image: { url: MAIN_IMAGE },
                    caption: bodyText,
                    contextInfo: buildContext(),
                }, { quoted: m });
            } catch {
                await m.reply(bodyText);
            }
        }
        return;
    }

    // ───── استخراج الرابط من الرسالة ─────
    const urlMatch = text.match(/https?:\/\/[^\s]+/i);
    const link = urlMatch?.[0];

    if (!link || !/capcut\.(com|link)/i.test(link)) {
        return m.reply(`${EMOJI} ❌ *الرابط مش من كاب كت*`);
    }

    try {
        await m.react('⏳');
        await m.reply(`${EMOJI} ⏳ *جاري تحميل الفيديو من كاب كت...*`);

        const result = await capcut(link);
        console.log(`${EMOJI} [capcut.js] رد المكتبة:`, JSON.stringify(result)?.slice(0, 300));

        const videoUrl = extractVideoUrl(result);
        if (!videoUrl) {
            throw new Error('ما قدرتش أجيب رابط الفيديو من الرد');
        }

        const caption = `${EMOJI}━━━[ *🎬 تحميل كاب كت* ]━━━${EMOJI}

📌 *العنوان:* ${extractTitle(result)}

👤 *المطور:* ${DEVELOPER}
${EMOJI} *${BOT_NAME}*`;

        // تحميل الفيديو كـ buffer، ولو فشل نبعته كرابط مباشر
        let videoContent;
        try {
            const fileRes = await fetch(videoUrl, {
                signal: AbortSignal.timeout(60000),
                headers: { 'User-Agent': 'Mozilla/5.0' },
            });
            if (!fileRes.ok) throw new Error(`السيرفر رجع خطأ ${fileRes.status}`);

            const buffer = Buffer.from(await fileRes.arrayBuffer());
            if (buffer.length < 1000) throw new Error('الفيديو فاضي أو تالف');

            videoContent = buffer;
        } catch (downloadError) {
            console.error(`${EMOJI} فشل تحميل الملف، هيتبعت كرابط:`, downloadError.message);
            videoContent = { url: videoUrl };
        }

        await conn.sendMessage(chatId, {
            video: videoContent,
            caption,
            mimetype: 'video/mp4',
            fileName: 'capcut.mp4',
            contextInfo: buildContext(),
        }, { quoted: m });

        await m.react('✅');

    } catch (e) {
        console.error(`${EMOJI} خطأ في تحميل كاب كت:`, e);
        await m.react('❌');
        await m.reply(`${EMOJI} ❌ *فشل التحميل:*\n📌 ${String(e?.message || e).slice(0, 150)}`);
    }
};

handler.usage = ['كاب_كت'];
handler.command = ['كاب_كت', 'capcut', 'كابكت'];
handler.category = 'downloads';

export default handler;