/*
 * 📱 تحميل تطبيقات APK من Aptoide (API رسمي مفتوح، بدون مفتاح)
 * الأمر: .تطبيق اسم_التطبيق   → يبحث ويبعت ملف الـ APK نفسه
 * قبل كده الأمر كان بيعرض روابط بحث بس ومش بيبعت ملف، وبيعتمد على سكرابينج apkpure
 * اللي بيتحجب (Cloudflare) فكان بيفشل.
 */

import axios from 'axios';

const CHANNEL_URL = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_JID = '120363433665479594@newsletter';
const UA = 'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36';

// أكبر حجم يتبعت كملف (بالبايت). فوق كده بنبعت رابط التحميل المباشر.
const MAX_SEND_BYTES = 300 * 1024 * 1024;

const ctx = (title) => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        sourceUrl: CHANNEL_URL,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

const fmtSize = (b) => {
    const n = Number(b) || 0;
    if (n >= 1024 ** 3) return (n / 1024 ** 3).toFixed(2) + ' GB';
    if (n >= 1024 ** 2) return (n / 1024 ** 2).toFixed(1) + ' MB';
    return (n / 1024).toFixed(0) + ' KB';
};

async function searchAptoide(query) {
    const res = await axios.get('https://ws75.aptoide.com/api/7/apps/search', {
        params: { query, limit: 5 },
        timeout: 30000,
        headers: { 'User-Agent': UA },
    });
    const list = res.data?.datalist?.list || [];
    const apps = list
        .map((a) => ({
            name: a.name,
            pkg: a.package,
            version: a.file?.vername || '',
            size: a.file?.filesize || a.size || 0,
            url: a.file?.path || a.file?.path_alt || '',
            icon: a.icon || '',
            updated: a.updated || '',
        }))
        .filter((a) => a.name && a.url);
    if (!apps.length) throw new Error('ما لقيت التطبيق ده، جرب اسم تاني (بالإنجليزي أفضل)');
    return apps;
}

const handler = async (m, { conn, text, command, usedPrefix }) => {
    const query = (text || '').trim();
    if (!query) {
        return m.reply(
            `*❌ اكتب اسم التطبيق بعد الأمر*\n\nمثال: ${usedPrefix || '.'}${command} WhatsApp`
        );
    }

    try {
        await m.react('🔍');
        const apps = await searchAptoide(query);
        const app = apps[0];

        const caption =
            `*📱 ${app.name}*\n` +
            `📦 ${app.pkg}\n` +
            (app.version ? `🔖 الإصدار: ${app.version}\n` : '') +
            `💾 الحجم: ${fmtSize(app.size)}\n` +
            (apps.length > 1
                ? `\n*نتائج تانية:*\n${apps.slice(1).map((a, i) => `${i + 2}. ${a.name} (${a.pkg})`).join('\n')}\n`
                : '') +
            `\n> *𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸*`;

        if (app.size && app.size > MAX_SEND_BYTES) {
            await conn.sendMessage(
                m.chat,
                {
                    text: `${caption}\n\n⚠️ الملف كبير على الإرسال المباشر، حمّله من هنا:\n${app.url}`,
                    contextInfo: ctx(`📱 ${app.name}`),
                },
                { quoted: m }
            );
            return m.react('✅');
        }

        await m.react('⏬');
        const fileName = `${app.name.replace(/[\\/:*?"<>|]/g, '')}.apk`;
        const docBase = {
            mimetype: 'application/vnd.android.package-archive',
            fileName,
            caption,
            contextInfo: ctx(`📱 ${app.name}`),
        };

        try {
            // 1) إرسال بالرابط مباشرة (بيتحمّل ستريم بدون ما ياكل رام)
            await conn.sendMessage(m.chat, { document: { url: app.url }, ...docBase }, { quoted: m });
        } catch (e1) {
            console.error('فشل إرسال APK بالرابط، هجرب buffer:', e1?.message);
            try {
                // 2) تحميل كـ buffer ثم إرسال
                const file = await axios.get(app.url, {
                    responseType: 'arraybuffer',
                    timeout: 180000,
                    maxContentLength: MAX_SEND_BYTES,
                    headers: { 'User-Agent': UA },
                });
                await conn.sendMessage(
                    m.chat,
                    { document: Buffer.from(file.data), ...docBase },
                    { quoted: m }
                );
            } catch (e2) {
                console.error('فشل إرسال APK بالـ buffer:', e2?.message);
                // 3) رابط التحميل نصاً
                await conn.sendMessage(
                    m.chat,
                    { text: `${caption}\n\n🔗 *رابط التحميل المباشر:*\n${app.url}`, contextInfo: ctx(`📱 ${app.name}`) },
                    { quoted: m }
                );
            }
        }

        await m.react('✅');
    } catch (e) {
        console.error(e?.message || e);
        await m.react('❌');
        await m.reply(`*❌ فشل:* ${String(e?.message || e).slice(0, 120)}`);
    }
};

handler.usage = ['تطبيق'];
handler.command = ['تطبيق', 'apk', 'apksearch'];
handler.category = 'download';

export default handler;
