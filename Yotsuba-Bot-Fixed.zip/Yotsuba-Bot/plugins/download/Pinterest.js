const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const buildContext = (title = '📌 Pinterest') => ({
  isForwarded: true,
  forwardingScore: 999,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
  externalAdReply: {
    title,
    body: CHANNEL_NAME,
    sourceUrl: CHANNEL_LINK,
    mediaType: 1,
    renderLargerThumbnail: false,
  },
});

const isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);

// بيطلع قائمة الصور من أي شكل رد
const extractImages = (res) => {
  const raw =
    (Array.isArray(res?.data) && res.data) ||
    (Array.isArray(res?.result) && res.result) ||
    (Array.isArray(res?.results) && res.results) ||
    (Array.isArray(res?.images) && res.images) ||
    (Array.isArray(res?.data?.images) && res.data.images) ||
    (Array.isArray(res?.data?.results) && res.data.results) ||
    (Array.isArray(res) && res) ||
    [];

  const seen = new Set();

  return raw
    .map((item) => (typeof item === 'string' ? { url: item } : item))
    .filter((item) => {
      const url = item?.url || item?.image;
      if (!isHttp(url) || seen.has(url)) return false;
      seen.add(url);
      item.url = url;
      return true;
    });
};

async function pinterestSearch(m, { conn, bot, Api, text, usedPrefix, command }) {
  const prefix = usedPrefix || '.';
  const query = (text || '').trim();

  const send = async (message) => {
    try {
      await conn.sendMessage(
        m.chat,
        { text: message, contextInfo: buildContext() },
        { quoted: m }
      );
    } catch {
      await m.reply(message);
    }
  };

  if (!query) {
    return send(
      `*🧸🕯 اكتب اسم البحث انجلش عشان يطلع لك الصور 🕯🧸*\n\nمثال:\n${prefix}${command || 'بين'} anime boy`
    );
  }

  try {
    await m.react('🔍');

    const api = bot?.Api || Api;
    if (typeof api?.search?.pinterestImages !== 'function') {
      throw new Error('خدمة بحث بينترست مش متاحة في البوت');
    }

    const res = await api.search.pinterestImages({ q: query });
    const images = extractImages(res);

    if (!images.length) {
      await m.react('⚠️');
      return send('*⚠️ لا توجد نتائج للبحث 🧸*');
    }

    // اختيار 10 صور عشوائية متتالية
    const start =
      images.length > 10 ? Math.floor(Math.random() * (images.length - 9)) : 0;
    const selectedImages = images.slice(start, start + 10);

    const cards = selectedImages.map((item, index) => {
      const title =
        item.title && item.title !== 'No title' ? item.title : `Image ~ ${index + 1}`;

      return {
        imageUrl: item.url,
        bodyText: `*${title}*`,
        footerText: item.owner ? `👤 ${item.owner} • Pinterest` : '📌 Pinterest Image',
        buttons: [
          {
            name: 'cta_url',
            params: {
              display_text: '🔗╎ رؤيـتـهـا',
              url: item.pinUrl || item.url,
            },
          },
          {
            name: 'cta_copy',
            params: {
              display_text: '📋╎ نـسـخ الـرابــط',
              copy_code: item.url,
            },
          },
        ],
      };
    });

    let carouselSent = false;

    if (typeof conn.sendCarousel === 'function') {
      try {
        await conn.sendCarousel(
          m.chat,
          {
            headerText: `📸 البحث الخاص بك → *[ ${query} ]*`,
            globalFooterText: 'Swipe to see more images →',
            cards,
            mentions: [m.sender],
            newsletter: {
              name: CHANNEL_NAME,
              jid: CHANNEL_JID,
            },
            contextInfo: buildContext(),
          },
          m
        );
        carouselSent = true;
      } catch (e) {
        console.error('فشل الكاروسيل، هبعت الصور عادي:', e?.message);
      }
    }

    // بديل: صور عادية (أول 5)
    if (!carouselSent) {
      for (const [i, item] of selectedImages.slice(0, 5).entries()) {
        const title =
          item.title && item.title !== 'No title' ? item.title : `Image ~ ${i + 1}`;

        try {
          await conn.sendMessage(
            m.chat,
            {
              image: { url: item.url },
              caption:
                `📸 *${query}*\n📌 ${title}` +
                (item.owner ? `\n👤 ${item.owner}` : '') +
                (item.pinUrl ? `\n🔗 ${item.pinUrl}` : ''),
              contextInfo: buildContext(),
            },
            { quoted: m }
          );
        } catch (e) {
          console.error('فشل إرسال صورة:', e?.message);
        }
      }
    }

    await m.react('✅');
  } catch (error) {
    console.error(error?.message || error);
    await m.react('❌');
    await m.reply(`❌ ${String(error?.message || error).slice(0, 150)}`);
  }
}

pinterestSearch.category = 'downloads';
pinterestSearch.usage = ['بينترست'];
pinterestSearch.command = ['بين', 'بينترست', 'pinterest'];

export default pinterestSearch;