/*
 * 🕸 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸
 * 📢 واتساب : https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z
 */

import axios from 'axios';
import * as cheerio from 'cheerio';

const BASE_URL = 'https://on4t.com';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const UA =
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';

const buildContext = (title = '⬇️ تحميل فيديو') => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

const isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);

const fixUrl = (url) => {
    if (!url) return null;
    if (isHttp(url)) return url;
    if (url.startsWith('//')) return 'https:' + url;
    return BASE_URL + (url.startsWith('/') ? url : '/' + url);
};

const URL_KEYS = ['url', 'video_file_url', 'video_url', 'videoUrl', 'video', 'link', 'download', 'download_url', 'src'];

// بيجمع كل روابط الفيديو من أي شكل رد (مع الجودة لو موجودة)
function collectVideos(data, out = [], depth = 0) {
    if (!data || depth > 6) return out;

    if (isHttp(data)) {
        out.push({ url: data, quality: '' });
        return out;
    }

    if (Array.isArray(data)) {
        for (const item of data) collectVideos(item, out, depth + 1);
        return out;
    }

    if (typeof data === 'object') {
        for (const key of URL_KEYS) {
            if (isHttp(data[key])) {
                out.push({
                    url: data[key],
                    quality: String(data.quality || data.resolution || data.label || ''),
                });
                return out;
            }
        }
        for (const key of ['data', 'result', 'results', 'videos', 'medias', 'links']) {
            if (data[key] && typeof data[key] === 'object') {
                collectVideos(data[key], out, depth + 1);
            }
        }
    }
    return out;
}

const qNum = (q) => parseInt(String(q).match(/\d+/)?.[0] || '0', 10);

async function downloadFromOn4t(link) {
    // الطريقة الأولى: POST
    try {
        const res = await axios.post(
            `${BASE_URL}/download`,
            { url: link },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': UA,
                    Referer: BASE_URL + '/',
                },
                timeout: 40000,
            }
        );
        const list = collectVideos(res.data);
        if (list.length) return list;
    } catch (e) {
        console.error('on4t POST error:', e?.message);
    }

    // الطريقة البديلة: قراءة صفحة الموقع
    const page = await axios.get(`${BASE_URL}/?url=${encodeURIComponent(link)}`, {
        headers: { 'User-Agent': UA },
        timeout: 30000,
    });
    const html = String(page.data || '');
    const $ = cheerio.load(html);
    const found = [];

    $('a[href*=".mp4"], a[download], video source, video, meta[property="og:video"]').each((_, el) => {
        const href =
            $(el).attr('href') || $(el).attr('src') || $(el).attr('content');
        const full = fixUrl(href);
        if (isHttp(full)) found.push({ url: full, quality: $(el).text().trim() });
    });

    const raw = html.match(/https?:\/\/[^"'\s\\]+\.mp4[^"'\s\\]*/gi) || [];
    for (const r of raw) found.push({ url: r, quality: '' });

    const seen = new Set();
    const unique = found.filter((f) => !seen.has(f.url) && seen.add(f.url));

    if (!unique.length) throw new Error('ما قدرت أجيب الفيديو من هذا الرابط');
    return unique;
}

// إرسال: رابط مباشر ← buffer ← رابط نصي
async function sendVideo(conn, m, videoUrl, caption) {
    const content = { caption, mimetype: 'video/mp4', contextInfo: buildContext() };

    try {
        await conn.sendMessage(m.chat, { video: { url: videoUrl }, ...content }, { quoted: m });
        return;
    } catch (e) {
        console.error('فشل الإرسال بالرابط، هجرب buffer:', e?.message);
    }

    try {
        const res = await axios.get(videoUrl, {
            responseType: 'arraybuffer',
            timeout: 120000,
            headers: { 'User-Agent': UA, Referer: BASE_URL + '/' },
            maxContentLength: 100 * 1024 * 1024,
        });
        const buffer = Buffer.from(res.data);
        if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');

        await conn.sendMessage(m.chat, { video: buffer, ...content }, { quoted: m });
        return;
    } catch (e) {
        console.error('فشل الإرسال بالـ buffer:', e?.message);
    }

    await conn.sendMessage(
        m.chat,
        { text: `${caption}\n\n🔗 *رابط التحميل المباشر:*\n${videoUrl}`, contextInfo: buildContext() },
        { quoted: m }
    );
}

const handler = async (m, { conn, text, command, usedPrefix }) => {
    const prefix = usedPrefix || '.';
    const link = (text || m.quoted?.text || m.quoted?.caption || '').match(/https?:\/\/[^\s]+/i)?.[0];

    const send = async (message) => {
        try {
            await conn.sendMessage(m.chat, { text: message, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(message);
        }
    };

    if (!link) {
        return send(
            `*⬇️ تحميل فيديو (متعدد المنصات)*\n${'━'.repeat(30)}\n\n` +
            `*الاستخدام:*\n${prefix}${command} [رابط]\n\n` +
            `*المنصات المدعومة:*\n` +
            `تيك توك | انستقرام | فيسبوك\n` +
            `تويتر | بينتريست | Vimeo\n` +
            `Dailymotion | وغيرها\n\n` +
            `> *${BOT_NAME}*`
        );
    }

    try {
        await m.react('⏳');

        const list = await downloadFromOn4t(link);

        // أعلى جودة متاحة
        list.sort((a, b) => qNum(b.quality) - qNum(a.quality));
        const best = list[0];
        if (!best?.url) throw new Error('ما لقيت رابط للتحميل');

        const caption =
            `✅ *تم التحميل*\n` +
            (best.quality ? `📺 *الجودة:* ${best.quality}\n` : '') +
            `🔗 ${link.slice(0, 60)}\n\n` +
            `> *${BOT_NAME}*`;

        await sendVideo(conn, m, best.url, caption);
        await m.react('✅');
    } catch (e) {
        console.error(e?.message || e);
        await m.react('❌');
        await m.reply(`*❌ فشل التحميل:* ${String(e?.message || e).slice(0, 100)}`);
    }
};

handler.usage = ['تحميل_فيديو'];
handler.command = ['تحميل_فيديو', 'on4t'];
handler.category = 'download';

export default handler;