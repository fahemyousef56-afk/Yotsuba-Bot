const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const buildContext = (title = '🔎 بحث جوجل') => ({
  isForwarded: true,
  forwardingScore: 999,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: -1,
  },
  externalAdReply: {
    title,
    body: CHANNEL_NAME,
    sourceUrl: CHANNEL_LINK,
    mediaType: 1,
    renderLargerThumbnail: false,
  },
});

const fetchJson = async (url) => {
  const response = await fetch(url, {
    signal: AbortSignal.timeout(10000),
    headers: { 'User-Agent': 'Mozilla/5.0', Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
};

const stripHtml = (str) =>
  String(str || '')
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&#039;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();

// المصدر الأول: ويكيبيديا (بيدعم العربي كويس)
const searchWikipedia = async (query) => {
  const lang = /[\u0600-\u06FF]/.test(query) ? 'ar' : 'en';

  const search = await fetchJson(
    `https://${lang}.wikipedia.org/w/api.php?action=query&list=search` +
      `&srsearch=${encodeURIComponent(query)}&srlimit=1&format=json&origin=*`
  );

  const first = search?.query?.search?.[0];
  if (!first) return null;

  const summary = await fetchJson(
    `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(first.title)}`
  );

  const extract = summary?.extract?.trim();
  if (!extract) return null;

  return {
    title: summary.title || first.title,
    text: extract.length > 800 ? extract.slice(0, 800) + '...' : extract,
    url: summary?.content_urls?.desktop?.page || null,
  };
};

// المصدر الثاني: DuckDuckGo
const searchDuckDuckGo = async (query) => {
  const data = await fetchJson(
    `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
  );

  const firstTopic = data.RelatedTopics?.find((t) => t.Text) || data.RelatedTopics?.[0]?.Topics?.[0];
  const text = data.AbstractText || data.Answer || firstTopic?.Text;
  if (!text) return null;

  return {
    title: data.Heading || query,
    text: stripHtml(text),
    url: data.AbstractURL || firstTopic?.FirstURL || null,
  };
};

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const query = (text || '').trim();
  const prefix = usedPrefix || '.';

  if (!query) {
    return m.reply(`🔎 اكتب كلمة البحث بعد الأمر\nمثال: ${prefix}${command || 'جوجل'} أخبار التقنية`);
  }

  const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;

  const send = async (message) => {
    try {
      await conn.sendMessage(
        m.chat,
        { text: message, contextInfo: buildContext() },
        { quoted: m }
      );
    } catch {
      await m.reply(message);
    }
  };

  try {
    await m.react('🔍');

    let result = null;

    try {
      result = await searchWikipedia(query);
    } catch (e) {
      console.error('Wikipedia error:', e?.message);
    }

    if (!result) {
      try {
        result = await searchDuckDuckGo(query);
      } catch (e) {
        console.error('DuckDuckGo error:', e?.message);
      }
    }

    if (result) {
      await send(
        `🔎 *نتيجة البحث عن:* ${query}\n\n` +
          `📌 *${result.title}*\n${result.text}\n\n` +
          (result.url ? `📖 *المصدر:* ${result.url}\n` : '') +
          `🌐 *نتائج جوجل:* ${googleUrl}`
      );
      await m.react('✅');
    } else {
      await send(`🔎 لم أجد ملخصاً سريعاً، افتح نتائج Google:\n${googleUrl}`);
      await m.react('⚠️');
    }
  } catch (e) {
    console.error(e?.message || e);
    await m.react('❌');
    await send(`🔎 تعذر جلب الملخص، افتح نتائج Google:\n${googleUrl}`);
  }
};

handler.command = ['جوجل', 'google'];
handler.usage = ['جوجل كلمة البحث'];
handler.category = 'downloads';

export default handler;