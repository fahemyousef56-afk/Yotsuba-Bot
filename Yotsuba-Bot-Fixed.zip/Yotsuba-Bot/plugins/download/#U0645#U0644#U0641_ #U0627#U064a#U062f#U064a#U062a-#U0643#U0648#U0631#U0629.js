// 🕸 ملف: ايديت-كورة.js - فيديوهات إديت كرة القدم - 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸

const EMOJI = '🕸';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';
const MAX_TRIES = 8;

const buildContext = (title = '⚽ إديت كورة') => ({
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: -1,
    },
    externalAdReply: {
        title,
        body: CHANNEL_NAME,
        sourceUrl: CHANNEL_LINK,
        mediaType: 1,
        renderLargerThumbnail: false,
    },
});

import { searchEditVideos, shuffle } from '../../system/edit_videos.js';

// ────────────────[مصفوفة الفيديوهات]────────────────
const VIDEOS = [...new Set([
    'https://telegra.ph/file/5fb7c13a4d93917f97ff3.mp4',
    'https://telegra.ph/file/2a4e007bec39cc66385b0.mp4',
    'https://telegra.ph/file/a22d5d23a85c4d7b2cdac.mp4',
    'https://telegra.ph/file/148dcadb72c631e0a9d1c.mp4',
    'https://telegra.ph/file/6699964c4f9486bafac22.mp4',
    'https://telegra.ph/file/aec768d540e249ceb0c5b.mp4',
    'https://telegra.ph/file/b2f92a40a7b869896d360.mp4',
    'https://telegra.ph/file/cd611bb1e76ceac182de8.mp4',
    'https://telegra.ph/file/0c4046c6477431bbed40d.mp4',
    'https://telegra.ph/file/d84e53e96fb44ec4cbd23.mp4',
    'https://telegra.ph/file/1286e1bf83c9901308cd8.mp4',
])];

// آخر فيديو اتبعت في كل محادثة (لتجنب التكرار)
const lastSent = new Map();

const pickRandom = (chatId, exclude = new Set()) => {
    const pool = VIDEOS.filter((v) => v !== lastSent.get(chatId) && !exclude.has(v));
    const list = pool.length ? pool : VIDEOS.filter((v) => !exclude.has(v));
    return list.length ? list[Math.floor(Math.random() * list.length)] : null;
};

const downloadBuffer = async (url) => {
    const res = await fetch(url, {
        signal: AbortSignal.timeout(60000),
        headers: { 'User-Agent': UA },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const buffer = Buffer.from(await res.arrayBuffer());
    if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');
    return buffer;
};

// ────────────────[الأمر الرئيسي]────────────────
const handler = async (m, { conn, command, usedPrefix }) => {
    const chatId = m.chat;
    const prefix = usedPrefix || '.';

    const send = async (text) => {
        try {
            await conn.sendMessage(chatId, { text, contextInfo: buildContext() }, { quoted: m });
        } catch {
            await m.reply(text);
        }
    };

    try {
        await m.react('⚽').catch(() => {});

        const caption =
            `${EMOJI}━━━━━━━━━━━━━━━━${EMOJI}\n` +
            `*⚽ فِيدِيُو إِدِيت كُرَةِ الْقَدَمِ*\n` +
            `${EMOJI}━━━━━━━━━━━━━━━━${EMOJI}\n\n` +
            `⚡ *استمتع بالمشاهدة!*\n\n` +
            `📌 *لفيديو آخر:* ${prefix}${command || 'اديت-كورة'}\n` +
            `👤 *المطور:* ${DEVELOPER}\n` +
            `${EMOJI} *${BOT_NAME}*`;

        const tried = new Set();
        let sent = false;

        // فيديوهات حديثة من البحث أولاً، ثم القائمة القديمة كاحتياطي
        const queue = [...(await searchEditVideos('football edit skills')), ...shuffle(VIDEOS)];

        for (let i = 0; i < MAX_TRIES && !sent && queue.length; i++) {
            const videoUrl = queue.shift();
            if (!videoUrl) break;
            if (tried.has(videoUrl)) continue;
            tried.add(videoUrl);

            const content = { caption, mimetype: 'video/mp4', contextInfo: buildContext() };

            // 1) إرسال بالرابط مباشرة
            try {
                await conn.sendMessage(chatId, { video: { url: videoUrl }, ...content }, { quoted: m });
                sent = true;
            } catch (e1) {
                console.error(`${EMOJI} فشل الإرسال بالرابط:`, e1?.message);

                // 2) إرسال كـ buffer
                try {
                    const buffer = await downloadBuffer(videoUrl);
                    await conn.sendMessage(chatId, { video: buffer, ...content }, { quoted: m });
                    sent = true;
                } catch (e2) {
                    console.error(`${EMOJI} فشل الإرسال بالـ buffer، هجرب فيديو تاني:`, e2?.message);
                }
            }

            if (sent) lastSent.set(chatId, videoUrl);
        }

        if (!sent) {
            throw new Error('الفيديوهات مش متاحة دلوقتي، جرب بعد شوية');
        }

        await m.react('✅').catch(() => {});
    } catch (error) {
        console.error(`${EMOJI} خطأ في إرسال فيديو الإديت:`, error);
        await m.react('❌').catch(() => {});
        await send(
            `${EMOJI} ❌ *حدث خطأ في إرسال الفيديو*\n` +
            `📌 ${String(error?.message || 'يرجى المحاولة مرة أخرى').slice(0, 150)}`
        );
    }
};

// ────────────────[إعدادات الأمر]────────────────
handler.usage = ['اديت-كورة'];
handler.category = 'media';
handler.command = ['اديت-كورة', 'editfoot', 'اديت-كوره', 'اديت-فوت', 'كورة'];
handler.description = '⚽ فيديو إديت كرة قدم عشوائي';

export default handler;