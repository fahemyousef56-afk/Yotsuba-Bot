/*
 * 🕸 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸
 * 📢 واتساب : https://whatsapp.com/channel/0029Vb8xTot1t90ks8pCah1O
 * 📨 تيليجرام : https://t.me/+-ZIIcYxN18w4ZGM8
 */

import { Sticker } from 'wa-sticker-formatter';

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const handler = async (m, { conn }) => {
    const q = m.quoted ? m.quoted : m;
    const msg = q.msg || q;
    const mime = msg.mimetype || q.mimetype || '';

    if (!mime.includes('video') && !mime.includes('gif')) {
        return send(conn, m, '*❌ رد على فيديو أو GIF عشان أحوله لملصق متحرك*');
    }

    // seconds ممكن تيجي كرقم أو كنص حسب الـ base
    const مدة = Number(msg.seconds || q.seconds || 0);
    if (مدة > 10) return send(conn, m, '*❌ الفيديو يجب أن يكون أقل من 10 ثواني*');

    await m.react?.('⏳');
    try {
        const buffer = await q.download();
        if (!buffer?.length) throw new Error('تعذر تحميل الفيديو');

        const sticker = await new Sticker(buffer, {
            pack: BOT_NAME,
            author: 'Yotsuba',
            type: 'full',
            quality: 50
        }).toBuffer();

        await conn.sendMessage(m.chat, { sticker, contextInfo: channelInfo }, { quoted: m });
        await m.react?.('✅');
    } catch (e) {
        console.error('Sticker error:', e);
        await m.react?.('❌');
        await send(conn, m, `*❌ فشل التحويل:* ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ['ملصق_متحرك'];
handler.command = ['ملصق_متحرك', 'gifsticker', 'gif_sticker', 'ملصق-متحرك'];
handler.category = 'sticker';

export default handler;