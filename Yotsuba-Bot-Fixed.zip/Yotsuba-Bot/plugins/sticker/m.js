// 🕸 plugins/stickers-pack.js - حزمة ملصقات Pinterest 📦

import fetch from 'node-fetch'
import { writeFile, readFile, unlink } from 'fs/promises'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { tmpdir } from 'os'
import path from 'path'
import crypto from 'crypto'
import https from 'https'
import axios from 'axios'

const execFileAsync = promisify(execFile)

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸'
const EMOJI = '🕸'
const UA_DESKTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
const UA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'

const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
}

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m })

const log = (...a) => console.log(`${EMOJI} [stickers-pack]`, ...a)

// ────────────────[Pinterest]────────────────
const PINTEREST_BASE = 'https://www.pinterest.com'
const PINTEREST_SEARCH_PATH = '/resource/BaseSearchResource/get/'
const PINTEREST_HEADERS = {
  accept: 'application/json, text/javascript, */*, q=0.01',
  referer: 'https://www.pinterest.com/',
  'user-agent': UA_DESKTOP,
  'x-app-version': 'a9522f',
  'x-pinterest-appstate': 'active',
  'x-pinterest-pws-handler': 'www/[username]/[slug].js',
  'x-requested-with': 'XMLHttpRequest'
}

async function getPinterestCookies() {
  try {
    const res = await axios.get(PINTEREST_BASE, {
      timeout: 15000,
      headers: { 'user-agent': UA_DESKTOP, accept: 'text/html,*/*' }
    })
    const setCookies = res.headers['set-cookie']
    if (!setCookies?.length) { log('Pinterest: مفيش cookies راجعة'); return null }
    return setCookies.map(c => c.split(';')[0].trim()).join('; ')
  } catch (e) {
    log('Pinterest cookies فشلت:', e?.response?.status || e.message)
    return null
  }
}

async function searchPinterestDirect(query, needed) {
  const images = { static: [], animated: [] }
  const cookies = await getPinterestCookies()
  if (!cookies) return images

  let bookmarks = ['']
  let attempts = 0

  while (images.static.length + images.animated.length < needed && bookmarks.length && attempts < 10) {
    attempts++
    try {
      const params = {
        source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
        data: JSON.stringify({
          options: { isPrefetch: false, query, scope: 'pins', bookmarks, page_size: 50 },
          context: {}
        }),
        _: Date.now()
      }

      const { data } = await axios.get(`${PINTEREST_BASE}${PINTEREST_SEARCH_PATH}`, {
        headers: { ...PINTEREST_HEADERS, cookie: cookies },
        params,
        timeout: 15000
      })

      const results = data?.resource_response?.data?.results?.filter(v => v?.images?.orig?.url) || []
      if (!results.length) break

      for (const r of results) {
        const url = r.images.orig.url
        if (url.endsWith('.gif')) images.animated.push(url)
        else images.static.push(url)
        if (images.static.length + images.animated.length >= needed) break
      }

      const next = data?.resource_response?.bookmark
      if (!next || next === '-end-') break
      bookmarks = [next]
    } catch (e) {
      log('Pinterest search فشل:', e?.response?.status || e.message)
      break
    }
  }
  return images
}

// بدائل لو Pinterest رفض الطلب
async function searchPinterestApis(query) {
  const apis = [
    `https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(query)}`,
    `https://api.doude.pw/api/pinterest?q=${encodeURIComponent(query)}`
  ]
  for (const api of apis) {
    try {
      const { data } = await axios.get(api, { timeout: 15000, headers: { 'user-agent': UA } })
      const list = data?.data || data?.result || data?.results || []
      if (!Array.isArray(list)) continue
      const urls = list
        .map(v => (typeof v === 'string' ? v : v?.image || v?.url || v?.images_url || v?.src))
        .filter(v => typeof v === 'string' && /^https?:\/\//i.test(v))
      if (urls.length) return urls
    } catch (e) {
      log(`بديل فشل ${new URL(api).hostname}:`, e?.response?.status || e.message)
    }
  }
  return []
}

async function searchPinterest(query, needed = 100) {
  let images = await searchPinterestDirect(query, needed)

  if (!images.static.length && !images.animated.length) {
    log('Pinterest المباشر ما رجّعش حاجة، بجرب البدائل...')
    const urls = await searchPinterestApis(query)
    for (const u of urls) {
      if (/\.gif(\?|$)/i.test(u)) images.animated.push(u)
      else images.static.push(u)
    }
  }

  return {
    static: [...new Set(images.static)].slice(0, needed),
    animated: [...new Set(images.animated)].slice(0, needed)
  }
}

// ────────────────[Sharp / تحويل الصور]────────────────
async function getSharp() {
  try {
    const mod = await import('sharp')
    return mod.default
  } catch {
    throw new Error('مكتبة sharp غير مثبتة، نزّلها بـ: npm i sharp')
  }
}

async function makeTrayWebp(buffer) {
  const sharp = await getSharp()
  return sharp(buffer, { animated: false }).resize(252, 252, { fit: 'cover' }).webp().toBuffer()
}

async function makeBlankTrayWebp() {
  const sharp = await getSharp()
  return sharp({ create: { width: 252, height: 252, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } }).webp().toBuffer()
}

async function makeThumbnailJpeg(buffer) {
  const sharp = await getSharp()
  return sharp(buffer).resize(252, 252, { fit: 'cover' }).jpeg().toBuffer()
}

// ملصق ثابت
async function makeWebp(buffer) {
  const sharp = await getSharp()
  const out = await sharp(buffer)
    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 80 })
    .toBuffer()
  return { buffer: out, isAnimated: false }
}

// ملصق متحرك (ffmpeg)
async function makeAnimatedWebp(buffer) {
  const id = crypto.randomBytes(6).toString('hex')
  const inputPath = path.join(tmpdir(), `pk_a_${id}.gif`)
  const outputPath = path.join(tmpdir(), `pk_a_${id}.webp`)
  try {
    await writeFile(inputPath, buffer)
    await execFileAsync('ffmpeg', [
      '-y', '-i', inputPath,
      '-vf', 'fps=12,scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000',
      '-c:v', 'libwebp', '-loop', '0', '-lossless', '0', '-q:v', '60',
      '-preset', 'default', '-an', '-t', '6',
      outputPath
    ])
    const result = await readFile(outputPath)
    if (result.length > 1024 * 1024) throw new Error('الملصق المتحرك كبير (أكتر من 1MB)')
    return { buffer: result, isAnimated: true }
  } finally {
    await unlink(inputPath).catch(() => {})
    await unlink(outputPath).catch(() => {})
  }
}

// ────────────────[الرفع وإرسال الحزمة]────────────────
const sha256 = (buffer) => crypto.createHash('sha256').update(buffer).digest()

const toB64Url = (buffer) =>
  Buffer.from(buffer).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')

async function uploadToServer(conn, buffer, { hkdf, mediaPath, mediaKey = crypto.randomBytes(32) }) {
  const expanded = Buffer.from(crypto.hkdfSync('sha256', mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112))
  const iv = expanded.subarray(0, 16)
  const cipherKey = expanded.subarray(16, 48)
  const macKey = expanded.subarray(48, 80)
  const cipher = crypto.createCipheriv('aes-256-cbc', cipherKey, iv)
  const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()])
  const mac = crypto.createHmac('sha256', macKey).update(iv).update(encrypted).digest().subarray(0, 10)
  const encBuffer = Buffer.concat([encrypted, mac])
  const fileSha256 = sha256(buffer)
  const fileEncSha256 = sha256(encBuffer)

  if (typeof conn.query !== 'function') throw new Error('conn.query مش موجودة في الـ base ده')

  const iq = await conn.query({
    tag: 'iq',
    attrs: { id: conn.generateMessageTag?.() ?? Date.now().toString(), to: 's.whatsapp.net', type: 'set', xmlns: 'w:m' },
    content: [{ tag: 'media_conn', attrs: {} }]
  })

  const mediaConn = iq.content?.find(v => v.tag === 'media_conn')
  if (!mediaConn) throw new Error('media_conn غير موجود')
  const auth = mediaConn.attrs?.auth
  if (!auth) throw new Error('auth غير موجود')

  const hosts = (mediaConn.content || []).filter(v => v.tag === 'host').map(v => v.attrs?.hostname).filter(Boolean)
  if (!hosts.length) throw new Error('لا يوجد host للرفع')

  const token = encodeURIComponent(toB64Url(fileEncSha256))

  let lastError
  for (const host of hosts) {
    try {
      const json = await new Promise((resolve, reject) => {
        const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`)
        const req = https.request({
          hostname: url.hostname, port: 443, path: url.pathname + url.search, method: 'POST',
          headers: {
            Origin: 'https://web.whatsapp.com',
            Referer: 'https://web.whatsapp.com/',
            'Content-Type': 'application/octet-stream',
            'Content-Length': encBuffer.length
          },
          timeout: 60000
        }, (res) => {
          let body = ''
          res.on('data', c => body += c)
          res.on('end', () => {
            if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error(`فشل الرفع ${res.statusCode}`))
            try { resolve(JSON.parse(body)) } catch { reject(new Error('رد غير JSON')) }
          })
        })
        req.on('timeout', () => req.destroy(new Error('انتهت مهلة الرفع')))
        req.on('error', reject)
        req.write(encBuffer)
        req.end()
      })
      const directPath = json.direct_path ?? json.directPath ?? json.url ?? json.path
      if (!directPath) throw new Error('directPath غير موجود')
      return { mediaKey, fileLength: buffer.length, fileSha256, fileEncSha256, directPath, ...json }
    } catch (e) {
      lastError = e
      log(`رفع فشل على ${host}:`, e.message)
    }
  }
  throw lastError ?? new Error('جميع محاولات الرفع فشلت')
}

async function sendStickerPack(conn, m, pack, query) {
  const JSZip = (await import('jszip')).default
  const zip = new JSZip()
  const stickersMetadata = []

  for (const item of pack) {
    const fileName = `${toB64Url(sha256(item.buffer))}.webp`
    zip.file(fileName, item.buffer)
    stickersMetadata.push({
      fileName,
      isAnimated: item.isAnimated,
      emojis: [EMOJI],
      accessibilityLabel: '',
      isLottie: false,
      mimetype: 'image/webp'
    })
  }

  const trayIconFileName = 'tray_icon.webp'
  const traySource = pack.find(v => !v.isAnimated)?.buffer || pack[0]?.buffer
  const trayBuffer = traySource ? await makeTrayWebp(traySource) : await makeBlankTrayWebp()
  zip.file(trayIconFileName, trayBuffer)

  const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'STORE' })

  const packUpload = await uploadToServer(conn, archive, { hkdf: 'WhatsApp Sticker Pack Keys', mediaPath: '/mms/sticker-pack' })
  const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer)
  const thumbUpload = await uploadToServer(conn, thumbnailBuffer, {
    hkdf: 'WhatsApp Sticker Pack Thumbnail Keys',
    mediaPath: '/mms/thumbnail-sticker-pack',
    mediaKey: packUpload.mediaKey
  })

  // relayMessage ما بيدعمش { quoted } فبنعمل الـ quote يدوي
  const contextInfo = {
    ...channelInfo,
    ...(m.key?.id && m.message ? {
      stanzaId: m.key.id,
      participant: m.sender,
      quotedMessage: m.message
    } : {})
  }

  await conn.relayMessage(m.chat, {
    messageContextInfo: { messageSecret: crypto.randomBytes(32) },
    stickerPackMessage: {
      stickerPackId: 'Pack_' + crypto.randomBytes(8).toString('hex'),
      name: BOT_NAME,
      publisher: BOT_NAME,
      packDescription: `${EMOJI} ${BOT_NAME} | ${query}`,
      stickers: stickersMetadata,
      fileLength: packUpload.fileLength,
      fileSha256: packUpload.fileSha256,
      fileEncSha256: packUpload.fileEncSha256,
      mediaKey: packUpload.mediaKey,
      directPath: packUpload.directPath,
      mediaKeyTimestamp: Math.floor(Date.now() / 1000),
      stickerPackSize: packUpload.fileLength,
      stickerPackOrigin: 2,
      trayIconFileName,
      thumbnailDirectPath: thumbUpload.directPath,
      thumbnailSha256: thumbUpload.fileSha256,
      thumbnailEncSha256: thumbUpload.fileEncSha256,
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: thumbUpload.fileSha256.toString('base64'),
      contextInfo
    }
  }, {})
}

// بديل: لو الحزمة فشلت نبعت الملصقات واحد واحد
async function sendStickersOneByOne(conn, m, pack) {
  let sent = 0
  for (const item of pack) {
    try {
      await conn.sendMessage(m.chat, { sticker: item.buffer, contextInfo: channelInfo }, { quoted: m })
      sent++
      await new Promise(r => setTimeout(r, 700))
    } catch (e) {
      log('إرسال ملصق فشل:', e.message)
    }
  }
  return sent
}

// ────────────────[تحميل وتحويل على دفعات]────────────────
async function downloadAndConvert(url, animated) {
  const res = await fetch(url, {
    headers: { 'User-Agent': UA },
    signal: AbortSignal.timeout(animated ? 15000 : 10000)
  })
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  const buffer = Buffer.from(await res.arrayBuffer())
  return animated ? makeAnimatedWebp(buffer) : makeWebp(buffer)
}

async function processBatch(urls, animated, limit, pack) {
  const BATCH = 4
  for (let i = 0; i < urls.length && pack.length < limit; i += BATCH) {
    const chunk = urls.slice(i, i + BATCH)
    const results = await Promise.allSettled(chunk.map(u => downloadAndConvert(u, animated)))
    for (const r of results) {
      if (r.status === 'fulfilled') {
        if (pack.length < limit) pack.push(r.value)
      } else {
        log('تحويل فشل:', r.reason?.message)
      }
    }
  }
}

// ────────────────[الأمر الرئيسي]────────────────
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return send(conn, m, `${EMOJI} *${usedPrefix + command} <بحث> <عدد>*\n${EMOJI} مثال: ${usedPrefix + command} anime 10`)
  }

  let query = text.trim()
  let count = 10
  const parts = query.split(/\s+/)
  const lastPart = parts[parts.length - 1]
  if (parts.length > 1 && /^\d+$/.test(lastPart)) {
    count = Math.min(100, Math.max(1, parseInt(lastPart)))
    query = parts.slice(0, -1).join(' ')
  }

  const statusMsg = await send(conn, m, `${EMOJI} جاري البحث عن "${query}" وتجهيز الحزمة...`)

  const cleanStatus = async () => {
    try { if (statusMsg?.key) await conn.sendMessage(m.chat, { delete: statusMsg.key }) } catch {}
  }

  try {
    const images = await searchPinterest(query, count)

    if (!images.static.length && !images.animated.length) {
      await cleanStatus()
      return send(conn, m, `${EMOJI} ❌ لا توجد نتائج لـ "${query}"\n(شوف اللوج لمعرفة السبب)`)
    }

    const pack = []
    await processBatch(images.static, false, count, pack)
    await processBatch(images.animated, true, count, pack)

    if (!pack.length) {
      await cleanStatus()
      return send(conn, m, `${EMOJI} ❌ تعذر معالجة أي ملصق\n(تأكد من sharp و ffmpeg وشوف اللوج)`)
    }

    try {
      await sendStickerPack(conn, m, pack, query)
    } catch (e) {
      log('إرسال الحزمة فشل، هبعت الملصقات واحد واحد:', e?.stack || e.message)
      await send(conn, m, `${EMOJI} ⚠️ تعذر إرسال الحزمة (${String(e.message).slice(0, 80)})\nهبعتلك الملصقات واحد واحد...`)
      const sent = await sendStickersOneByOne(conn, m, pack)
      if (!sent) throw new Error('فشل إرسال الملصقات')
    }

    await cleanStatus()
  } catch (e) {
    console.error('stickers-pack error:', e)
    await cleanStatus()
    await send(conn, m, `${EMOJI} ❌ خطأ: ${String(e.message || e).slice(0, 150)}`)
  }
}

handler.command = ['ملصقات', 'حزمة', 'باكج', 'stickerpack', 'pack']
handler.help = ['ملصقات [بحث] [عدد]']
handler.tags = ['sticker']
handler.category = 'sticker'
handler.noSub = false

export default handler