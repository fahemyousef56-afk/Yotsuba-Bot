import { addExif } from '../lib/sticker.js'

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';

const channelInfo = {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363433665479594@newsletter',
        newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
        serverMessageId: 100
    }
};

const send = (conn, m, text, extra = {}) =>
    conn.sendMessage(m.chat, {
        text,
        ...extra,
        contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
    }, { quoted: m });

const box = (title, body) =>
`*▰▱▰ [ ${title} ] ▰▱▰*

${body}

*─━─━─━─━─*
¥ ${BOT_NAME}`;

let handler = async (m, { conn, text }) => {
    try {
        // ─── لازم رد على رسالة ──────────────────────────
        if (!m.quoted) {
            return send(conn, m, box('𝒀𝒐𝒕𝒔𝒖𝒃𝒂', `*┌──────────────⚠️*
*│⋄ الـحـالـة:* خـطـأ فـي الـاسـتـخـدام
*└──────────────🧸*

📝 *لازم ترد على الاستيكر اللي عايز تضيف عليه اسم الباكدج*

💡 *مثال:* .حقوق اسم الباكدج | اسم المؤلف`));
        }

        // ─── لازم يكون ستيكر ────────────────────────────
        const mime = (m.quoted.msg || m.quoted).mimetype || m.quoted.mimetype || '';
        if (!/webp/.test(mime)) {
            return send(conn, m, box('𝒀𝒐𝒕𝒔𝒖𝒃𝒂', '❌ *لازم ترد على استيكر عشان نضيف الاسم!*'));
        }

        await conn.sendMessage(m.chat, { react: { text: '🕸', key: m.key } });

        // ─── قراءة اسم الباكدج والمؤلف ──────────────────
        const [packRaw, ...authorParts] = (text || '').split('|');
        const packname = packRaw?.trim() || BOT_NAME;
        const author = authorParts.join('|').trim() || 'Yotsuba';

        // ─── تحميل الستيكر وإضافة الحقوق ────────────────
        const img = await m.quoted.download();
        if (!img?.length) {
            return send(conn, m, box('𝒀𝒐𝒕𝒔𝒖𝒃𝒂', '❌ *فيه حاجة مش مزبوطه.. حاول تنزل الاستيكر تاني!*'));
        }

        let stiker;
        try {
            stiker = await addExif(img, packname, author);
        } catch (e) {
            console.error('addExif error:', e);
            // بعض الإصدارات بترمي الـ Buffer نفسه كـ error
            if (Buffer.isBuffer(e)) stiker = e;
        }

        if (!stiker) throw new Error('فشل إضافة الحقوق للستيكر');

        await conn.sendMessage(m.chat, {
            sticker: stiker,
            mimetype: 'image/webp',
            contextInfo: channelInfo
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('حقوق error:', e);
        await send(conn, m, box(BOT_NAME, '❌ *حصلت غلطة! تأكد انك رديت على استيكر وضفت اسم الباكدج*'));
    }
}

handler.usage = ["حقوق | نص"];
handler.command = ["حقوق"];
handler.category = "sticker";
export default handler;