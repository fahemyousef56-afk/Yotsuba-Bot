/*
 * 🌸 ⏤͟͞𝒀𝑼𝑲𝑰 - 𝑩𝜺𝑻⃝🌸
 * 📢 واتساب : https://whatsapp.com/channel/0029Vb8xTot1t90ks8pCah1O
 * 📨 تيليجرام : https://t.me/+-ZIIcYxN18w4ZGM8
 */


import axios from 'axios';
import { Sticker } from 'wa-sticker-formatter';

const handler = async (m, { conn, args }) => {
    let نص;
    if (args.length >= 1) {
        نص = args.join(' ');
    } else if (m.quoted?.text) {
        نص = m.quoted.text;
    } else {
        return m.reply('*❌ اكتب نص بعد الأمر أو رد على رسالة*\n\nمثال: .اقتباس_ملصق مرحبا بالعالم');
    }

    if (نص.length > 100) return m.reply('*❌ النص أكبر من 100 حرف*');

    m.react('⏳');
    try {
        const من = m.quoted ? m.quoted.sender : m.sender;
        const اسم = m.quoted ? (m.quoted.name || 'مجهول') : (m.name || 'مجهول');
        const صورة_بروفايل = await conn.profilePictureUrl(من, 'image').catch(() => 'https://i.ibb.co/dwRnNBxj/IMG-20261013-114123-968.jpg');

        const إنشاء_ستيكر = async (لون_خلفية) => {
            const بيانات = {
                type: 'quote',
                format: 'png',
                backgroundColor: لون_خلفية,
                width: 512,
                height: 768,
                scale: 2,
                messages: [{
                    entities: [],
                    avatar: true,
                    from: {
                        id: 1,
                        name: اسم,
                        photo: { url: صورة_بروفايل }
                    },
                    text: نص,
                    replyMessage: {}
                }]
            };
            const res = await axios.post('https://qc.botcahx.eu.org/generate', بيانات, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 30000
            });
            return Buffer.from(res.data.result.image, 'base64');
        };

        // إنشاء نسختين أبيض وأسود
        const [أبيض, أسود] = await Promise.all([
            إنشاء_ستيكر('#ffffff'),
            إنشاء_ستيكر('#1a1a1a')
        ]);

        for (const buf of [أبيض, أسود]) {
            const sticker = await new Sticker(buf, {
                pack: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂',
                author: 'Yotsuba',
                type: 'full'
            }).toBuffer();
            await conn.sendMessage(m.chat, { sticker }, { quoted: m });
        }

        m.react('✅');
    } catch (e) {
        m.react('❌');
        m.reply(`*❌ فشل إنشاء الملصق:* ${e.message?.slice(0, 100)}`);
    }
};

handler.usage = ['اقتباس_ملصق'];
handler.command = ['اقتباس_ملصق', 'qc', 'quotely'];
handler.category = 'sticker';

export default handler;
