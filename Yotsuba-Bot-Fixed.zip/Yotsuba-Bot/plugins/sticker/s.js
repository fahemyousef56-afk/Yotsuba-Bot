import { createSticker } from "../../system/utils.js";

const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const EMOJI = '🕸';

const channelInfo = {
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363433665479594@newsletter',
    newsletterName: '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍',
    serverMessageId: 100
  }
};

const send = (conn, m, text, extra = {}) =>
  conn.sendMessage(m.chat, {
    text,
    ...extra,
    contextInfo: { ...channelInfo, ...(extra.contextInfo || {}) }
  }, { quoted: m });

const test = async (m, { conn, bot }) => {
  // الرد على رسالة، أو الرسالة نفسها لو فيها صورة/فيديو
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mimetype || '';

  if (!/image|video|webp|gif/.test(mime)) {
    return send(conn, m, `*_${EMOJI} يرجى الرد على صورة أو فيديو لتحويله إلى ملصق ${EMOJI}_*`);
  }

  // مدة الفيديو لازم تكون قصيرة
  const seconds = Number((q.msg || q).seconds || q.seconds || 0);
  if (/video|gif/.test(mime) && seconds > 10) {
    return send(conn, m, '*❌ الفيديو يجب أن يكون أقل من 10 ثواني*');
  }

  try {
    await m.react?.(EMOJI);

    const media = await q.download();
    if (!media?.length) throw new Error('تعذر تحميل الميديا');

    // اسم البوت على الملصق (pack)، والمؤلف من الإعدادات لو موجود
    const { author } = bot?.config?.info?.copyright || {};

    const buffer = await createSticker(media, {
      mime,
      pack: BOT_NAME,
      author: author || 'Yotsuba'
    });

    await conn.sendMessage(m.chat, {
      sticker: buffer,
      contextInfo: channelInfo
    }, { quoted: m });

    await m.react?.('✅');
  } catch (e) {
    console.error('sticker error:', e);
    await m.react?.('❌');
    await send(conn, m, `*❌ فشل التحويل:* ${e.message?.slice(0, 100)}`);
  }
};

test.usage = ["ملصق"];
test.command = ["ملصق", "s"];
test.category = "sticker";
test.noSub = false;
export default test;