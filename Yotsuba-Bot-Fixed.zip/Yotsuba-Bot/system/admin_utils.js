const ensureDatabase = () => {
    if (!global.db) global.db = {};
    if (!global.db.groups) global.db.groups = {};
    return global.db;
};

export const getG = chatId => {
    const db = ensureDatabase();
    if (!db.groups[chatId]) db.groups[chatId] = {};
    return db.groups[chatId];
};

export const isOwnerFn = (sender, bot, conn) => {
    const normalized = String(sender || '').split('@')[0].split(':')[0];
    const owners = bot?.config?.owners || bot?.owners || [];

    return owners.some(owner => {
        const jid = String(owner?.jid || owner || '').split('@')[0].split(':')[0];
        const lid = String(owner?.lid || '').split('@')[0].split(':')[0];
        return normalized && (normalized === jid || normalized === lid);
    }) || normalized === String(conn?.user?.id || '').split('@')[0].split(':')[0];
};

export const canUseAdminCmd = (message, bot, conn) => (
    Boolean(message?.isAdmin) || isOwnerFn(message?.sender, bot, conn)
);

export const addWarn = async (chat, sender, conn, reason = 'مخالفة', bot) => {
    const db = ensureDatabase();
    const group = db.groups[chat];
    group.warnings ??= {};
    const count = group.warnings[sender] = (group.warnings[sender] || 0) + 1;

    await conn.sendMessage(chat, {
        text: `⚠️ تم إعطاء إنذار لـ @${sender.split('@')[0]}\n` +
            `السبب: ${reason}\n` +
            `عدد الإنذارات: ${count}`,
        mentions: [sender]
    });

    return count;
};

export const updateParticipant = async (chat, participant, action, conn) => {
    try {
        await conn.groupParticipantsUpdate(chat, [participant], action);
        return { ok: true };
    } catch (error) {
        return { ok: false, error };
    }
};