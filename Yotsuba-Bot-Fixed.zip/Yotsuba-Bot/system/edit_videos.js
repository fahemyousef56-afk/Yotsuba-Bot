// مصدر حي لفيديوهات الإديت (بيدور في تيك توك عبر tikwm).
// روابط telegra.ph/file/*.mp4 القديمة اتحذفت من تيليجراف، فأمر اديت كان بيفشل دايماً.
// دلوقتي بنجيب فيديوهات جديدة كل مرة، ولو فشل البحث نرجع للقائمة القديمة كاحتياطي.
import axios from 'axios';

const BASE = 'https://www.tikwm.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36';

const shuffle = (a) => {
  const arr = [...a];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
};

const full = (u) => (!u ? '' : u.startsWith('http') ? u : BASE + (u.startsWith('/') ? u : '/' + u));

export async function searchEditVideos(query, count = 20) {
  try {
    const { data } = await axios.get(`${BASE}/api/feed/search`, {
      params: { keywords: query, count, cursor: 0, hd: 0 },
      timeout: 20000,
      headers: { 'User-Agent': UA },
    });
    const vids = data?.data?.videos || [];
    return shuffle(vids)
      .filter((v) => !v.duration || v.duration <= 90)
      .map((v) => full(v.play || v.hdplay || v.wmplay))
      .filter(Boolean);
  } catch (e) {
    console.error('[edit_videos] فشل البحث:', e?.message);
    return [];
  }
}

export { shuffle };
