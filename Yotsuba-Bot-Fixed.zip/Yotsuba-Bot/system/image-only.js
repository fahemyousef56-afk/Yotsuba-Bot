// ملف كان ناقص وبيستورده bot.js و sub.js (كان بيوقف البوت بالكامل عند التشغيل).
// النسخة دي "تمرير" فقط: مفيش أي استبدال للفيديو بصورة، فالفيديوهات والـ APK
// والملفات بتتبعت زي ما هي.
export function enforceImageOnlySending(sock) {
  return sock;
}

export default enforceImageOnlySending;
