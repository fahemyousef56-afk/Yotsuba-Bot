// system/control.js
// ⤹ 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸 ⤾

const OFFICIAL_DECORATION = '˚.❀ ⋅━ׄ━ׄ━ׄ━ׄ•﹝🕸﹞•━ׄ━ׄ━ׄ━ׄ ⋅❀.˚';
const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
const FOOTER = `> ${BOT_NAME}`;
const CHANNEL_JID = '120363433665479594@newsletter';
const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';

const newsletter = { name: CHANNEL_NAME, jid: CHANNEL_JID };

// ─── الصور (دخول / خروج) ────────────────────────────────
const IMAGES = {
    add: 'https://i.ibb.co/QF3tVBXR/file-00000000302c82108c9b9510416a598e.png',      // صورة الدخول
    remove: 'https://i.ibb.co/60H4cYM5/file-0000000072ac8210828dd3443375fc14.png',    // صورة الخروج
};

// ─── آيات قرآنية ────────────────────────────────────────
const quran = (ayah, surah) => `﴿ ${ayah} ﴾\n〔 ${surah} 〕`;

const AYAT = {
    add: quran('وَقُل رَّبِّ أَنزِلْنِي مُنزَلًا مُّبَارَكًا وَأَنتَ خَيْرُ الْمُنزِلِينَ', 'سورة المؤمنون - ٢٩'),
    remove: quran('فَاللَّهُ خَيْرٌ حَافِظًا ۖ وَهُوَ أَرْحَمُ الرَّاحِمِينَ', 'سورة يوسف - ٦٤'),
    promote: quran('يَرْفَعِ اللَّهُ الَّذِينَ آمَنُوا مِنكُمْ وَالَّذِينَ أُوتُوا الْعِلْمَ دَرَجَاتٍ', 'سورة المجادلة - ١١'),
    demote: quran('إِنَّ اللَّهَ مَعَ الصَّابِرِينَ', 'سورة البقرة - ١٥٣'),
};

// ─── رسائل الأحداث ──────────────────────────────────────
const buildGroupMessages = (users, authorTag) => ({
    add: `${OFFICIAL_DECORATION}

🌹 *أَهْـلًـا وَسَـهْـلًـا بِـكَ يَـا* 🌹
『 ${users} 』

${OFFICIAL_DECORATION}
✨ نَوَّرْتَ الْمَكَانَ بِحُضُورِكَ الطَّيِّب
🤝 نَتَمَنَّى لَكَ وَقْتًا مُمْتِعًا بَيْنَ إِخْوَانِكَ
🕊️ الْتَزِمْ بِالْأَدَبِ وَاحْتَرِمِ الْجَمِيع

${AYAT.add}
${OFFICIAL_DECORATION}

${FOOTER}`,

    remove: `${OFFICIAL_DECORATION}

🍂 *فِـي حِـفْـظِ اللَّهِ يَـا* 🍂
『 ${users} 』

${OFFICIAL_DECORATION}
🤍 شُكْرًا لِوُجُودِكَ مَعَنَا، وَنَتَمَنَّى لَكَ التَّوْفِيق
🚪 بَابُنَا مَفْتُوحٌ لَكَ مَتَى شِئْتَ
🤲 لَا تَنْسَنَا مِنْ صَالِحِ دُعَائِك

${AYAT.remove}
${OFFICIAL_DECORATION}

${FOOTER}`,

    promote: `${OFFICIAL_DECORATION}

👑 *تَـرْقِـيَـةٌ إِدَارِيَّـةٌ جَـدِيـدَة* 👑

🎖️ *الْعُضْو:* ${users}
🖋️ *بِوَاسِطَة:* ${authorTag}
🫡 *الْمَسْؤُولِيَّةُ أَمَانَة، فَاسْتَخْدِمْ صَلَاحِيَّاتِكَ بِالْحَقّ*

${AYAT.promote}
${OFFICIAL_DECORATION}

${FOOTER}`,

    demote: `${OFFICIAL_DECORATION}

📉 *تَـنْـزِيـلُ رُتْـبَـة* 📉

👤 *الْعُضْو:* ${users}
🖋️ *بِوَاسِطَة:* ${authorTag}
🧸 *لَا بَأْس، كُلُّنَا إِخْوَة وَالْخَيْرُ فِيمَا اخْتَارَهُ اللَّه*

${AYAT.demote}
${OFFICIAL_DECORATION}

${FOOTER}`
});

// ─── رسائل التحذيرات ────────────────────────────────────
const box = (title, body) =>
    `${OFFICIAL_DECORATION}\n\n${title}\n\n${body}\n\n${OFFICIAL_DECORATION}\n${FOOTER}`;

const accessMessages = {
    cooldown: (time) => box(
        '⏳ *مَـهْـلًـا يَـا صَـدِيـقِـي*',
        `🕰️ انْتَظِرْ ${time || 'بِضْعَ'} ثَوَانٍ قَبْلَ اسْتِخْدَامِ الْأَمْرِ مُجَدَّدًا\n🌿 لَا تَسْتَعْجِلْ، فَالصَّبْرُ جَمِيل\n\n${quran('وَاصْبِرْ وَمَا صَبْرُكَ إِلَّا بِاللَّهِ', 'سورة النحل - ١٢٧')}`
    ),
    owner: box(
        '🚫 *صَـلَاحِـيَّـةُ الْـمُـطَـوِّر*',
        '🕸 هَذَا الْأَمْرُ مُخَصَّصٌ لِمُطَوِّرِي الْبُوتِ فَقَط'
    ),
    group: box(
        '👥 *أَوَامِـرُ الْـمَـجْـمُـوعَـات*',
        '🌐 يَعْمَلُ هَذَا الْأَمْرُ دَاخِلَ الْمَجْمُوعَاتِ فَقَط'
    ),
    admin: box(
        '👑 *صَـلَاحِـيَّـةُ الْإِدَارَة*',
        '⚠️ هَذَا الْأَمْرُ يَتَطَلَّبُ أَنْ تَكُونَ مُشْرِفًا (Admin)'
    ),
    private: box(
        '🔒 *أَوَامِـرُ الْـخَـاص*',
        '💬 يَعْمَلُ هَذَا الْأَمْرُ فِي الْمُحَادَثَاتِ الْخَاصَّةِ فَقَط'
    ),
    botAdmin: box(
        '🤖 *صَـلَاحِـيَّـةُ الْـبُـوت*',
        '🕸 اجْعَلِ الْبُوتَ مُشْرِفًا فِي الْجُرُوبِ حَتَّى يَسْتَطِيعَ تَنْفِيذَ الْأَمْر'
    ),
    noSub: box(
        '🧸 *لِـلْـبُـوتِ الْأَسَـاسِـي*',
        '🔁 هَذَا الْأَمْرُ لَا يَعْمَلُ فِي الْبُوتَاتِ الْفَرْعِيَّةِ، جَرِّبْهُ فِي الْبُوتِ الْأَسَاسِي'
    ),
    disabled: box(
        '🛠️ *الْأَمْـرُ تَـحْـتَ الصِّـيَـانَـة*',
        '⚙️ هَذَا الْأَمْرُ مُتَوَقِّفٌ حَالِيًّا لِأَعْمَالِ الصِّيَانَةِ وَالتَّحْسِين'
    ),
    error: box(
        '❌ *حَـدَثَ خَـطَـأ*',
        `🕸 حَدَثَ خَطَأٌ أَثْنَاءَ تَنْفِيذِ الْأَمْرِ، تَوَاصَلْ مَعَ الْمُطَوِّرِ عَبْرَ أَمْرِ (.المطور)\n\n${quran('لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا', 'سورة البقرة - ٢٨٦')}`
    ),
};

// ─── حدث الجروب ─────────────────────────────────────────
const group = async (ctx, event, eventType) => {
    try {
        if (!event?.participants) return null;

        const participants = event.participants
            .filter(p => p?.phoneNumber)
            .map(p => p.phoneNumber);

        const author = event.author;
        const users = participants.length
            ? participants.map(p => '@' + p.split('@')[0]).join(' و ')
            : 'مستخدم';
        const authorTag = author ? '@' + author.split('@')[0] : 'Unknown';

        const txt = buildGroupMessages(users, authorTag)[eventType];
        if (!txt) return null;

        // التحقق من تفعيل الترحيب/الوداع
        if (['add', 'remove'].includes(eventType)) {
            const settings = global.db?.groups?.[event.chat];
            if (settings?.noWelcome === true) return 9999;
            if (eventType === 'add' && settings?.welcome?.enabled === false) return null;
            if (eventType === 'remove' && settings?.farewell?.enabled === false) return null;
        }

        const mentions = author ? [author, ...participants] : participants;

        // دخول / خروج → صورة + الكلام في الكابشن
        const image = IMAGES[eventType];
        if (image) {
            try {
                await ctx.sock.sendMessage(event.chat, {
                    image: { url: image },
                    caption: txt,
                    mentions,
                    contextInfo: {
                        isForwarded: true,
                        forwardingScore: 1,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: CHANNEL_JID,
                            newsletterName: CHANNEL_NAME,
                            serverMessageId: -1,
                        },
                    },
                });
                return null;
            } catch (e) {
                console.error('group image send failed, falling back to text:', e);
            }
        }

        // ترقية / تنزيل (أو لو الصورة فشلت) → رسالة نصية عادية
        await ctx.sock.msgUrl(event.chat, txt, {
            newsletter,
            mentions,
            big: ["remove", "add"].includes(eventType)
        });
    } catch (e) {
        console.error('group event error:', e);
    }
    return null;
};

// ─── تحقق الصلاحيات ─────────────────────────────────────
const access = async (msg, checkType, time) => {
    const conn = await msg.client();

    const builder = accessMessages[checkType];
    const txt = typeof builder === 'function' ? builder(time) : builder;

    if (conn && txt) {
        await conn.msgUrl(msg.chat, txt, {
            newsletter,
            mentions: [msg.sender],
            big: false
        });
        return false;
    }
    return null;
};

export { access, group };