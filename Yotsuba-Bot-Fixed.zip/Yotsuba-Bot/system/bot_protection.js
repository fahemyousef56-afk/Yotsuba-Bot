const cooldowns = new Map();

export const notAdminMsg = () =>
    '❌ لازم البوت يكون أدمن في الجروب عشان ينفذ الأمر';

export const notAuthMsg = () =>
    '❌ الأمر ده للمشرفين فقط';

export const adminGuard = async m => {
    if (m?.isOwner || m?.owner || m?.isAdmin) return true;
    return false;
};

export const checkCommandCooldown = (command, sender, chat, windowMs = 1500) => {
    const key = `${chat || 'chat'}:${sender || 'user'}:${command || 'command'}`;
    const now = Date.now();
    const previous = cooldowns.get(key) || 0;
    const elapsed = now - previous;

    if (elapsed < windowMs) {
        return { allowed: false, waitMs: windowMs - elapsed };
    }

    cooldowns.set(key, now);
    return { allowed: true, waitMs: 0 };
};