// مزودات التحميل المشتركة (انستا / فيس / تحميل شامل)
// الفكرة: جرّب أكتر من مصدر بالترتيب، وأول مصدر يرجّع ميديا يُستخدم.
// لو مصدر وقع أو اتغير شكل رده، البوت يكمل للمصدر اللي بعده بدل ما يفشل.
import axios from 'axios';
import qs from 'qs';
import * as cheerio from 'cheerio';

export const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

const enc = encodeURIComponent;
const isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);
const SKIP_KEYS = /thumb|cover|avatar|profile|poster|preview|icon|logo/i;

const guessType = (url, key = '') => {
  const clean = String(url).split('?')[0].toLowerCase();
  if (/\.(jpe?g|png|webp|gif)$/.test(clean)) return 'image';
  if (/\.(mp4|mov|webm|m4v)$/.test(clean)) return 'video';
  if (/image|photo|pic/i.test(key)) return 'image';
  return 'video';
};

// يطلع كل روابط الميديا من أي شكل رد (مصفوفة / كائن / نص)
export function collectMedia(data, out = [], key = '', depth = 0) {
  if (data == null || depth > 7) return out;
  if (typeof data === 'string') {
    if (isHttp(data) && !SKIP_KEYS.test(key) && !out.some((o) => o.url === data)) {
      out.push({ type: guessType(data, key), url: data });
    }
    return out;
  }
  if (Array.isArray(data)) {
    for (const item of data) collectMedia(item, out, key, depth + 1);
    return out;
  }
  if (typeof data === 'object') {
    for (const [k, v] of Object.entries(data)) collectMedia(v, out, k, depth + 1);
  }
  return out;
}

const getJson = async (url) => {
  const { data } = await axios.get(url, { timeout: 25000, headers: { 'User-Agent': UA } });
  return data;
};

const btch = async (name, url) => {
  const mod = await import('btch-downloader'); // موجودة في package.json
  const fn = mod[name] || mod.default?.[name];
  if (typeof fn !== 'function') throw new Error(`btch-downloader.${name} غير موجودة`);
  return fn(url);
};

// يجرب المصادر بالترتيب. كل مصدر دالة async بترجع بيانات خام.
async function firstWorking(sources) {
  const errors = [];
  for (const [name, run] of sources) {
    try {
      const raw = await run();
      const media = collectMedia(raw);
      if (media.length) return media;
      errors.push(`${name}: فاضي`);
    } catch (e) {
      errors.push(`${name}: ${e?.message || e}`);
    }
  }
  const err = new Error('كل مصادر التحميل فشلت، جرب بعد شوية أو جرب رابط تاني');
  err.details = errors;
  console.error('[dl_providers]', errors.join(' | '));
  throw err;
}

/* ───────────── Facebook: scrape fdownloader.net (الطريقة الأصلية) ───────────── */
async function fdownloader(link) {
  const form = (o) => qs.stringify(o);
  const h = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    Accept: '*/*',
    'X-Requested-With': 'XMLHttpRequest',
    'User-Agent': UA,
    Referer: 'https://fdownloader.net/id',
  };
  const v = await axios.post('https://fdownloader.net/api/userverify', form({ url: link }), {
    headers: h,
    timeout: 25000,
  });
  const { k_token, k_exp, token } = v.data || {};
  const r = await axios.post(
    'https://v3.fdownloader.net/api/ajaxSearch',
    form({ k_exp, k_token, q: link, lang: 'id', web: 'fdownloader.net', v: 'v2', w: '', cftoken: token }),
    { headers: h, timeout: 25000 }
  );
  const $ = cheerio.load(r.data?.data || '');
  const rows = [];
  $('table.table tbody tr').each((_, el) => {
    const quality = $(el).find('.video-quality').text().trim();
    const url = $(el).find('a.download-link-fb').attr('href');
    if (quality && url) rows.push({ quality, url });
  });
  const q = (s) => parseInt(String(s).match(/\d+/)?.[0] || '0', 10);
  rows.sort((a, b) => q(b.quality) - q(a.quality));
  return rows.slice(0, 1).map((r2) => r2.url); // أعلى جودة فقط
}

export const getFacebook = (link) =>
  firstWorking([
    ['fdownloader', () => fdownloader(link)],
    ['btch', () => btch('fbdown', link)],
    ['siputzx', () => getJson(`https://api.siputzx.my.id/api/d/fb?url=${enc(link)}`)],
    ['aswin', () => getJson(`https://api-aswin-sparky.koyeb.app/api/downloader/fbdl?url=${enc(link)}`)],
  ]);

export const getInstagram = (link, Api) =>
  firstWorking([
    [
      'meowsab-api',
      async () => {
        if (typeof Api?.download?.instagram !== 'function') throw new Error('غير متاح');
        const res = await Api.download.instagram({ url: link });
        if (res?.status && res.status !== 'success') throw new Error('status=' + res.status);
        return res?.data ?? res;
      },
    ],
    ['btch', () => btch('igdl', link)],
    ['siputzx', () => getJson(`https://api.siputzx.my.id/api/d/igdl?url=${enc(link)}`)],
    ['aswin', () => getJson(`https://api-aswin-sparky.koyeb.app/api/downloader/instagram?url=${enc(link)}`)],
  ]);

export const getThreads = (link) =>
  firstWorking([
    ['siputzx', () => getJson(`https://api.siputzx.my.id/api/d/threads?url=${enc(link)}`)],
    ['aswin', () => getJson(`https://api-aswin-sparky.koyeb.app/api/downloader/threads?url=${enc(link)}`)],
  ]);

export const getTwitter = (link) =>
  firstWorking([
    ['btch', () => btch('twitter', link)],
    ['eliteprotech', () => getJson(`https://eliteprotech-apis.zone.id/x?url=${enc(link)}`)],
    ['siputzx', () => getJson(`https://api.siputzx.my.id/api/d/twitter?url=${enc(link)}`)],
  ]);

export const getYoutube = (link) =>
  firstWorking([
    ['btch', () => btch('youtube', link)],
    ['siputzx', () => getJson(`https://api.siputzx.my.id/api/d/ytmp4?url=${enc(link)}`)],
    ['ryzendesu', () => getJson(`https://api.ryzendesu.vip/api/downloader/ytmp4?url=${enc(link)}`)],
  ]);

/* ───────────── إرسال ميديا: رابط ← buffer ← رابط نصي ───────────── */
export async function sendMedia(conn, m, { type, url }, caption, contextInfo) {
  const base = { caption, contextInfo };
  if (type === 'video') base.mimetype = 'video/mp4';
  try {
    await conn.sendMessage(m.chat, { [type]: { url }, ...base }, { quoted: m });
    return;
  } catch (e) {
    console.error('فشل الإرسال بالرابط، هجرب buffer:', e?.message);
  }
  try {
    const res = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 90000,
      headers: { 'User-Agent': UA },
      maxContentLength: 100 * 1024 * 1024,
    });
    const buffer = Buffer.from(res.data);
    if (buffer.length < 1000) throw new Error('الملف فاضي أو تالف');
    await conn.sendMessage(m.chat, { [type]: buffer, ...base }, { quoted: m });
    return;
  } catch (e) {
    console.error('فشل الإرسال بالـ buffer:', e?.message);
  }
  await conn.sendMessage(
    m.chat,
    { text: `${caption}\n\n🔗 *رابط التحميل المباشر:*\n${url}`, contextInfo },
    { quoted: m }
  );
}
