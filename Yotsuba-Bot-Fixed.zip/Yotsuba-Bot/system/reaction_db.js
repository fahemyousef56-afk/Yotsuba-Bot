const subscriptions = new Map();

export const getAllSubs = () => [...subscriptions.values()];

export const getSubsByChannel = channelJid => (
    getAllSubs().filter(sub => sub.channelJid === channelJid)
);

export const addSub = sub => {
    const id = sub?.id || `${sub?.channelJid || 'channel'}:${Date.now()}`;
    const value = { ...sub, id };
    subscriptions.set(id, value);
    return value;
};

export const removeSub = id => subscriptions.delete(id);