import fetch from 'node-fetch';

export const EMOJI = '🐤';
export const BOT_NAME = '𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸';
export const DEVELOPER = '𝑴𝒓  • 𝒀𝒐𝒕𝒔𝒖𝒐  •  𝑫𝒆𝒗';
export const CHANNEL_JID = '120363433665479594@newsletter';
export const CHANNEL_NAME = '𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍';
export const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z';
export const MAIN_IMAGE = 'https://i.ibb.co/n8Y6T4TY/candy-addict-full-course-miku-by-siolane-dey49ro-pre.jpg';

// Keep the shared fetch available to legacy plugins that expect it globally.
if (!globalThis.fetch) globalThis.fetch = fetch;

globalThis.YOTSUBA_PREAMBLE = {
  EMOJI,
  BOT_NAME,
  DEVELOPER,
  CHANNEL_JID,
  CHANNEL_NAME,
  CHANNEL_LINK,
  MAIN_IMAGE,
};