// نقطة التشغيل: بتشغّل بوت التليجرام وبوت واتساب مع بعض
import './telegram-installer.js';
