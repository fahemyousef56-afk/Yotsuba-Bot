import { Client } from 'meowsab';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { group, access } from "./system/control.js";
import UltraDB from "./system/UltraDB.js";
import { enforceImageOnlySending } from "./system/image-only.js";
import "./preamble.js";
import sub from './sub.js';

const BOT_ROOT = path.dirname(fileURLToPath(import.meta.url));

/* =========== Client ========== */
const client = new Client({
  phoneNumber: process.env.WHATSAPP_MAIN_PHONE || '201092189342', // Bot number
  prefix: [".", "/", "!"],
  fromMe: null,
  printQR: false,
  // Pairing is requested from the Telegram control panel instead of logs.
  showLogs: false,
  sessionPath: path.join(BOT_ROOT, 'session'),
  owners: [
    {
      name: "المطور",
      jid: `${process.env.DEVELOPER_WHATSAPP_NUMBER || '221774033156'}@s.whatsapp.net`,
      lid: `${process.env.DEVELOPER_WHATSAPP_NUMBER || '253038501605520'}@lid`
    }
  ],
  settings: { noWelcome: false },
  commandsPath: path.join(BOT_ROOT, 'plugins')
});
global.mainBot = client;

client.onGroupEvent(group);
client.onCommandAccess(access);
const imageOnlyMonitor = setInterval(() => enforceImageOnlySending(client.sock), 100);
imageOnlyMonitor.unref?.();

/* =========== Database ========== */
if (!global.db) {
    global.db = new UltraDB();
}

/* =========== Config ========== */
const { config } = client;
const BOT_NAME = "𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸";
const CHANNEL_NAME = "𝒀𝒐𝒕𝒔𝒖𝒃𝒂 • 𝑪𝒉𝒂𝒏𝒏𝒆𝒍";
const CHANNEL_LINK = "https://whatsapp.com/channel/0029VbEKUCc7T8bfoVGuTx3Z";
const CHANNEL_JID = "120363433665479594@newsletter";
const BRAND_IMAGES = [
  "https://i.ibb.co/n8Y6T4TY/candy-addict-full-course-miku-by-siolane-dey49ro-pre.jpg",
  "https://i.ibb.co/PkNHfYM/chimera-by-anthophilasation-dfx3sia-pre.jpg",
  "https://i.ibb.co/8pfnm4m/miss-miku-by-siolane-df1crvz-pre.jpg",
  "https://i.ibb.co/Z6kdH64D/underworld-by-likesac-df6y33o-414w-2x.jpg",
  "https://i.ibb.co/gbFC1L7R/persephone-by-lizally-df9t20i-414w-2x.jpg",
  "https://i.ibb.co/VWZhj6x5/happy-halloween-by-smeoow-deuaihw-pre.jpg",
  "https://i.ibb.co/MkKP6v8X/oc-by-felicc-denac7j-pre.jpg",
  "https://i.ibb.co/xSP2yDZ6/good-night-by-likesac-ddu0ytr-414w-2x.jpg",
  "https://i.ibb.co/Z1cRPpgn/nekomishh-2nd-illust-commission-by-pawi-senpai-dkuziks-414w-2x.jpg",
  "https://i.ibb.co/ynpcn8RR/hihihhihi-by-irlzume-de43vsy-pre.jpg",
  "https://i.ibb.co/rKSR43yC/ajasdsjkfdlsl-by-irlzume-de511oj-375w-2x.jpg",
  "https://i.ibb.co/BHZ07YNY/sertraline-by-domitare-diokv2r-414w-2x.jpg",
  "https://i.ibb.co/9HRqBgyY/untitled-49-by-ochajeimp3-dicuw62-pre.jpg",
  "https://i.ibb.co/JW6s6kGs/payments-by-aurpl3xd-dgw0jhl-pre.jpg",
  "https://i.ibb.co/1YSZmytw/jeeeeeeeeeeeeeeeeeeeeee-by-dreamalgia-dfanuuy-414w-2x.jpg",
  "https://i.ibb.co/JMdcZ92/ghost-friend-adopt-by-ikagummy-dges1md-pre.jpg"
];

global.redes = CHANNEL_LINK;
global.icons = BRAND_IMAGES[0];
config.info = {
  nameBot: BOT_NAME,
  urls: { repo: "", api: "https://emam-api.web.id", channel: CHANNEL_LINK },
  channel: CHANNEL_LINK,
  channelLink: CHANNEL_LINK,
  newsletter: CHANNEL_LINK,
  newsletterLink: CHANNEL_LINK,
  channelUrl: CHANNEL_LINK,
  channelJid: CHANNEL_JID,
  channelName: CHANNEL_NAME,
  links: { channel: CHANNEL_LINK, newsletter: CHANNEL_LINK },
  copyright: { pack: BOT_NAME, author: BOT_NAME },
  images: BRAND_IMAGES
};

/* =========== Start ========== */
client.start();

const waitForMainSocket = async (timeoutMs = 30_000) => {
  const startedAt = Date.now();
  while (!client.sock && Date.now() - startedAt < timeoutMs) {
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  return client.sock;
};

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const requestMainPairingCode = async (normalizedPhone) => {
  client.config.phoneNumber = normalizedPhone;

  // A socket that was created before the Telegram request may already be
  // closed. Restart it so requestPairingCode always uses a fresh connection.
  await client.restart(true);
  await sleep(2_500);

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const sock = await waitForMainSocket();
    if (!sock) {
      throw new Error("واتساب الأساسي لم يجهز لطلب كود الربط بعد");
    }

    try {
      return await sock.requestPairingCode(normalizedPhone);
    } catch (error) {
      const message = String(error?.message || error);
      if (!/closed|connection/i.test(message) || attempt === 3) {
        throw error;
      }
      await client.restart(true);
      await sleep(2_500);
    }
  }

  throw new Error("تعذر إنشاء كود الربط");
};

global.mainBotPair = async phone => {
  if (client.isConnected()) {
    return { alreadyConnected: true, phone: client.config.phoneNumber || null };
  }

  const normalizedPhone = String(phone || "").replace(/[^\d]/g, "").replace(/^00/, "");
  if (!/^\d{8,15}$/.test(normalizedPhone) || normalizedPhone.startsWith("0")) {
    throw new Error("رقم واتساب غير صحيح");
  }

  const code = await requestMainPairingCode(normalizedPhone);
  return { code, phone: normalizedPhone };
};

setTimeout(async () => {
  if (client.commandSystem) { 
    sub(client);
  }
}, 2000);

/* =========== Catch Errors ========== */
process.on('uncaughtException', (e) => {
    if (e.message.includes('rate-overlimit')) {}
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
});
