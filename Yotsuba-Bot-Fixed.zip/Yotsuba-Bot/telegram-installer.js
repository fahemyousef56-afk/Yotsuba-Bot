import { Telegraf, Markup, session } from 'telegraf';

const token = process.env.BET_BOT_TELEGRAM_TOKEN || '8510079084:AAHNYZw8sG917-PYMHSPMz0h0sNeaZz5of0';
if (!token) {
  throw new Error('BET_BOT_TELEGRAM_TOKEN is not configured');
}

await import('./bot.js');

const bot = new Telegraf(token);
bot.use(session({ defaultSession: () => ({ mode: null }) }));

const pendingInstalls = new Map();
const lastInstallByUser = new Map();
const INSTALL_COOLDOWN_MS = 60_000;
const MAX_SUB_BOTS = 150;
const ADMIN_USERNAME = String(
  process.env.TELEGRAM_ADMIN_USERNAME || ''
).replace(/^@/, '').toLowerCase();
const ADMIN_ID = String(process.env.TELEGRAM_ADMIN_ID || '8022609834').trim();

function isAdmin(ctx) {
  if (ctx.chat?.type !== 'private') return false;

  const userId = String(ctx.from?.id || '');
  const username = String(ctx.from?.username || '').toLowerCase();
  return (ADMIN_ID && userId === ADMIN_ID) || (
    ADMIN_USERNAME && username === ADMIN_USERNAME
  );
}

async function requirePrivateChat(ctx) {
  if (ctx.chat?.type === 'private') return true;
  await ctx.reply('🔒 التنصيب خاص. افتح المحادثة الخاصة مع البوت وأرسل /start للمتابعة بأمان.');
  return false;
}

async function requireAdmin(ctx) {
  if (isAdmin(ctx)) return true;
  await ctx.reply('🚫 الأمر ده متاح لمالك البوت فقط.');
  return false;
}

function normalizePhone(value) {
  const phone = String(value || '').replace(/[^\d]/g, '');
  return phone.replace(/^00/, '');
}

function validPhone(phone) {
  return /^\d{8,15}$/.test(phone) && !phone.startsWith('0');
}

function mainKeyboard(ctx) {
  const rows = [
    ['تنصيب البوت🕸️'],
    ['📊 حالة التنصيبات', '❓ المساعدة']
  ];

  if (isAdmin(ctx)) rows.push(['🧑‍💻 لوحة التحكم']);
  return Markup.keyboard(rows).resize();
}

function adminKeyboard() {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('📊 تحديث الحالة', 'control:status'),
      Markup.button.callback('▶️ تشغيل الكل', 'control:resume')
    ],
    [
      Markup.button.callback('⏸️ إيقاف الكل', 'control:pause'),
      Markup.button.callback('🔗 ربط الأساسي', 'control:pair-main')
    ]
  ]);
}

function helpText() {
  return [
    '╔══════════════════════╗',
    '║  🤖 تنصيب 𝒀𝑶𝑻𝑺𝑼𝑩𝑨⃝⃕ ⥃ 𝑩☻𝑻⃝🕸  عبر تيليجرام  ║',
    '╚══════════════════════╝',
    '',
    '1) اضغط «📲 تثبيت نسخة واتساب».',
    '2) أرسل رقم واتساب بالصيغة الدولية، مثل:',
    '`20123##67890`',
    '',
    '3) استلم كود الربط هنا في تيليجرام.',
    '4) في واتساب افتح: الأجهزة المرتبطة ← ربط جهاز ← ربط برقم الهاتف، ثم أدخل الكود.',
    '',
    'بعد الربط، نسخة البوت تعمل على واتساب. رقم واتساب مطلوب لإتمام الربط.'
  ].join('\n');
}

function activeSubBots() {
  return global.subBots && typeof global.subBots.list === 'function'
    ? global.subBots.list()
    : [];
}

function controlStatusText() {
  const control = global.whatsappControl;
  if (!control || typeof control.status !== 'function') {
    return '⚠️ لوحة التحكم لسه بتجهز، حاول بعد ثواني.';
  }

  const status = control.status();
  const main = status.main?.connected ? '🟢 شغال' : '🔴 متوقف';
  const subBots = status.subBots || [];
  const connected = subBots.filter(bot => bot.connected).length;
  const lines = [
    '🧑‍💻 *لوحة تحكم واتساب*',
    '',
    `البوت الأساسي: ${main}`,
    `البوتات الفرعية: ${connected}/${subBots.length} متصل`,
    ''
  ];

  if (!subBots.length) {
    lines.push('لا توجد بوتات فرعية محفوظة حالياً.');
  } else {
    lines.push('*التفاصيل:*');
    for (const bot of subBots.slice(0, 30)) {
      lines.push(
        `${bot.connected ? '🟢' : '🔴'} ${bot.phone || bot.id} — ` +
        `${bot.connected ? 'شغال' : 'متوقف'}`
      );
    }
    if (subBots.length > 30) {
      lines.push(`… و ${subBots.length - 30} بوتات أخرى`);
    }
  }

  return lines.join('\n');
}

async function showControlPanel(ctx, edit = false) {
  if (!(await requireAdmin(ctx))) return;

  const text = controlStatusText();
  if (edit) {
    try {
      await ctx.editMessageText(text, {
        parse_mode: 'Markdown',
        ...adminKeyboard()
      });
      return;
    } catch {}
  }

  await ctx.reply(text, {
    parse_mode: 'Markdown',
    ...adminKeyboard()
  });
}

async function waitForSubBots(timeoutMs = 30_000) {
  const started = Date.now();
  while (!global.subBots && Date.now() - started < timeoutMs) {
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  return global.subBots;
}

async function beginMainPair(ctx, rawPhone) {
  if (!(await requireAdmin(ctx))) return;

  const phone = normalizePhone(rawPhone);
  if (!validPhone(phone)) {
    await ctx.reply(
      '❌ الرقم غير صحيح.\n\nأرسله بالصيغة الدولية بدون + أو مسافات، مثال:\n201234567890'
    );
    return;
  }

  if (typeof global.mainBotPair !== 'function') {
    await ctx.reply('⚠️ البوت الأساسي لسه بيجهز، حاول بعد ثواني.');
    return;
  }

  try {
    const result = await global.mainBotPair(phone);
    if (result.alreadyConnected) {
      await ctx.reply(
        `✅ البوت الأساسي متصل بالفعل على الرقم:\n\`${result.phone || phone}\``,
        { parse_mode: 'Markdown' }
      );
      return;
    }

    await ctx.reply(
      `🔗 *كود ربط البوت الأساسي جاهز*\n\n` +
      `📱 الرقم: \`${result.phone}\`\n` +
      `🔑 الكود: \`${result.code}\`\n\n` +
      `افتح واتساب على الرقم ده ثم:\n` +
      `الأجهزة المرتبطة ← ربط جهاز ← ربط برقم الهاتف\n` +
      `وأدخل الكود كما هو.\n\n` +
      `بعد إتمام الربط استخدم زر *📊 تحديث الحالة*.`,
      { parse_mode: 'Markdown', ...adminKeyboard() }
    );
  } catch (error) {
    await ctx.reply(
      `❌ تعذر إنشاء كود الربط.\n\nالسبب: ${error?.message || 'خطأ غير معروف'}`
    );
  }
}

async function beginInstall(ctx, rawPhone) {
  if (!(await requirePrivateChat(ctx))) return;

  const userId = ctx.from.id;
  const now = Date.now();
  const previous = lastInstallByUser.get(userId) || 0;
  if (now - previous < INSTALL_COOLDOWN_MS) {
    const seconds = Math.ceil((INSTALL_COOLDOWN_MS - (now - previous)) / 1000);
    await ctx.reply(`⏳ استنى ${seconds} ثانية قبل طلب تنصيب جديد.`);
    return;
  }

  const phone = normalizePhone(rawPhone);
  if (!validPhone(phone)) {
    await ctx.reply(
      '❌ الرقم غير صحيح.\n\nأرسله بالصيغة الدولية بدون + أو مسافات، مثال:\n201234567890'
    );
    return;
  }

  const sub = await waitForSubBots();
  if (!sub || typeof sub.add !== 'function') {
    await ctx.reply('⚠️ نظام التنصيبات لسه بيجهز، حاول بعد ثواني.');
    return;
  }

  const currentCount = typeof sub.list === 'function' ? sub.list().length : 0;
  if (currentCount >= MAX_SUB_BOTS) {
    await ctx.reply(`⚠️ وصلنا للحد الأقصى للتنصيبات (${MAX_SUB_BOTS}).`);
    return;
  }

  if (pendingInstalls.has(userId)) {
    await ctx.reply('⏳ عندك عملية تنصيب قيد التنفيذ بالفعل.');
    return;
  }

  lastInstallByUser.set(userId, now);
  const state = {
    phone,
    uid: null,
    pendingPair: null,
    pendingReady: null,
    pendingError: null,
    pendingBadSession: null,
    resolved: false,
    timer: null,
    sub,
    cleanup: null,
  };
  pendingInstalls.set(userId, state);

  const cleanup = () => {
    if (state.timer) clearTimeout(state.timer);
    pendingInstalls.delete(userId);
    sub.off('pair', onPair);
    sub.off('ready', onReady);
    sub.off('error', onError);
    sub.off('badSession', onBadSession);
  };
  state.cleanup = cleanup;

  const sendPairCode = async code => {
    await ctx.reply(
      `╔══════════════════════╗\n` +
      `║  🔐 *كود الربط جاهز*  ║\n` +
      `╚══════════════════════╝\n\n` +
      `📱 الرقم: \`${phone}\`\n` +
      `🔑 الكود: \`${code}\`\n\n` +
      `افتح واتساب على الرقم ده:\n` +
      `الأجهزة المرتبطة ← ربط جهاز ← ربط برقم الهاتف\n` +
      `ثم أدخل الكود كما هو.\n\n` +
      `⏱️ الكود مؤقت، استخدمه الآن.`,
      { parse_mode: 'Markdown' }
    );
  };

  const onPair = async (uid, code) => {
    if (state.resolved) return;
    if (!state.uid) {
      state.pendingPair = { uid, code };
      return;
    }
    if (state.uid !== uid) return;
    await sendPairCode(code);
  };

  const onReady = async (uid) => {
    if (state.resolved) return;
    if (!state.uid) {
      state.pendingReady = uid;
      return;
    }
    if (state.uid !== uid) return;

    state.resolved = true;
    cleanup();
    await ctx.reply(
      `✅ *تم التنصيب بنجاح!*\n\n` +
      `📱 الرقم: \`${phone}\`\n` +
      `🤖 البوت الفرعي شغال الآن على واتساب.\n\n` +
      `اكتب \`.اوامر\` في واتساب لعرض الأقسام والأوامر.`,
      { parse_mode: 'Markdown', ...mainKeyboard(ctx) }
    );
  };

  const onError = async (uid, error) => {
    if (state.resolved) return;
    if (!state.uid) {
      state.pendingError = { uid, error };
      return;
    }
    if (state.uid !== uid) return;
    state.resolved = true;
    cleanup();
    await ctx.reply(`❌ فشل التنصيب للرقم ${phone}.\n\nالسبب: ${error?.message || 'خطأ غير معروف'}`);
  };

  const onBadSession = async (uid) => {
    if (state.resolved) return;
    if (!state.uid) {
      state.pendingBadSession = uid;
      return;
    }
    if (state.uid !== uid) return;
    state.resolved = true;
    cleanup();
    await ctx.reply(`❌ جلسة الرقم ${phone} غير صالحة وتم حذفها. ابدأ التنصيب من جديد.`);
  };

  sub.on('pair', onPair);
  sub.on('ready', onReady);
  sub.on('error', onError);
  sub.on('badSession', onBadSession);

  state.timer = setTimeout(async () => {
    if (state.resolved) return;
    state.resolved = true;
    try {
      if (state.uid && typeof sub.remove === 'function') await sub.remove(state.uid);
    } catch {}
    cleanup();
    await ctx.reply('⏰ انتهت مهلة التنصيب. اضغط تنصيب من جديد للحصول على كود جديد.');
  }, 120_000);

  try {
    state.uid = await sub.add(phone);
    if (state.resolved) {
      if (typeof sub.remove === 'function') {
        try {
          await sub.remove(state.uid);
        } catch {}
      }
      cleanup();
      return;
    }
    if (state.pendingError?.uid === state.uid) {
      await onError(state.uid, state.pendingError.error);
      return;
    }
    if (state.pendingBadSession === state.uid) {
      await onBadSession(state.uid);
      return;
    }
    if (state.pendingPair?.uid === state.uid && !state.resolved) {
      await sendPairCode(state.pendingPair.code);
      state.pendingPair = null;
    }
    if (state.pendingReady === state.uid && !state.resolved) {
      await onReady(state.uid);
      return;
    }
    await ctx.reply(
      `⏳ جاري تجهيز تنصيب البوت للرقم:\n\`${phone}\`\n\n` +
      `هيوصلك كود الربط هنا خلال ثواني.`,
      { parse_mode: 'Markdown' }
    );
  } catch (error) {
    if (state.resolved) return;
    state.resolved = true;
    cleanup();
    await ctx.reply(`❌ تعذر بدء التنصيب.\n\nالسبب: ${error?.message || 'خطأ غير معروف'}`);
  }
}

bot.start(async ctx => {
  if (!(await requirePrivateChat(ctx))) return;

  await ctx.reply(
    '🎉 أهلاً بك في مساعد تنصيب 𝒀𝒐𝒖𝒏𝒂 • 𝑩𝜺𝑻⃝🕸 عبر تيليجرام.\n\n' +
    'ابدأ التنصيب من الزر، وسيصلك كود ربط نسخة واتساب هنا.',
    mainKeyboard(ctx)
  );
});

bot.command(['panel', 'لوحة'], async ctx => {
  await showControlPanel(ctx);
});

bot.hears('🧑‍💻 لوحة التحكم', async ctx => {
  await showControlPanel(ctx);
});

bot.action('control:status', async ctx => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery('تم تحديث الحالة');
  await showControlPanel(ctx, true);
});

bot.action('control:pause', async ctx => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery('جاري الإيقاف');
  const control = global.whatsappControl;
  if (!control?.pauseAll) {
    await ctx.reply('⚠️ خدمة واتساب لسه بتجهز.');
    return;
  }

  try {
    await control.pauseAll();
    await showControlPanel(ctx, true);
  } catch (error) {
    await ctx.reply(`❌ تعذر إيقاف البوتات: ${error?.message || 'خطأ غير معروف'}`);
  }
});

bot.action('control:resume', async ctx => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery('جاري التشغيل');
  const control = global.whatsappControl;
  if (!control?.resumeAll) {
    await ctx.reply('⚠️ خدمة واتساب لسه بتجهز.');
    return;
  }

  try {
    await control.resumeAll();
    await showControlPanel(ctx, true);
  } catch (error) {
    await ctx.reply(`❌ تعذر تشغيل البوتات: ${error?.message || 'خطأ غير معروف'}`);
  }
});

bot.action('control:pair-main', async ctx => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery();
  ctx.session.mode = 'main-phone';
  await ctx.reply(
    '🔗 أرسل رقم واتساب الأساسي بالصيغة الدولية بدون + أو مسافات.\n\nمثال: `201234567890`',
    { parse_mode: 'Markdown', ...Markup.keyboard([['❌ إلغاء']]).resize() }
  );
});

bot.command(['pairmain', 'ربط_البوت', 'ربط'], async ctx => {
  if (!(await requireAdmin(ctx))) return;
  ctx.session.mode = 'main-phone';
  await ctx.reply(
    '🔗 أرسل رقم واتساب الأساسي بالصيغة الدولية بدون + أو مسافات.\n\nمثال: `201234567890`',
    { parse_mode: 'Markdown', ...Markup.keyboard([['❌ إلغاء']]).resize() }
  );
});

async function promptInstall(ctx) {
  if (!(await requirePrivateChat(ctx))) return;

  ctx.session.mode = 'phone';
  await ctx.reply(
    '📱 أرسل رقم واتساب بالصيغة الدولية بدون + أو مسافات.\n\nمثال: `201234567890`\n\nسيصلك كود الربط هنا في تيليجرام.',
    { parse_mode: 'Markdown', ...Markup.keyboard([['❌ إلغاء']]).resize() }
  );
}

bot.command(['install', 'تنصيب'], promptInstall);

bot.hears('تنصيب البوت🕸️', promptInstall);
bot.hears('تنصيب البوت🕸️', promptInstall);

bot.hears('📊 حالة التنصيبات', async ctx => {
  if (!(await requirePrivateChat(ctx))) return;

  const count = activeSubBots().length;
  const pending = pendingInstalls.has(ctx.from.id);
  await ctx.reply(
    `📊 *الحالة*\n\n🤖 البوتات العاملة: ${count}\n⏳ طلبك الحالي: ${pending ? 'قيد التنفيذ' : 'لا يوجد'}`,
    { parse_mode: 'Markdown', ...mainKeyboard(ctx) }
  );
});

bot.hears('❓ المساعدة', async ctx => {
  if (!(await requirePrivateChat(ctx))) return;

  await ctx.replyWithMarkdown(helpText());
});

bot.hears('❌ إلغاء', async ctx => {
  if (!(await requirePrivateChat(ctx))) return;

  const state = pendingInstalls.get(ctx.from.id);
  if (state) {
    state.resolved = true;
    state.cleanup?.();
    if (state.uid && typeof state.sub?.remove === 'function') {
      try {
        await state.sub.remove(state.uid);
      } catch {}
    }
  }
  ctx.session.mode = null;
  await ctx.reply('✅ تم الإلغاء.', mainKeyboard(ctx));
});

bot.on('text', async ctx => {
  if (ctx.message.text.startsWith('/')) return;
  if (ctx.chat?.type !== 'private') return;
  if (ctx.session.mode === 'main-phone') {
    ctx.session.mode = null;
    await beginMainPair(ctx, ctx.message.text);
    return;
  }
  if (ctx.session.mode !== 'phone') return;
  ctx.session.mode = null;
  await beginInstall(ctx, ctx.message.text);
});

bot.catch((error, ctx) => {
  console.error(`Telegram error for ${ctx.updateType}:`, error?.message || error);
});

console.log('⏳ Starting Telegram installer polling...');
bot.launch({
  allowedUpdates: ['message', 'callback_query'],
  dropPendingUpdates: false
}).then(() => {
  console.log('✅ Telegram installer polling started');
}).catch(error => {
  console.error('❌ Telegram installer failed:', error?.message || error);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));